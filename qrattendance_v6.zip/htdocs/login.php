<?php
require_once __DIR__ . '/includes/auth.php';

// Already logged in? redirect
if (!empty($_SESSION['logged_in'])) {
    if ($_SESSION['role'] === 'admin') redirect('admin/dashboard.php');
    elseif ($_SESSION['role'] === 'teacher') redirect('teacher/dashboard.php');
    else redirect('student/dashboard.php');
}

$loginError = '';
$regError   = '';
$activeTab  = $_POST['active_tab'] ?? 'login';

// ── HANDLE LOGIN ──────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form_type'] ?? '') === 'login') {
    $activeTab = 'login';
    $username  = clean($_POST['username'] ?? '');
    $password  = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $loginError = 'Please enter both username and password.';
    } else {
        $userClass = new User();
        $user      = $userClass->login($username, $password);
        if ($user && empty($user['_blocked'])) {
            User::startSession($user);
            if ($user['role'] === 'admin')       redirect('admin/dashboard.php');
            elseif ($user['role'] === 'teacher') redirect('teacher/dashboard.php');
            else                                  redirect('student/dashboard.php');
        } elseif (is_array($user) && ($user['_blocked'] ?? '') === 'pending') {
            $loginError = 'Your teacher account is pending admin approval. Please check back soon.';
        } elseif (is_array($user) && ($user['_blocked'] ?? '') === 'rejected') {
            $loginError = 'Your account registration was not approved. Please contact the administrator.';
        } else {
            $loginError = 'Invalid username or password. Please try again.';
        }
    }
}

// ── HANDLE REGISTER ───────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form_type'] ?? '') === 'register') {
    $activeTab     = 'register';
    $firstName     = clean($_POST['first_name']     ?? '');
    $lastName      = clean($_POST['last_name']      ?? '');
    $studentNumber = clean($_POST['student_number'] ?? '');
    $course        = clean($_POST['course']         ?? '');
    $yearLevel     = (int)($_POST['year_level']     ?? 1);
    $section       = clean($_POST['section']        ?? '');
    $email         = clean($_POST['email']          ?? '');
    $username      = clean($_POST['reg_username']   ?? '');
    $password      = $_POST['reg_password']         ?? '';
    $confirm       = $_POST['reg_confirm']          ?? '';

    if (!$firstName || !$lastName || !$studentNumber || !$username || !$password) {
        $regError = 'Please fill in all required fields.';
    } elseif (strlen($password) < 6) {
        $regError = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm) {
        $regError = 'Passwords do not match.';
    } else {
        $studentClass = new Student();
        $result       = $studentClass->create([
            'student_number' => $studentNumber,
            'first_name'     => $firstName,
            'last_name'      => $lastName,
            'course'         => $course,
            'year_level'     => $yearLevel,
            'section'        => $section,
            'email'          => $email,
            'username'       => $username,
            'password'       => $password,
        ]);

        if ($result['success']) {
            // Auto-login after successful registration
            $userClass = new User();
            $user      = $userClass->login($username, $password);
            if ($user) {
                User::startSession($user);
                redirect('student/dashboard.php');
            }
        } else {
            $regError = $result['message'];
        }
    }
}

// ── HANDLE TEACHER REGISTER ──────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form_type'] ?? '') === 'teacher_register') {
    $activeTab = 'teacher_register';
    $tFirst    = clean($_POST['t_first_name']    ?? '');
    $tLast     = clean($_POST['t_last_name']     ?? '');
    $tEmail    = clean($_POST['t_email']         ?? '');
    $tEmpId    = clean($_POST['t_employee_id']   ?? '');
    $tDept     = clean($_POST['t_department']    ?? '');
    $tUser     = clean($_POST['t_username']      ?? '');
    $tPass     = $_POST['t_password']            ?? '';
    $tConfirm  = $_POST['t_confirm']             ?? '';

    if (!$tFirst || !$tLast || !$tUser || !$tPass) {
        $regError = 'Please fill in all required fields.';
        $activeTab = 'teacher_register';
    } elseif (strlen($tPass) < 6) {
        $regError = 'Password must be at least 6 characters.';
        $activeTab = 'teacher_register';
    } elseif ($tPass !== $tConfirm) {
        $regError = 'Passwords do not match.';
        $activeTab = 'teacher_register';
    } else {
        $teacherClass = new Teacher();
        $result = $teacherClass->create([
            'first_name'  => $tFirst, 'last_name'   => $tLast,
            'email'       => $tEmail, 'employee_id' => $tEmpId,
            'department'  => $tDept,  'username'    => $tUser,
            'password'    => $tPass,
        ]);
        if ($result['success']) {
            $loginError  = '';
            $regError    = '';
            $activeTab   = 'login';
            $regSuccess  = $result['message'];
        } else {
            $regError  = $result['message'];
            $activeTab = 'teacher_register';
        }
    }
}

$schoolName = User::getSetting('school_name') ?? 'QR Attendance System';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($schoolName) ?> — Login</title>
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="icon"             type="image/x-icon" href="<?= BASE_URL ?>/assets/favicon.ico">
  <link rel="icon"             type="image/png" sizes="32x32" href="<?= BASE_URL ?>/assets/favicon-32.png">
  <link rel="apple-touch-icon" sizes="180x180"    href="<?= BASE_URL ?>/assets/favicon-180.png">
  <style>
    .page-tabs {
      display: flex; gap: .4rem; margin-bottom: 1.8rem;
      background: var(--ad-bg); padding: .35rem; border-radius: var(--radius-sm);
    }
    .page-tab {
      flex: 1; padding: .6rem; border: none; border-radius: 6px;
      background: transparent; color: var(--ad-muted);
      font-weight: 600; font-size: .875rem; cursor: pointer;
      transition: var(--transition);
      display: flex; align-items: center; justify-content: center; gap: .45rem;
    }
    .page-tab.active {
      background: var(--primary); color: #fff;
      box-shadow: 0 2px 8px rgba(99,102,241,.4);
    }
    .form-panel { display: none; }
    .form-panel.active { display: block; }

    .divider {
      display: flex; align-items: center; gap: .75rem;
      margin: 1.1rem 0; color: var(--ad-muted); font-size: .78rem;
    }
    .divider::before, .divider::after {
      content: ''; flex: 1; height: 1px; background: var(--ad-border);
    }

    .demo-pill {
      display: flex; align-items: center; gap: .6rem;
      background: var(--ad-surface2); border: 1px solid var(--ad-border);
      border-radius: var(--radius-sm); padding: .6rem .9rem;
      font-size: .8rem; cursor: pointer; transition: var(--transition);
      color: var(--ad-muted); width: 100%; margin-top: .6rem;
    }
    .demo-pill:hover { border-color: var(--primary); color: var(--primary-light); }
    .demo-pill .demo-icon {
      width: 28px; height: 28px; background: rgba(99,102,241,.15);
      border-radius: 6px; display: flex; align-items: center; justify-content: center;
      font-size: .85rem; color: var(--primary); flex-shrink: 0;
    }
    .demo-pill code {
      background: var(--ad-bg); padding: .1rem .4rem;
      border-radius: 4px; color: var(--primary-light); font-size: .78rem;
    }

    .strength-bar {
      height: 4px; border-radius: 4px;
      background: var(--ad-border); margin-top: .4rem; overflow: hidden;
    }
    .strength-fill { height: 100%; border-radius: 4px; transition: width .3s, background .3s; width: 0%; }
    .strength-label { font-size: .72rem; margin-top: .25rem; }

    .login-form-area { overflow-y: auto; }
  </style>
</head>
<body>
<div class="login-page">

  <!-- Brand Panel -->
  <div class="login-brand">
    <div class="login-brand-content">
      <div class="login-brand-icon">
        <img src="<?= BASE_URL ?>/assets/school-logo.png"
             alt="School Logo"
             style="width:120px;height:120px;object-fit:contain;
                    filter:drop-shadow(0 4px 12px rgba(0,0,0,.4))">
      </div>
      <h1><?= htmlspecialchars($schoolName) ?></h1>
      <p>Scan-in, track attendance, and stay informed — all in one place.</p>
      <div style="margin-top:2.5rem;display:flex;flex-direction:column;gap:.9rem">
        <div style="display:flex;align-items:center;gap:.8rem;color:rgba(255,255,255,.8);font-size:.9rem">
          <div style="width:32px;height:32px;background:rgba(255,255,255,.15);border-radius:8px;display:flex;align-items:center;justify-content:center">
            <i class="fa-solid fa-qrcode"></i>
          </div>
          QR code generation &amp; scanning
        </div>
        <div style="display:flex;align-items:center;gap:.8rem;color:rgba(255,255,255,.8);font-size:.9rem">
          <div style="width:32px;height:32px;background:rgba(255,255,255,.15);border-radius:8px;display:flex;align-items:center;justify-content:center">
            <i class="fa-solid fa-chart-line"></i>
          </div>
          Real-time attendance analytics
        </div>
        <div style="display:flex;align-items:center;gap:.8rem;color:rgba(255,255,255,.8);font-size:.9rem">
          <div style="width:32px;height:32px;background:rgba(255,255,255,.15);border-radius:8px;display:flex;align-items:center;justify-content:center">
            <i class="fa-solid fa-shield-halved"></i>
          </div>
          Role-based access control
        </div>
      </div>
    </div>
  </div>

  <!-- Form Area -->
  <div class="login-form-area">
    <div class="login-box">

      <!-- Main tabs: Sign In / Create Account -->
      <div class="page-tabs">
        <button type="button" class="page-tab <?= $activeTab==='login'?'active':'' ?>"
                onclick="switchTab('login')">
          <i class="fa-solid fa-right-to-bracket"></i> Sign In
        </button>
        <button type="button" class="page-tab <?= $activeTab==='register'?'active':'' ?>"
                onclick="switchTab('register')">
          <i class="fa-solid fa-graduation-cap"></i> Student
        </button>
        <button type="button" class="page-tab <?= $activeTab==='teacher_register'?'active':'' ?>"
                onclick="switchTab('teacher_register')">
          <i class="fa-solid fa-chalkboard-user"></i> Teacher
        </button>
      </div>

      <!-- ══════════════ LOGIN PANEL ══════════════ -->
      <div class="form-panel <?= $activeTab==='login'?'active':'' ?>" id="panelLogin">

        <h2>Welcome back</h2>
        <p class="login-subtitle" style="margin-bottom:1.2rem">Sign in to continue to your dashboard.</p>

        <!-- Role tabs -->
        <div class="role-tabs">
          <button type="button" class="role-tab active" id="tabAdmin" onclick="setRole('admin')">
            <i class="fa-solid fa-user-shield"></i> Admin
          </button>
          <button type="button" class="role-tab" id="tabStudent" onclick="setRole('student')">
            <i class="fa-solid fa-user-graduate"></i> Student
          </button>
          <button type="button" class="role-tab" id="tabTeacher" onclick="setRole('teacher')">
            <i class="fa-solid fa-chalkboard-user"></i> Teacher
          </button>
        </div>

        <?php if ($loginError): ?>
          <div class="alert alert-danger">
            <i class="fa-solid fa-circle-exclamation"></i> <?= htmlspecialchars($loginError) ?>
          </div>
        <?php endif; ?>

        <form method="POST" action="" class="dark-form">
          <input type="hidden" name="form_type"  value="login">
          <input type="hidden" name="active_tab" value="login">
          <input type="hidden" name="role_hint"  id="roleHint" value="admin">

          <div class="form-group">
            <label class="form-label" for="username">Username</label>
            <div class="input-icon-wrap">
              <i class="fa-solid fa-user input-icon"></i>
              <input type="text" id="username" name="username" class="form-control"
                     placeholder="Enter your username"
                     value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                     autocomplete="username">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label" for="loginPassword">Password</label>
            <div class="input-icon-wrap">
              <i class="fa-solid fa-lock input-icon"></i>
              <input type="password" id="loginPassword" name="password" class="form-control"
                     placeholder="Enter your password"
                     autocomplete="current-password">
              <button type="button" onclick="togglePw('loginPassword','eyeLogin')" style="
                position:absolute;right:.9rem;top:50%;transform:translateY(-50%);
                background:none;border:none;color:var(--ad-muted);cursor:pointer;font-size:.95rem
              "><i class="fa-solid fa-eye" id="eyeLogin"></i></button>
            </div>
          </div>

          <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top:1.2rem">
            <i class="fa-solid fa-right-to-bracket"></i> Sign In
          </button>
        </form>

        <div class="divider">demo credentials</div>

        <button type="button" class="demo-pill" onclick="fillDemo()">
          <div class="demo-icon"><i class="fa-solid fa-user-shield"></i></div>
          <div>
            <div style="font-weight:600;color:var(--ad-text)">Admin Demo — click to fill</div>
            <div>Username: <code>admin</code> &nbsp;·&nbsp; Password: <code>admin123</code></div>
          </div>
          <i class="fa-solid fa-wand-magic-sparkles" style="margin-left:auto;color:var(--primary)"></i>
        </button>

        <div style="text-align:center;margin-top:1.3rem;color:var(--ad-muted);font-size:.8rem">
          Don't have an account?
          <button type="button" onclick="switchTab('register')"
            style="background:none;border:none;color:var(--primary-light);cursor:pointer;font-size:.8rem;font-weight:600;padding:0">
            Create one &rarr;
          </button>
        </div>
      </div>

      <!-- ══════════════ REGISTER PANEL ══════════════ -->
      <div class="form-panel <?= $activeTab==='register'?'active':'' ?>" id="panelRegister">

        <h2>Create Account</h2>
        <p class="login-subtitle" style="margin-bottom:1.2rem">
          Register as a student to track your attendance.
        </p>

        <?php if ($regError): ?>
          <div class="alert alert-danger">
            <i class="fa-solid fa-circle-exclamation"></i> <?= htmlspecialchars($regError) ?>
          </div>
        <?php endif; ?>

        <form method="POST" action="" class="dark-form" id="formRegister">
          <input type="hidden" name="form_type"  value="register">
          <input type="hidden" name="active_tab" value="register">

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">First Name <span style="color:var(--danger)">*</span></label>
              <input type="text" name="first_name" class="form-control"
                     placeholder="e.g. Maria"
                     value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>" required>
            </div>
            <div class="form-group">
              <label class="form-label">Last Name <span style="color:var(--danger)">*</span></label>
              <input type="text" name="last_name" class="form-control"
                     placeholder="e.g. Santos"
                     value="<?= htmlspecialchars($_POST['last_name'] ?? '') ?>" required>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Student Number <span style="color:var(--danger)">*</span></label>
            <div class="input-icon-wrap">
              <i class="fa-solid fa-id-card input-icon"></i>
              <input type="text" name="student_number" class="form-control"
                     placeholder="e.g. 2024-00001"
                     value="<?= htmlspecialchars($_POST['student_number'] ?? '') ?>"
                     style="padding-left:2.6rem" required>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Course</label>
              <input type="text" name="course" class="form-control" placeholder="e.g. BSIT"
                     value="<?= htmlspecialchars($_POST['course'] ?? '') ?>">
            </div>
            <div class="form-group">
              <label class="form-label">Year</label>
              <select name="year_level" class="form-control">
                <?php for ($y = 1; $y <= 5; $y++): ?>
                  <option value="<?= $y ?>" <?= (($_POST['year_level'] ?? 1) == $y) ? 'selected' : '' ?>>
                    Year <?= $y ?>
                  </option>
                <?php endfor; ?>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Section</label>
              <input type="text" name="section" class="form-control" placeholder="e.g. A"
                     value="<?= htmlspecialchars($_POST['section'] ?? '') ?>">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Email</label>
            <div class="input-icon-wrap">
              <i class="fa-solid fa-envelope input-icon"></i>
              <input type="email" name="email" class="form-control"
                     placeholder="your@email.com"
                     value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                     style="padding-left:2.6rem">
            </div>
          </div>

          <div class="divider">Login Credentials</div>

          <div class="form-group">
            <label class="form-label">Username <span style="color:var(--danger)">*</span></label>
            <div class="input-icon-wrap">
              <i class="fa-solid fa-at input-icon"></i>
              <input type="text" name="reg_username" id="reg_username" class="form-control"
                     placeholder="Choose a username"
                     value="<?= htmlspecialchars($_POST['reg_username'] ?? '') ?>"
                     style="padding-left:2.6rem" autocomplete="off" required>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Password <span style="color:var(--danger)">*</span></label>
            <div class="input-icon-wrap">
              <i class="fa-solid fa-lock input-icon"></i>
              <input type="password" name="reg_password" id="reg_password" class="form-control"
                     placeholder="Min. 6 characters"
                     style="padding-left:2.6rem"
                     oninput="checkStrength(this.value)"
                     autocomplete="new-password" required>
              <button type="button" onclick="togglePw('reg_password','eyeReg')" style="
                position:absolute;right:.9rem;top:50%;transform:translateY(-50%);
                background:none;border:none;color:var(--ad-muted);cursor:pointer;font-size:.95rem
              "><i class="fa-solid fa-eye" id="eyeReg"></i></button>
            </div>
            <div class="strength-bar"><div class="strength-fill" id="strengthFill"></div></div>
            <div class="strength-label" id="strengthLabel" style="color:var(--ad-muted)"></div>
          </div>

          <div class="form-group">
            <label class="form-label">Confirm Password <span style="color:var(--danger)">*</span></label>
            <div class="input-icon-wrap">
              <i class="fa-solid fa-lock input-icon"></i>
              <input type="password" name="reg_confirm" id="reg_confirm" class="form-control"
                     placeholder="Re-enter password"
                     style="padding-left:2.6rem"
                     oninput="checkMatch()"
                     autocomplete="new-password" required>
            </div>
            <div class="strength-label" id="matchLabel" style="color:var(--ad-muted)"></div>
          </div>

          <button type="submit" class="btn btn-success btn-block btn-lg"
                  style="margin-top:.5rem" onclick="return validateReg()">
            <i class="fa-solid fa-user-plus"></i> Create My Account
          </button>
        </form>

        <div style="text-align:center;margin-top:1.3rem;color:var(--ad-muted);font-size:.8rem">
          Already have an account?
          <button type="button" onclick="switchTab('login')"
            style="background:none;border:none;color:var(--primary-light);cursor:pointer;font-size:.8rem;font-weight:600;padding:0">
            Sign in &rarr;
          </button>
        </div>
      </div>

    <!-- ══════════════ TEACHER REGISTER PANEL ══════════════ -->
    <div class="form-panel <?= $activeTab==='teacher_register'?'active':'' ?>" id="panelTeacherReg">

      <?php if (!empty($regSuccess)): ?>
        <div class="alert alert-success">
          <i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($regSuccess) ?>
        </div>
      <?php endif; ?>
      <?php if ($activeTab==='teacher_register' && !empty($regError)): ?>
        <div class="alert alert-danger">
          <i class="fa-solid fa-circle-exclamation"></i> <?= htmlspecialchars($regError) ?>
        </div>
      <?php endif; ?>

      <div style="background:rgba(14,165,233,.08);border:1px solid rgba(14,165,233,.25);border-radius:var(--radius-sm);padding:.75rem 1rem;margin-bottom:1rem;font-size:.82rem;color:var(--ad-text)">
        <i class="fa-solid fa-circle-info" style="color:#0ea5e9"></i>
        Teacher accounts require <strong>admin approval</strong> before you can log in.
      </div>

      <form method="POST" onsubmit="return validateTeacherReg()">
        <input type="hidden" name="form_type"  value="teacher_register">
        <input type="hidden" name="active_tab" value="teacher_register">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.7rem">
          <div class="form-group">
            <label class="form-label">First Name <span style="color:var(--danger)">*</span></label>
            <input type="text" name="t_first_name" class="form-control" placeholder="Juan" required>
          </div>
          <div class="form-group">
            <label class="form-label">Last Name <span style="color:var(--danger)">*</span></label>
            <input type="text" name="t_last_name" class="form-control" placeholder="Dela Cruz" required>
          </div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.7rem">
          <div class="form-group">
            <label class="form-label">Employee ID</label>
            <input type="text" name="t_employee_id" class="form-control" placeholder="EMP-0001">
          </div>
          <div class="form-group">
            <label class="form-label">Department</label>
            <input type="text" name="t_department" class="form-control" placeholder="College of IT">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" name="t_email" class="form-control" placeholder="juan@school.edu.ph">
        </div>
        <div class="form-group">
          <label class="form-label">Username <span style="color:var(--danger)">*</span></label>
          <input type="text" name="t_username" class="form-control" placeholder="jdelacruz" required autocomplete="username">
        </div>
        <div class="form-group">
          <label class="form-label">Password <span style="color:var(--danger)">*</span></label>
          <div style="position:relative">
            <input type="password" name="t_password" id="t_password" class="form-control"
                   placeholder="Min. 6 characters" required autocomplete="new-password"
                   oninput="checkStrength(this.value)">
            <button type="button" onclick="togglePw('t_password','t_eye')"
              style="position:absolute;right:.7rem;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:var(--ad-muted)">
              <i id="t_eye" class="fa-solid fa-eye"></i>
            </button>
          </div>
          <div style="display:flex;align-items:center;gap:.5rem;margin-top:.3rem">
            <div style="flex:1;height:4px;background:var(--ad-border);border-radius:2px">
              <div id="strengthFill2" style="height:100%;border-radius:2px;width:0;transition:all .3s"></div>
            </div>
            <span id="strengthLabel2" style="font-size:.72rem;min-width:40px"></span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Confirm Password <span style="color:var(--danger)">*</span></label>
          <div style="position:relative">
            <input type="password" name="t_confirm" id="t_confirm" class="form-control"
                   placeholder="Re-enter password" required autocomplete="new-password"
                   oninput="checkTeacherMatch()">
            <button type="button" onclick="togglePw('t_confirm','t_eye2')"
              style="position:absolute;right:.7rem;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:var(--ad-muted)">
              <i id="t_eye2" class="fa-solid fa-eye"></i>
            </button>
          </div>
          <div id="tMatchLabel" style="font-size:.78rem;margin-top:.25rem"></div>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;margin-top:.4rem">
          <i class="fa-solid fa-paper-plane"></i> Submit Registration
        </button>
        <div style="text-align:center;margin-top:1rem;color:var(--ad-muted);font-size:.8rem">
          Already have an account?
          <button type="button" onclick="switchTab('login')"
            style="background:none;border:none;color:var(--primary-light);cursor:pointer;font-size:.8rem;font-weight:600;padding:0">
            Sign in &rarr;
          </button>
        </div>
      </form>
    </div><!-- /panelTeacherReg -->

    </div><!-- /login-box -->
  </div><!-- /login-form-area -->
</div><!-- /login-page -->

<script>
// Tab switching
function switchTab(tab) {
  document.getElementById('panelLogin').classList.toggle('active',      tab === 'login');
  document.getElementById('panelRegister').classList.toggle('active',   tab === 'register');
  const tPanel = document.getElementById('panelTeacherReg');
  if (tPanel) tPanel.classList.toggle('active', tab === 'teacher_register');
  document.querySelectorAll('.page-tab').forEach((btn, i) => {
    btn.classList.toggle('active',
      (i === 0 && tab === 'login') ||
      (i === 1 && tab === 'register') ||
      (i === 2 && tab === 'teacher_register')
    );
  });
}

function checkTeacherMatch() {
  const p1  = document.getElementById('t_password').value;
  const p2  = document.getElementById('t_confirm').value;
  const lbl = document.getElementById('tMatchLabel');
  if (!p2) { lbl.textContent = ''; return; }
  lbl.textContent = p1 === p2 ? '✓ Passwords match' : '✗ Passwords do not match';
  lbl.style.color = p1 === p2 ? 'var(--success)' : 'var(--danger)';
}

function validateTeacherReg() {
  const p1 = document.getElementById('t_password').value;
  const p2 = document.getElementById('t_confirm').value;
  if (p1 !== p2)     { alert('Passwords do not match.');                return false; }
  if (p1.length < 6) { alert('Password must be at least 6 characters.'); return false; }
  return true;
}

// Role selector
function setRole(role) {
  document.getElementById('roleHint').value = role;
  document.getElementById('tabAdmin').classList.toggle('active',   role === 'admin');
  document.getElementById('tabStudent').classList.toggle('active', role === 'student');
  document.getElementById('tabTeacher').classList.toggle('active', role === 'teacher');
}

function switchToTeacherReg() {
  switchTab('teacher_register');
}

// Show/hide password
function togglePw(inputId, iconId) {
  const pw = document.getElementById(inputId);
  const ic = document.getElementById(iconId);
  pw.type        = pw.type === 'password' ? 'text' : 'password';
  ic.className   = pw.type === 'text' ? 'fa-solid fa-eye-slash' : 'fa-solid fa-eye';
}

// Fill demo credentials
function fillDemo() {
  document.getElementById('username').value      = 'admin';
  document.getElementById('loginPassword').value = 'admin123';
  setRole('admin');
  const pill = document.querySelector('.demo-pill');
  pill.style.borderColor = 'var(--success)';
  pill.style.color       = '#10b981';
  setTimeout(() => { pill.style.borderColor = ''; pill.style.color = ''; }, 900);
}

// Password strength meter
function checkStrength(val) {
  let score = 0;
  if (val.length >= 6)                          score++;
  if (val.length >= 10)                         score++;
  if (/[A-Z]/.test(val) && /[a-z]/.test(val))  score++;
  if (/\d/.test(val))                           score++;
  if (/[^A-Za-z0-9]/.test(val))                score++;

  const levels = [
    { pct: '0%',   color: '',                  text: '' },
    { pct: '25%',  color: 'var(--danger)',     text: 'Weak' },
    { pct: '50%',  color: 'var(--warning)',    text: 'Fair' },
    { pct: '75%',  color: 'var(--info)',       text: 'Good' },
    { pct: '100%', color: 'var(--success)',    text: 'Strong' },
  ];
  const lvl = levels[Math.min(score, 4)];
  const fill  = document.getElementById('strengthFill');
  const label = document.getElementById('strengthLabel');
  fill.style.width      = lvl.pct;
  fill.style.background = lvl.color;
  label.textContent     = lvl.text;
  label.style.color     = lvl.color;
}

// Confirm match
function checkMatch() {
  const p1  = document.getElementById('reg_password').value;
  const p2  = document.getElementById('reg_confirm').value;
  const lbl = document.getElementById('matchLabel');
  if (!p2) { lbl.textContent = ''; return; }
  lbl.textContent = p1 === p2 ? '✓ Passwords match' : '✗ Passwords do not match';
  lbl.style.color = p1 === p2 ? 'var(--success)' : 'var(--danger)';
}

// Client-side register validation
function validateReg() {
  const p1 = document.getElementById('reg_password').value;
  const p2 = document.getElementById('reg_confirm').value;
  if (p1 !== p2)    { alert('Passwords do not match.');              return false; }
  if (p1.length < 6){ alert('Password must be at least 6 characters.'); return false; }
  return true;
}

// Auto-dismiss alerts
document.querySelectorAll('.alert').forEach(a => {
  setTimeout(() => {
    a.style.transition = 'opacity .5s';
    a.style.opacity    = '0';
    setTimeout(() => a.remove(), 500);
  }, 5000);
});
</script>
</body>
</html>