<?php
// ============================================================
//  reset_admin.php — Emergency Admin Account Fix
//  Upload this to your site root, visit it once, then DELETE it
// ============================================================

require_once __DIR__ . '/config/database.php';

$message = '';
$type    = '';
$done    = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newUser = trim($_POST['admin_user'] ?? 'admin');
    $newPass = $_POST['admin_pass'] ?? 'admin123';

    if (strlen($newPass) < 4) {
        $message = 'Password too short (min 4 chars).';
        $type    = 'error';
    } else {
        try {
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER, DB_PASS,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );

            $hash = password_hash($newPass, PASSWORD_BCRYPT);

            // Check if admin user already exists
            $check = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $check->execute([$newUser]);
            $existing = $check->fetch(PDO::FETCH_ASSOC);

            if ($existing) {
                // Update the existing user's password and ensure role is admin
                $pdo->prepare("UPDATE users SET password = ?, role = 'admin', is_active = 1 WHERE username = ?")
                    ->execute([$hash, $newUser]);
                $message = "✅ Admin account \"$newUser\" password has been reset successfully!";
            } else {
                // Create a brand new admin account
                $pdo->prepare("INSERT INTO users (username, password, role, is_active) VALUES (?, ?, 'admin', 1)")
                    ->execute([$newUser, $hash]);
                $message = "✅ New admin account \"$newUser\" created successfully!";
            }

            $type = 'success';
            $done = true;

        } catch (PDOException $e) {
            $message = '❌ Database error: ' . htmlspecialchars($e->getMessage());
            $type    = 'error';
        }
    }
}

// Quick verification test
$verifyResult = '';
if ($done) {
    try {
        $pdo  = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        $row  = $pdo->prepare("SELECT password FROM users WHERE username = ?");
        $row->execute([$_POST['admin_user'] ?? 'admin']);
        $user = $row->fetch(PDO::FETCH_ASSOC);
        if ($user && password_verify($_POST['admin_pass'], $user['password'])) {
            $verifyResult = '✅ Verification passed — login will work!';
        } else {
            $verifyResult = '⚠️ Verification failed — something went wrong.';
        }
    } catch (Exception $e) {
        $verifyResult = '⚠️ Could not verify: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Reset Tool</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="install-page">
  <div class="install-card" style="max-width:480px">

    <div class="install-card-header" style="background:#ef4444">
      <div style="font-size:2rem;margin-bottom:.5rem">🔑</div>
      <h1 style="font-size:1.3rem">Admin Account Reset</h1>
      <p style="opacity:.85;font-size:.85rem;margin-top:.3rem">
        Use this tool to fix or recreate the admin account.<br>
        <strong>Delete this file after use!</strong>
      </p>
    </div>

    <div class="install-card-body">

      <?php if ($message): ?>
        <div style="
          padding: .9rem 1.1rem;
          border-radius: 8px;
          margin-bottom: 1.2rem;
          font-weight: 600;
          background: <?= $type === 'success' ? '#d1fae5' : '#fee2e2' ?>;
          color:       <?= $type === 'success' ? '#065f46' : '#991b1b' ?>;
          border-left: 4px solid <?= $type === 'success' ? '#10b981' : '#ef4444' ?>;
        ">
          <?= $message ?>
        </div>
        <?php if ($verifyResult): ?>
          <div style="
            padding:.8rem 1rem;border-radius:8px;margin-bottom:1.2rem;font-size:.875rem;
            background:#dbeafe;color:#1e40af;border-left:4px solid #3b82f6;
          ">
            <?= htmlspecialchars($verifyResult) ?>
          </div>
        <?php endif; ?>
      <?php endif; ?>

      <?php if ($done && $type === 'success'): ?>
        <div style="text-align:center;padding:.5rem 0 1rem">
          <a href="login.php" class="btn btn-primary btn-lg">
            <i class="fa-solid fa-right-to-bracket"></i> Go to Login Now
          </a>
          <p style="color:#64748b;font-size:.8rem;margin-top:1rem">
            ⚠️ Remember to <strong>delete reset_admin.php</strong> from your server!
          </p>
        </div>
      <?php else: ?>
        <form method="POST" class="dark-form">
          <p style="color:var(--ad-muted);font-size:.85rem;margin-bottom:1.2rem">
            Set the username and password for your admin account. If the account already exists, its password will be updated.
          </p>

          <div class="form-group">
            <label class="form-label">Admin Username</label>
            <div style="position:relative">
              <i class="fa-solid fa-user" style="position:absolute;left:.9rem;top:50%;transform:translateY(-50%);color:var(--ad-muted)"></i>
              <input type="text" name="admin_user" class="form-control"
                     value="<?= htmlspecialchars($_POST['admin_user'] ?? 'admin') ?>"
                     style="padding-left:2.6rem" required>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">New Password</label>
            <div style="position:relative">
              <i class="fa-solid fa-lock" style="position:absolute;left:.9rem;top:50%;transform:translateY(-50%);color:var(--ad-muted)"></i>
              <input type="text" name="admin_pass" class="form-control"
                     value="<?= htmlspecialchars($_POST['admin_pass'] ?? 'admin123') ?>"
                     style="padding-left:2.6rem" required>
            </div>
            <small style="color:var(--ad-muted)">Shown as plain text so you can confirm what you're setting.</small>
          </div>

          <!-- Current DB info -->
          <div style="background:var(--ad-bg);border-radius:8px;padding:.8rem 1rem;margin-bottom:1.2rem;font-size:.8rem;color:var(--ad-muted)">
            <strong style="color:var(--ad-text)">Current DB Config</strong><br>
            Host: <code><?= htmlspecialchars(DB_HOST) ?></code> &nbsp;·&nbsp;
            DB: <code><?= htmlspecialchars(DB_NAME) ?></code> &nbsp;·&nbsp;
            User: <code><?= htmlspecialchars(DB_USER) ?></code>
          </div>

          <button type="submit" class="btn btn-danger btn-block btn-lg">
            <i class="fa-solid fa-rotate"></i> Reset / Create Admin Account
          </button>
        </form>
      <?php endif; ?>

    </div>
  </div>
</div>
</body>
</html>
