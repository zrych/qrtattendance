<?php header('Location: ../admin/backup.php'); exit;
