<?php
require_once __DIR__ . '/../includes/auth.php';
User::requireLogin('student');

$studentClass    = new Student();
$attendanceClass = new Attendance();
$subjectClass    = new Subject();

$student = $studentClass->findByUserId((int)$_SESSION['user_id']);
if (!$student) {
    setFlash('danger', 'Student profile not found. Please contact your administrator.');
    User::logout();
}

$recentRecords  = $attendanceClass->getByStudent($student['id'], 5);
$allRecords     = $attendanceClass->getByStudent($student['id'], 999);
$attendanceRate = $attendanceClass->studentRate($student['id']);

// Enrolled subjects indexed by day
$mySubjects    = $subjectClass->getByStudent((int)$student['id']);
$subjectsByDay = [];
foreach ($mySubjects as $s) {
    $subjectsByDay[$s['day_of_week']][] = $s;
}

// Today's attendance records indexed by subject_id
$todayRecords = [];
foreach ($allRecords as $r) {
    if ($r['date'] === date('Y-m-d')) {
        $todayRecords[$r['subject_id'] ?? 'none'] = $r;
    }
}
$todayRecord = !empty($todayRecords) ? array_values($todayRecords)[0] : null;

// Streak
$streak = 0;
$dates  = array_column($allRecords, 'date');
if (!empty($dates)) {
    $check = date('Y-m-d');
    foreach ($dates as $d) {
        if ($d === $check) { $streak++; $check = date('Y-m-d', strtotime($check . ' -1 day')); }
        else break;
    }
}

$totalPresent = count(array_filter($allRecords, fn($r) => $r['status'] === 'present'));
$totalLate    = count(array_filter($allRecords, fn($r) => $r['status'] === 'late'));
$totalAbsent  = count(array_filter($allRecords, fn($r) => $r['status'] === 'absent'));

$days    = Subject::$DAYS;
$today   = date('l');
$nowTime = date('H:i:s');

$pageTitle = 'My Dashboard';
$activeNav = 'dashboard';
require_once __DIR__ . '/../includes/header_student.php';
?>

<!-- Welcome banner -->
<div style="background:linear-gradient(135deg,#6366f1,#8b5cf6);border-radius:var(--radius);padding:1.8rem 2rem;margin-bottom:1.5rem;color:#fff;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem">
  <div>
    <div style="font-size:.82rem;opacity:.8;text-transform:uppercase;letter-spacing:.6px;margin-bottom:.3rem">Welcome back</div>
    <h2 style="font-size:1.5rem;font-weight:800;margin-bottom:.2rem">
      <?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?>
    </h2>
    <div style="opacity:.85;font-size:.9rem">
      <?= htmlspecialchars($student['student_number']) ?> &nbsp;·&nbsp;
      <?= htmlspecialchars($student['course'] . ' Year ' . $student['year_level']) ?>
      <?php if ($student['section']): ?>&nbsp;– Section <?= htmlspecialchars($student['section']) ?><?php endif; ?>
    </div>
  </div>
  <a href="<?= BASE_URL ?>/student/qrcode.php" class="btn" style="background:rgba(255,255,255,.2);color:#fff;border:2px solid rgba(255,255,255,.4)">
    <i class="fa-solid fa-qrcode"></i> View My QR Code
  </a>
</div>

<!-- Stats row -->
<div class="stat-cards mb-2" style="margin-bottom:1.5rem">
  <div class="stat-card stat-card-light">
    <div class="stat-icon stat-icon-primary"><i class="fa-solid fa-chart-pie"></i></div>
    <div class="stat-info"><div class="stat-label">Attendance Rate</div><div class="stat-value"><?= $attendanceRate ?>%</div></div>
  </div>
  <div class="stat-card stat-card-light">
    <div class="stat-icon stat-icon-success"><i class="fa-solid fa-user-check"></i></div>
    <div class="stat-info"><div class="stat-label">Present</div><div class="stat-value"><?= $totalPresent ?></div></div>
  </div>
  <div class="stat-card stat-card-light">
    <div class="stat-icon stat-icon-warning"><i class="fa-solid fa-clock"></i></div>
    <div class="stat-info"><div class="stat-label">Late</div><div class="stat-value"><?= $totalLate ?></div></div>
  </div>
  <div class="stat-card stat-card-light">
    <div class="stat-icon stat-icon-danger"><i class="fa-solid fa-calendar-xmark"></i></div>
    <div class="stat-info"><div class="stat-label">Absences</div><div class="stat-value"><?= $totalAbsent ?></div></div>
  </div>
</div>

<!-- ═══════════ WEEKLY SCHEDULE ═══════════════════════════════ -->
<div class="card card-light" style="margin-bottom:1.5rem">
  <div class="card-header">
    <h3><i class="fa-solid fa-calendar-week" style="color:var(--primary)"></i>&nbsp;
      Weekly Schedule &nbsp;<span style="font-size:.8rem;color:var(--st-muted);font-weight:400">— <?= date('l, F j') ?></span>
    </h3>
    <?php if (empty($mySubjects)): ?>
      <a href="<?= BASE_URL ?>/student/notifications.php" class="btn btn-outline btn-sm">Enroll in Subjects</a>
    <?php endif; ?>
  </div>
  <div class="card-body" style="padding:1rem">

    <?php if (empty($mySubjects)): ?>
      <div class="empty-state" style="padding:1.5rem">
        <div class="empty-icon">📚</div>
        <h3 style="color:var(--st-muted)">No subjects yet</h3>
        <p style="color:var(--st-muted)">Check your <a href="<?= BASE_URL ?>/student/notifications.php">Subjects</a> tab to enroll or accept invitations.</p>
      </div>
    <?php else: ?>

      <!-- Mobile: vertical day list -->
      <div class="schedule-week-grid">
        <?php foreach ($days as $day):
          $daySubjects = $subjectsByDay[$day] ?? [];
          $isToday     = $day === $today;
        ?>
        <div class="schedule-day <?= $isToday ? 'schedule-day-today' : '' ?>">
          <!-- Day header -->
          <div class="schedule-day-header">
            <span class="schedule-day-name"><?= $isToday ? '⭐ ' : '' ?><?= $day ?></span>
            <?php if ($isToday): ?>
              <span style="font-size:.68rem;background:var(--primary);color:#fff;padding:.15rem .5rem;border-radius:999px">TODAY</span>
            <?php endif; ?>
          </div>

          <?php if (empty($daySubjects)): ?>
            <div style="text-align:center;padding:.8rem 0;color:var(--st-muted);font-size:.78rem">No class</div>
          <?php else: ?>
            <?php foreach ($daySubjects as $subj):
              $ongoing = Subject::isOngoing($subj);
              $isPast  = $isToday && $nowTime > $subj['time_end'];
              $isFuture= $isToday && $nowTime < $subj['time_start'];

              // Find attendance record for this subject today
              $attRecord = $todayRecords[$subj['id']] ?? null;
            ?>
            <div class="schedule-subject-card
              <?= $ongoing ? ' schedule-subject-ongoing' : '' ?>
              <?= ($isPast && !$attRecord) ? ' schedule-subject-missed' : '' ?>">

              <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:.5rem">
                <div>
                  <div style="font-weight:700;font-size:.85rem;color:var(--st-text)">
                    <?= htmlspecialchars($subj['code']) ?>
                    <?php if ($ongoing): ?>
                      <span class="live-dot"></span>
                    <?php endif; ?>
                  </div>
                  <div style="font-size:.75rem;color:var(--st-muted);margin-top:.1rem">
                    <?= htmlspecialchars($subj['name']) ?>
                  </div>
                  <div style="font-size:.72rem;color:var(--st-muted);margin-top:.2rem">
                    <i class="fa-solid fa-clock" style="font-size:.6rem"></i>
                    <?= date('h:i A', strtotime($subj['time_start'])) ?> – <?= date('h:i A', strtotime($subj['time_end'])) ?>
                    <?php if ($subj['room']): ?>· <?= htmlspecialchars($subj['room']) ?><?php endif; ?>
                  </div>
                </div>

                <!-- Status badge for today's classes -->
                <?php if ($isToday): ?>
                  <?php if ($attRecord): ?>
                    <?php if ($attRecord['status'] === 'present'): ?>
                      <span style="background:#dcfce7;color:#15803d;font-size:.68rem;font-weight:700;padding:.2rem .5rem;border-radius:999px;white-space:nowrap">✓ Present</span>
                    <?php elseif ($attRecord['status'] === 'late'): ?>
                      <span style="background:#fef9c3;color:#854d0e;font-size:.68rem;font-weight:700;padding:.2rem .5rem;border-radius:999px;white-space:nowrap">⏰ Late</span>
                    <?php else: ?>
                      <span style="background:#fee2e2;color:#991b1b;font-size:.68rem;font-weight:700;padding:.2rem .5rem;border-radius:999px;white-space:nowrap">✗ Absent</span>
                    <?php endif; ?>
                  <?php elseif ($ongoing): ?>
                    <span style="background:rgba(99,102,241,.15);color:var(--primary);font-size:.68rem;font-weight:700;padding:.2rem .5rem;border-radius:999px;white-space:nowrap;animation:pulse 2s infinite">📷 Scan now</span>
                  <?php elseif ($isPast): ?>
                    <span style="background:#f1f5f9;color:#64748b;font-size:.68rem;padding:.2rem .5rem;border-radius:999px;white-space:nowrap">Not recorded</span>
                  <?php else: ?>
                    <span style="background:#f1f5f9;color:#94a3b8;font-size:.68rem;padding:.2rem .5rem;border-radius:999px;white-space:nowrap">Upcoming</span>
                  <?php endif; ?>
                <?php endif; ?>
              </div>

              <?php if ($attRecord && $attRecord['time_in']): ?>
                <div style="margin-top:.4rem;font-size:.7rem;color:var(--st-muted);display:flex;gap:.8rem">
                  <span><i class="fa-solid fa-right-to-bracket" style="font-size:.6rem"></i> <?= date('h:i A', strtotime($attRecord['time_in'])) ?></span>
                  <?php if ($attRecord['time_out']): ?>
                    <span><i class="fa-solid fa-right-from-bracket" style="font-size:.6rem"></i> <?= date('h:i A', strtotime($attRecord['time_out'])) ?></span>
                  <?php else: ?>
                    <span style="color:var(--warning)">Time-out pending</span>
                  <?php endif; ?>
                </div>
              <?php endif; ?>

            </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
        <?php endforeach; ?>
      </div>

    <?php endif; ?>
  </div>
</div>

<!-- Today's status + Recent records (two-col layout) -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:1.2rem">

  <!-- Today's status -->
  <div class="card card-light">
    <div class="card-header">
      <h3><i class="fa-solid fa-calendar-day" style="color:var(--primary)"></i>&nbsp; Today</h3>
    </div>
    <div class="card-body">
      <?php if ($todayRecord): ?>
        <div style="text-align:center;margin-bottom:1rem">
          <?php if ($todayRecord['status']==='present'): ?>
            <div style="font-size:2.8rem">✅</div>
            <span class="badge badge-success" style="margin-top:.4rem;font-size:.9rem">Present</span>
          <?php elseif ($todayRecord['status']==='late'): ?>
            <div style="font-size:2.8rem">⏰</div>
            <span class="badge badge-warning" style="margin-top:.4rem;font-size:.9rem">Late</span>
          <?php else: ?>
            <div style="font-size:2.8rem">❌</div>
            <span class="badge badge-danger" style="margin-top:.4rem;font-size:.9rem">Absent</span>
          <?php endif; ?>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.7rem">
          <div style="text-align:center;background:var(--st-bg);border-radius:var(--radius-sm);padding:.7rem">
            <div style="font-size:.72rem;color:var(--st-muted);text-transform:uppercase;letter-spacing:.5px">Time In</div>
            <div style="font-size:1.1rem;font-weight:700;color:var(--st-text)">
              <?= $todayRecord['time_in'] ? date('h:i A', strtotime($todayRecord['time_in'])) : '—' ?>
            </div>
          </div>
          <div style="text-align:center;background:var(--st-bg);border-radius:var(--radius-sm);padding:.7rem">
            <div style="font-size:.72rem;color:var(--st-muted);text-transform:uppercase;letter-spacing:.5px">Time Out</div>
            <div style="font-size:1.1rem;font-weight:700;color:var(--st-text)">
              <?= $todayRecord['time_out'] ? date('h:i A', strtotime($todayRecord['time_out'])) : '<span style="color:var(--st-muted);font-size:.9rem">Not yet</span>' ?>
            </div>
          </div>
        </div>
      <?php else: ?>
        <div style="text-align:center;padding:1rem 0">
          <div style="font-size:2.5rem;margin-bottom:.5rem">📋</div>
          <div style="font-weight:700;color:var(--st-text);margin-bottom:.3rem">No attendance yet today</div>
          <div style="color:var(--st-muted);font-size:.85rem;margin-bottom:1rem">Show your QR code to record attendance.</div>
          <a href="<?= BASE_URL ?>/student/qrcode.php" class="btn btn-primary btn-sm">
            <i class="fa-solid fa-qrcode"></i> Show QR
          </a>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Recent records -->
  <div class="card card-light">
    <div class="card-header">
      <h3><i class="fa-solid fa-history" style="color:var(--primary)"></i>&nbsp; Recent</h3>
      <a href="<?= BASE_URL ?>/student/my_attendance.php" class="btn btn-outline btn-sm">View All</a>
    </div>
    <div class="card-body" style="padding:0">
      <?php if (empty($recentRecords)): ?>
        <div class="empty-state" style="padding:1.5rem">
          <div class="empty-icon">📅</div>
          <p style="color:var(--st-muted)">No records yet.</p>
        </div>
      <?php else: ?>
        <div class="table-wrapper">
          <table class="table table-light">
            <thead><tr><th>Date</th><th>In</th><th>Status</th></tr></thead>
            <tbody>
              <?php foreach ($recentRecords as $r): ?>
              <tr>
                <td>
                  <strong><?= date('M j', strtotime($r['date'])) ?></strong>
                  <div style="font-size:.72rem;color:var(--st-muted)"><?= date('D', strtotime($r['date'])) ?></div>
                </td>
                <td><?= $r['time_in'] ? date('h:i A', strtotime($r['time_in'])) : '—' ?></td>
                <td>
                  <?php if ($r['status']==='present'): ?>
                    <span class="badge badge-success">Present</span>
                  <?php elseif ($r['status']==='late'): ?>
                    <span class="badge badge-warning">Late</span>
                  <?php else: ?>
                    <span class="badge badge-danger">Absent</span>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>

</div>

<style>
/* ── Week Schedule Grid ────────────────────────── */
.schedule-week-grid {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: .5rem;
}
.schedule-day {
  background: var(--st-bg);
  border: 1px solid var(--st-border);
  border-radius: var(--radius-sm);
  padding: .5rem;
  min-height: 80px;
}
.schedule-day-today {
  background: rgba(99,102,241,.06);
  border-color: var(--primary);
  box-shadow: 0 0 0 1px rgba(99,102,241,.2);
}
.schedule-day-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: .4rem;
  gap: .3rem;
  flex-wrap: wrap;
}
.schedule-day-name {
  font-size: .68rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: .4px;
  color: var(--st-muted);
}
.schedule-day-today .schedule-day-name {
  color: var(--primary);
}
.schedule-subject-card {
  background: var(--st-surface);
  border: 1px solid var(--st-border);
  border-radius: 6px;
  padding: .5rem .55rem;
  margin-bottom: .35rem;
  transition: all .2s;
}
.schedule-subject-ongoing {
  border-color: var(--primary);
  background: rgba(99,102,241,.06);
  box-shadow: 0 0 0 1px rgba(99,102,241,.15);
}
.schedule-subject-missed {
  opacity: .65;
}
.live-dot {
  display: inline-block;
  width: 7px; height: 7px;
  background: #22c55e;
  border-radius: 50%;
  margin-left: 3px;
  vertical-align: middle;
  animation: pulse 1.5s infinite;
}
@keyframes pulse {
  0%, 100% { opacity: 1; transform: scale(1); }
  50%       { opacity: .5; transform: scale(.85); }
}
@media (max-width: 900px) {
  .schedule-week-grid { grid-template-columns: repeat(3, 1fr); }
}
@media (max-width: 600px) {
  .schedule-week-grid { grid-template-columns: 1fr 1fr; }
}
</style>

</main>
<script>
document.querySelectorAll('.alert').forEach(a => {
  setTimeout(()=>{ a.style.opacity='0'; a.style.transition='opacity .5s'; setTimeout(()=>a.remove(),500); }, 4000);
});
</script>
</body>
</html>
