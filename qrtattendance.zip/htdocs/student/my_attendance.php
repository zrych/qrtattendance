<?php
require_once __DIR__ . '/../includes/auth.php';
User::requireLogin('student');

$studentClass    = new Student();
$attendanceClass = new Attendance();

$student = $studentClass->findByUserId((int)$_SESSION['user_id']);
if (!$student) { User::logout(); }

$filterStatus = clean($_GET['status'] ?? '');
$allRecords   = $attendanceClass->getAll([
    'student_id' => $student['id'],
    'status'     => $filterStatus,
]);

$rate         = $attendanceClass->studentRate($student['id']);
$totalPresent = count(array_filter($allRecords, fn($r) => $r['status'] === 'present'));
$totalLate    = count(array_filter($allRecords, fn($r) => $r['status'] === 'late'));
$totalAbsent  = count(array_filter($allRecords, fn($r) => $r['status'] === 'absent'));
$totalAuto    = count(array_filter($allRecords, fn($r) => str_contains($r['notes'] ?? '', 'Auto timed-out')));

$pageTitle = 'My Attendance';
$activeNav = 'attendance';
require_once __DIR__ . '/../includes/header_student.php';
?>

<div style="max-width:900px;margin:0 auto">

  <div style="margin-bottom:1.5rem">
    <h1 style="font-size:1.4rem;font-weight:800;color:var(--st-text)">My Attendance History</h1>
    <p style="color:var(--st-muted)">
      <?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?> &nbsp;·&nbsp;
      <?= htmlspecialchars($student['student_number']) ?>
    </p>
  </div>

  <!-- Summary stats -->
  <div class="stat-cards mb-2" style="grid-template-columns:repeat(4,1fr);margin-bottom:1.2rem">
    <div class="stat-card stat-card-light">
      <div class="stat-icon stat-icon-primary"><i class="fa-solid fa-chart-pie"></i></div>
      <div class="stat-info">
        <div class="stat-label">Rate</div>
        <div class="stat-value"><?= $rate ?>%</div>
      </div>
    </div>
    <div class="stat-card stat-card-light">
      <div class="stat-icon stat-icon-success"><i class="fa-solid fa-check"></i></div>
      <div class="stat-info">
        <div class="stat-label">Present</div>
        <div class="stat-value"><?= $totalPresent ?></div>
      </div>
    </div>
    <div class="stat-card stat-card-light">
      <div class="stat-icon stat-icon-warning"><i class="fa-solid fa-clock"></i></div>
      <div class="stat-info">
        <div class="stat-label">Late</div>
        <div class="stat-value"><?= $totalLate ?></div>
      </div>
    </div>
    <div class="stat-card stat-card-light">
      <div class="stat-icon stat-icon-danger"><i class="fa-solid fa-xmark"></i></div>
      <div class="stat-info">
        <div class="stat-label">Absent</div>
        <div class="stat-value"><?= $totalAbsent ?></div>
      </div>
    </div>
  </div>

  <!-- Auto-timeout notice (shown only if any exist) -->
  <?php if ($totalAuto > 0): ?>
  <div style="
    background:rgba(245,158,11,.08);
    border:1.5px solid rgba(245,158,11,.25);
    border-radius:var(--radius);
    padding:.8rem 1.1rem;
    margin-bottom:1.2rem;
    display:flex;align-items:center;gap:.8rem">
    <i class="fa-solid fa-robot" style="color:#f59e0b;font-size:1rem;flex-shrink:0"></i>
    <div style="font-size:.85rem;color:var(--st-text)">
      <strong><?= $totalAuto ?> record<?= $totalAuto > 1 ? 's' : '' ?></strong>
      were auto timed-out because you did not scan out before class ended.
      Your attendance status for these records is still counted normally.
      Contact your instructor if you believe this is an error.
    </div>
  </div>
  <?php endif; ?>

  <!-- Attendance Rate Bar -->
  <div class="card card-light mb-2" style="margin-bottom:1.2rem">
    <div class="card-body">
      <div style="display:flex;justify-content:space-between;margin-bottom:.5rem">
        <span style="font-size:.85rem;font-weight:600;color:var(--st-text)">Overall Attendance Rate</span>
        <span style="font-size:.85rem;font-weight:700;color:<?= $rate >= 75 ? 'var(--success)' : ($rate >= 50 ? 'var(--warning)' : 'var(--danger)') ?>">
          <?= $rate ?>%
          <?php if ($rate < 75): ?>
            <span style="font-weight:400;font-size:.78rem">(⚠ Below 75% threshold)</span>
          <?php endif; ?>
        </span>
      </div>
      <div style="background:var(--st-bg);border-radius:20px;height:10px;overflow:hidden">
        <div style="
          width:<?= $rate ?>%;
          height:100%;border-radius:20px;
          background:<?= $rate >= 75 ? 'var(--success)' : ($rate >= 50 ? 'var(--warning)' : 'var(--danger)') ?>;
          transition:width .8s ease"></div>
      </div>
    </div>
  </div>

  <!-- Filter + Table -->
  <div class="card card-light">
    <div class="card-header">
      <h3><i class="fa-solid fa-calendar-check" style="color:var(--primary)"></i>&nbsp; Attendance Log</h3>
      <form method="GET" style="display:flex;gap:.5rem">
        <select name="status" class="form-control" style="width:auto;font-size:.82rem;padding:.35rem .7rem">
          <option value="">All</option>
          <option value="present" <?= $filterStatus==='present'?'selected':'' ?>>Present</option>
          <option value="late"    <?= $filterStatus==='late'   ?'selected':'' ?>>Late</option>
          <option value="absent"  <?= $filterStatus==='absent' ?'selected':'' ?>>Absent</option>
        </select>
        <button type="submit" class="btn btn-primary btn-sm">
          <i class="fa-solid fa-filter"></i>
        </button>
        <?php if ($filterStatus): ?>
          <a href="<?= BASE_URL ?>/student/my_attendance.php" class="btn btn-secondary btn-sm">Clear</a>
        <?php endif; ?>
      </form>
    </div>
    <div class="card-body" style="padding:0">
      <?php if (empty($allRecords)): ?>
        <div class="empty-state">
          <div class="empty-icon" style="color:var(--st-muted)">📅</div>
          <h3 style="color:var(--st-muted)">No records found</h3>
          <p style="color:var(--st-muted)">Your attendance will appear here after being scanned.</p>
        </div>
      <?php else: ?>
        <div class="table-wrapper">
          <table class="table table-light">
            <thead>
              <tr>
                <th>#</th>
                <th>Date</th>
                <th>Day</th>
                <th>Subject</th>
                <th>Time In</th>
                <th>Time Out</th>
                <th>Hours</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($allRecords as $i => $r):
                $isAutoTimeout = str_contains($r['notes'] ?? '', 'Auto timed-out');
                // Duration — auto-timeout records show class hours, manual shows actual
                $duration = '';
                if ($r['time_in'] && $r['time_out']) {
                    $diff = strtotime($r['time_out']) - strtotime($r['time_in']);
                    $hrs  = floor($diff / 3600);
                    $mins = floor(($diff % 3600) / 60);
                    $duration = $hrs . 'h ' . $mins . 'm';
                }
              ?>
              <tr>
                <td style="color:var(--st-muted)"><?= $i + 1 ?></td>
                <td>
                  <strong><?= date('M j, Y', strtotime($r['date'])) ?></strong>
                  <?php if ($r['date'] === date('Y-m-d')): ?>
                    <span class="badge badge-info" style="margin-left:.3rem;font-size:.68rem">Today</span>
                  <?php endif; ?>
                </td>
                <td style="color:var(--st-muted)"><?= date('D', strtotime($r['date'])) ?></td>
                <td style="font-size:.82rem;color:var(--st-muted)">
                  <?= htmlspecialchars($r['subject_code'] ?? '—') ?>
                </td>
                <td><?= $r['time_in'] ? date('h:i A', strtotime($r['time_in'])) : '—' ?></td>
                <td>
                  <?php if ($r['time_out'] && $isAutoTimeout): ?>
                    <span style="color:#f59e0b">
                      <?= date('h:i A', strtotime($r['time_out'])) ?>
                    </span>
                    <div style="font-size:.68rem;color:#f59e0b">
                      <i class="fa-solid fa-robot"></i> auto
                    </div>
                  <?php elseif ($r['time_out']): ?>
                    <?= date('h:i A', strtotime($r['time_out'])) ?>
                  <?php else: ?>
                    <span style="color:var(--st-muted)">—</span>
                  <?php endif; ?>
                </td>
                <td style="color:var(--st-muted);font-size:.82rem">
                  <?= $duration ?: '—' ?>
                  <?php if ($isAutoTimeout && $duration): ?>
                    <div style="font-size:.68rem;color:#f59e0b">class hours</div>
                  <?php endif; ?>
                </td>
                <td>
                  <?php if ($r['status'] === 'present'): ?>
                    <span class="badge badge-success"><i class="fa-solid fa-check"></i> Present</span>
                  <?php elseif ($r['status'] === 'late'): ?>
                    <span class="badge badge-warning"><i class="fa-solid fa-clock"></i> Late</span>
                  <?php else: ?>
                    <span class="badge badge-danger"><i class="fa-solid fa-xmark"></i> Absent</span>
                  <?php endif; ?>
                  <?php if ($isAutoTimeout): ?>
                    <span style="
                      display:inline-block;
                      margin-left:.35rem;
                      background:rgba(239,68,68,.1);
                      color:#ef4444;
                      border:1px solid rgba(239,68,68,.3);
                      font-size:.65rem;
                      font-weight:700;
                      padding:.1rem .4rem;
                      border-radius:4px;
                      text-transform:uppercase;
                      letter-spacing:.4px;
                      vertical-align:middle"
                      title="Your time-out was recorded automatically because you did not scan out before class ended.">
                      Invalid
                    </span>
                    <div style="margin-top:.3rem;font-size:.75rem;color:#f59e0b;line-height:1.4">
                      <i class="fa-solid fa-triangle-exclamation"></i>
                      You were auto timed-out at
                      <strong><?= date('h:i A', strtotime($r['time_out'])) ?></strong>
                      — you did not scan out before class ended.
                    </div>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>

</div>

</main>
<script>
document.querySelectorAll('.alert').forEach(a => {
  setTimeout(() => {
    a.style.opacity = '0';
    a.style.transition = 'opacity .5s';
    setTimeout(() => a.remove(), 500);
  }, 4000);
});
</script>
</body>
</html>