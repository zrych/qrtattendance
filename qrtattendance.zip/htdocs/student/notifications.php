<?php
require_once __DIR__ . '/../includes/auth.php';
User::requireLogin('student');

$studentClass  = new Student();
$subjectClass  = new Subject();
$notifClass    = new Notification();

$student = $studentClass->findByUserId((int)$_SESSION['user_id']);
if (!$student) { User::logout(); }

// ── POST Handlers ─────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['post_action'] ?? '';

    // Accept invite and enroll
    if ($act === 'enroll') {
        $subjectId = (int)($_POST['subject_id'] ?? 0);
        $password  = $_POST['enrollment_password'] ?? '';
        $result    = $subjectClass->studentEnroll($subjectId, (int)$student['id'], $password);
        if ($result['success']) {
            setFlash('success', $result['message']);
        } else {
            setFlash('danger', $result['message']);
        }
        redirect('student/notifications.php');
    }

    // Mark all pending as read
    if ($act === 'mark_all_read') {
        $notifClass->markAllRead((int)$student['id']);
        setFlash('success', 'All notifications marked as read.');
        redirect('student/notifications.php');
    }

    // Delete a single notification
    if ($act === 'delete_notification') {
        $notifId = (int)($_POST['notification_id'] ?? 0);
        $notifClass->deleteNotification($notifId, (int)$student['id']);
        setFlash('success', 'Notification removed.');
        redirect('student/notifications.php');
    }
}

// Mark as read when the notification is opened (individual read tracking)
// We do NOT auto-mark-all on page load — that's now a button.
// We do mark individual ones read as the page renders.
$notifClass->markAllRead((int)$student['id']); // marks is_read only, not status

// ── Load data ──────────────────────────────────────────────────
$pending           = $notifClass->getPending((int)$student['id']);
$accepted          = $notifClass->getAccepted((int)$student['id']);
$availableSubjects = $notifClass->getAvailableSubjects((int)$student['id']);
$enrolledSubjects  = $subjectClass->getByStudent((int)$student['id']);

$pageTitle = 'Subjects';
$activeNav = 'notifications';
require_once __DIR__ . '/../includes/header_student.php';
$flash = getFlash();
?>

<?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] ?>">
    <i class="fa-solid fa-circle-info"></i> <?= htmlspecialchars($flash['msg']) ?>
  </div>
<?php endif; ?>

<!-- Page header -->
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;flex-wrap:wrap;gap:.7rem">
  <div>
    <h1 style="font-size:1.5rem;font-weight:800;color:var(--st-text)">Subjects &amp; Enrollment</h1>
    <p style="color:var(--st-muted)">Manage your enrolled subjects and accept course invitations.</p>
  </div>
  <?php if (!empty($pending)): ?>
    <form method="POST">
      <input type="hidden" name="post_action" value="mark_all_read">
      <button type="submit" class="btn btn-outline btn-sm">
        <i class="fa-solid fa-check-double"></i> Mark All as Read
      </button>
    </form>
  <?php endif; ?>
</div>

<!-- ═══ PENDING INVITATIONS ══════════════════════════════════ -->
<?php if (!empty($pending)): ?>
<div style="margin-bottom:1.8rem">
  <div style="display:flex;align-items:center;gap:.7rem;margin-bottom:1rem">
    <h2 style="font-size:1.05rem;font-weight:700;color:var(--st-text)">
      <i class="fa-solid fa-bell" style="color:#f59e0b"></i>&nbsp; Pending Invitations
    </h2>
    <span class="badge badge-warning"><?= count($pending) ?></span>
  </div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1rem">
    <?php foreach ($pending as $inv):
      $open = (bool)($inv['enrollment_open'] ?? false);
    ?>
    <div style="background:var(--st-surface);border:2px solid <?= $open ? 'rgba(99,102,241,.35)' : 'var(--st-border)' ?>;border-radius:var(--radius);padding:1.2rem;position:relative">

      <!-- Close/Delete button -->
      <form method="POST" style="position:absolute;top:.6rem;right:.6rem">
        <input type="hidden" name="post_action"     value="delete_notification">
        <input type="hidden" name="notification_id" value="<?= $inv['id'] ?>">
        <button type="submit" title="Dismiss this invitation"
          style="background:none;border:none;cursor:pointer;color:var(--st-muted);font-size:.85rem;padding:.2rem .4rem;border-radius:4px"
          onmouseover="this.style.color='#ef4444'" onmouseout="this.style.color='var(--st-muted)'">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </form>

      <div style="display:flex;align-items:flex-start;gap:.8rem;margin-bottom:.9rem;padding-right:1.5rem">
        <div style="width:42px;height:42px;background:rgba(99,102,241,.1);border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0">
          <i class="fa-solid fa-book-open" style="color:var(--primary)"></i>
        </div>
        <div>
          <div style="font-weight:800;color:var(--st-text);font-size:.95rem">
            <?= htmlspecialchars($inv['code']) ?> — <?= htmlspecialchars($inv['name']) ?>
          </div>
          <div style="font-size:.8rem;color:var(--st-muted);margin-top:.2rem">
            <?= $inv['day_of_week'] ?>,
            <?= date('h:i A', strtotime($inv['time_start'])) ?> –
            <?= date('h:i A', strtotime($inv['time_end'])) ?>
            <?php if ($inv['room']): ?> · <?= htmlspecialchars($inv['room']) ?><?php endif; ?>
          </div>
          <?php if ($inv['instructor']): ?>
            <div style="font-size:.78rem;color:var(--st-muted)">
              <i class="fa-solid fa-chalkboard-user"></i> <?= htmlspecialchars($inv['instructor']) ?>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <div style="display:flex;gap:.5rem;font-size:.72rem;margin-bottom:.9rem;flex-wrap:wrap">
        <span style="background:rgba(16,185,129,.1);color:#059669;padding:.2rem .55rem;border-radius:999px;font-weight:600">
          ✓ Present ≤<?= (int)($inv['late_minutes']??15) ?>m
        </span>
        <span style="background:rgba(245,158,11,.1);color:#d97706;padding:.2rem .55rem;border-radius:999px;font-weight:600">
          ⏰ Late ≤<?= (int)($inv['absent_minutes']??45) ?>m
        </span>
      </div>

      <?php if ($open): ?>
        <button class="btn btn-primary" style="width:100%;justify-content:center"
          onclick="openEnroll(<?= $inv['subject_id'] ?>, '<?= htmlspecialchars(addslashes($inv['code'].' — '.$inv['name'])) ?>')">
          <i class="fa-solid fa-right-to-bracket"></i> Enroll Now
        </button>
      <?php else: ?>
        <div style="text-align:center;color:var(--st-muted);font-size:.85rem;padding:.4rem;background:var(--st-bg);border-radius:var(--radius-sm)">
          <i class="fa-solid fa-lock"></i> Enrollment is currently closed
        </div>
      <?php endif; ?>

    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<!-- ═══ MY ENROLLED SUBJECTS ════════════════════════════════ -->
<div class="card card-light" style="margin-bottom:1.5rem">
  <div class="card-header">
    <h3>
      <i class="fa-solid fa-graduation-cap" style="color:var(--primary)"></i>&nbsp;
      My Enrolled Subjects
      <span class="badge badge-primary" style="margin-left:.5rem"><?= count($enrolledSubjects) ?></span>
    </h3>
  </div>
  <div class="card-body" style="padding:0">
    <?php if (empty($enrolledSubjects)): ?>
      <div class="empty-state">
        <div class="empty-icon">📚</div>
        <h3 style="color:var(--st-muted)">No subjects yet</h3>
        <p style="color:var(--st-muted)">Enroll in a subject below or accept an invitation.</p>
      </div>
    <?php else: ?>
      <div class="table-wrapper">
        <table class="table table-light">
          <thead><tr><th>Code</th><th>Subject</th><th>Schedule</th><th>Room</th><th>Instructor</th><th>Time Rules</th></tr></thead>
          <tbody>
            <?php foreach ($enrolledSubjects as $s): ?>
            <tr>
              <td><strong style="color:var(--primary);font-family:monospace"><?= htmlspecialchars($s['code']) ?></strong></td>
              <td><?= htmlspecialchars($s['name']) ?></td>
              <td>
                <div style="font-weight:600"><?= $s['day_of_week'] ?></div>
                <div style="font-size:.78rem;color:var(--st-muted)"><?= date('h:i A',strtotime($s['time_start'])) ?> – <?= date('h:i A',strtotime($s['time_end'])) ?></div>
              </td>
              <td style="color:var(--st-muted);font-size:.85rem"><?= htmlspecialchars($s['room'])?:'—' ?></td>
              <td style="color:var(--st-muted);font-size:.85rem"><?= htmlspecialchars($s['instructor'])?:'—' ?></td>
              <td style="font-size:.75rem">
                <span style="color:#10b981">✓ ≤<?= (int)($s['late_minutes']??15) ?>m</span>
                <span style="color:#f59e0b"> · ⏰ ≤<?= (int)($s['absent_minutes']??45) ?>m</span>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- ═══ AVAILABLE SUBJECTS ═══════════════════════════════════ -->
<?php if (!empty($availableSubjects)): ?>
<div style="margin-bottom:1.5rem">
  <div style="display:flex;align-items:center;gap:.7rem;margin-bottom:1rem">
    <h2 style="font-size:1.05rem;font-weight:700;color:var(--st-text)">
      <i class="fa-solid fa-magnifying-glass" style="color:var(--primary)"></i>&nbsp; Available Subjects
    </h2>
    <span class="badge badge-secondary"><?= count($availableSubjects) ?></span>
  </div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1rem">
    <?php foreach ($availableSubjects as $sub): ?>
    <div style="background:var(--st-surface);border:1.5px solid var(--st-border);border-radius:var(--radius);padding:1.2rem;position:relative">

      <?php if ($sub['has_notification']): ?>
        <div style="position:absolute;top:0;right:0;background:var(--primary);color:#fff;font-size:.62rem;font-weight:700;padding:.25rem .7rem;border-radius:0 var(--radius) 0 10px">INVITED</div>
      <?php endif; ?>

      <div style="display:flex;align-items:flex-start;gap:.8rem;margin-bottom:.9rem">
        <div style="width:42px;height:42px;background:rgba(99,102,241,.08);border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0">
          <i class="fa-solid fa-book" style="color:var(--primary)"></i>
        </div>
        <div>
          <div style="font-weight:800;color:var(--st-text);font-size:.95rem"><?= htmlspecialchars($sub['code']) ?> — <?= htmlspecialchars($sub['name']) ?></div>
          <div style="font-size:.8rem;color:var(--st-muted);margin-top:.2rem">
            <?= $sub['day_of_week'] ?>, <?= date('h:i A',strtotime($sub['time_start'])) ?> – <?= date('h:i A',strtotime($sub['time_end'])) ?>
            <?php if ($sub['room']): ?> · <?= htmlspecialchars($sub['room']) ?><?php endif; ?>
          </div>
          <?php if ($sub['instructor']): ?><div style="font-size:.78rem;color:var(--st-muted)"><i class="fa-solid fa-chalkboard-user"></i> <?= htmlspecialchars($sub['instructor']) ?></div><?php endif; ?>
        </div>
      </div>

      <div style="display:flex;gap:.5rem;font-size:.72rem;margin-bottom:.9rem;flex-wrap:wrap">
        <span style="background:rgba(16,185,129,.1);color:#059669;padding:.2rem .55rem;border-radius:999px;font-weight:600">✓ Present ≤<?= (int)($sub['late_minutes']??15) ?>m</span>
        <span style="background:rgba(245,158,11,.1);color:#d97706;padding:.2rem .55rem;border-radius:999px;font-weight:600">⏰ Late ≤<?= (int)($sub['absent_minutes']??45) ?>m</span>
      </div>

      <button class="btn btn-outline" style="width:100%;justify-content:center"
        onclick="openEnroll(<?= $sub['id'] ?>, '<?= htmlspecialchars(addslashes($sub['code'].' — '.$sub['name'])) ?>')">
        <i class="fa-solid fa-right-to-bracket"></i> Enroll with Code
      </button>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<!-- ═══ ENROLLMENT HISTORY ════════════════════════════════════ -->
<?php if (!empty($accepted)): ?>
<div style="margin-bottom:1.5rem">
  <div style="display:flex;align-items:center;gap:.7rem;margin-bottom:.8rem">
    <h2 style="font-size:1.05rem;font-weight:700;color:var(--st-text)">
      <i class="fa-solid fa-clock-rotate-left" style="color:var(--st-muted)"></i>&nbsp; Enrollment History
    </h2>
    <span class="badge badge-secondary"><?= count($accepted) ?></span>
  </div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:.7rem">
    <?php foreach ($accepted as $a): ?>
    <div style="background:var(--st-bg);border:1px solid var(--st-border);border-radius:var(--radius-sm);padding:.85rem 1rem;display:flex;align-items:center;gap:.8rem;position:relative">
      <div style="width:34px;height:34px;background:#dcfce7;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0">
        <i class="fa-solid fa-circle-check" style="color:#16a34a;font-size:.9rem"></i>
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:700;font-size:.85rem;color:var(--st-text)"><?= htmlspecialchars($a['code']) ?></div>
        <div style="font-size:.75rem;color:var(--st-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($a['name']) ?></div>
        <?php if ($a['accepted_at']): ?>
          <div style="font-size:.7rem;color:var(--st-muted)">Joined <?= date('M j, Y', strtotime($a['accepted_at'])) ?></div>
        <?php endif; ?>
      </div>
      <!-- Delete from history -->
      <form method="POST">
        <input type="hidden" name="post_action"     value="delete_notification">
        <input type="hidden" name="notification_id" value="<?= $a['id'] ?>">
        <button type="submit" title="Remove from history"
          style="background:none;border:none;cursor:pointer;color:var(--st-muted);font-size:.8rem;padding:.2rem"
          onmouseover="this.style.color='#ef4444'" onmouseout="this.style.color='var(--st-muted)'">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </form>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<!-- ═══ ENROLL MODAL ══════════════════════════════════════════ -->
<div id="enrollModal" style="display:none;position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.5);backdrop-filter:blur(4px);align-items:center;justify-content:center">
  <div style="background:var(--st-surface);border-radius:20px;padding:2rem;max-width:380px;width:90%;box-shadow:0 20px 60px rgba(0,0,0,.3);animation:slideUp .3s cubic-bezier(.34,1.56,.64,1)">
    <div style="text-align:center;margin-bottom:1.3rem">
      <div style="width:52px;height:52px;background:rgba(99,102,241,.1);border-radius:14px;display:inline-flex;align-items:center;justify-content:center;font-size:1.4rem;margin-bottom:.8rem">🔐</div>
      <h3 style="font-size:1.1rem;font-weight:800;color:var(--st-text);margin:0 0 .3rem">Enroll in Subject</h3>
      <p id="enrollSubjectName" style="font-size:.85rem;color:var(--st-muted);margin:0"></p>
    </div>
    <form method="POST" id="enrollForm">
      <input type="hidden" name="post_action" value="enroll">
      <input type="hidden" name="subject_id"  id="enrollSubjectId">
      <div style="margin-bottom:1.2rem">
        <label style="display:block;font-size:.85rem;font-weight:600;color:var(--st-text);margin-bottom:.5rem">Enrollment Code</label>
        <div style="position:relative">
          <input type="password" name="enrollment_password" id="enrollPwInput"
            class="form-control" placeholder="Enter the code given by your instructor"
            style="padding-right:2.5rem" required autocomplete="off">
          <button type="button" onclick="toggleEnrollPw()"
            style="position:absolute;right:.7rem;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:var(--st-muted);font-size:.9rem">
            <i class="fa-solid fa-eye" id="enrollPwEye"></i>
          </button>
        </div>
      </div>
      <div style="display:flex;gap:.7rem">
        <button type="button" class="btn btn-secondary" style="flex:1;justify-content:center" onclick="closeEnroll()">Cancel</button>
        <button type="submit" class="btn btn-primary" style="flex:1;justify-content:center">
          <i class="fa-solid fa-right-to-bracket"></i> Enroll
        </button>
      </div>
    </form>
  </div>
</div>

<style>
@keyframes slideUp {
  from { transform: translateY(30px) scale(.96); opacity:0 }
  to   { transform: translateY(0) scale(1); opacity:1 }
}
</style>

<script>
const enrollModal = document.getElementById('enrollModal');
function openEnroll(id, name) {
  document.getElementById('enrollSubjectId').value   = id;
  document.getElementById('enrollSubjectName').textContent = name;
  document.getElementById('enrollPwInput').value     = '';
  enrollModal.style.display = 'flex';
  setTimeout(() => document.getElementById('enrollPwInput').focus(), 100);
}
function closeEnroll() { enrollModal.style.display = 'none'; }
function toggleEnrollPw() {
  const inp = document.getElementById('enrollPwInput');
  const eye = document.getElementById('enrollPwEye');
  inp.type  = inp.type === 'password' ? 'text' : 'password';
  eye.className = inp.type === 'password' ? 'fa-solid fa-eye' : 'fa-solid fa-eye-slash';
}
enrollModal.addEventListener('click', e => { if (e.target===enrollModal) closeEnroll(); });
document.addEventListener('keydown',  e => { if (e.key==='Escape') closeEnroll(); });
</script>

</main>
<script>
document.querySelectorAll('.alert').forEach(a => {
  setTimeout(()=>{ a.style.opacity='0'; a.style.transition='opacity .5s'; setTimeout(()=>a.remove(),500); }, 4000);
});
</script>
</body>
</html>
