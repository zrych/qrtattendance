<?php
// ============================================================
//  classes/User.php — Authentication & User Management
// ============================================================

class User {
    private Database $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    // ── Authentication ────────────────────────────────────────

    /**
     * Attempt login; returns user array on success, false on failure.
     */
    public function login(string $username, string $password): array|false {
        $row = $this->db->query(
            'SELECT * FROM users WHERE username = ? AND is_active = 1',
            [trim($username)]
        )->fetch();

        if ($row && password_verify($password, $row['password'])) {
            return $row;
        }
        return false;
    }

    /**
     * Start a user session after successful login.
     */
    public static function startSession(array $user): void {
        if (session_status() === PHP_SESSION_NONE) session_start();
        session_regenerate_id(true);
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role']     = $user['role'];
        $_SESSION['logged_in']= true;
        $_SESSION['login_time'] = time();
    }

    /**
     * Destroy session and redirect to login.
     */
    public static function logout(): void {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $_SESSION = [];
        session_destroy();
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }

    /**
     * Require a valid session; redirect if not logged in.
     * @param string|null $requiredRole 'admin' | 'student' | null (any)
     */
    public static function requireLogin(?string $requiredRole = null): void {
        if (session_status() === PHP_SESSION_NONE) session_start();

        if (empty($_SESSION['logged_in'])) {
            header('Location: ' . BASE_URL . '/login.php');
            exit;
        }
        if ($requiredRole && $_SESSION['role'] !== $requiredRole) {
            // Wrong role — send to their own dashboard
            if ($_SESSION['role'] === 'admin') {
                header('Location: ' . BASE_URL . '/admin/dashboard.php');
            } else {
                header('Location: ' . BASE_URL . '/student/dashboard.php');
            }
            exit;
        }
    }

    // ── CRUD ─────────────────────────────────────────────────

    /** Create a new user; returns new user ID. */
    public function create(string $username, string $password, string $role = 'student'): int {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $this->db->query(
            'INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
            [$username, $hash, $role]
        );
        return (int)$this->db->lastInsertId();
    }

    /** Update a user's password. */
    public function updatePassword(int $userId, string $newPassword): bool {
        $hash = password_hash($newPassword, PASSWORD_BCRYPT);
        $this->db->query(
            'UPDATE users SET password = ? WHERE id = ?',
            [$hash, $userId]
        );
        return true;
    }

    /** Toggle active status. */
    public function setActive(int $userId, bool $active): void {
        $this->db->query(
            'UPDATE users SET is_active = ? WHERE id = ?',
            [(int)$active, $userId]
        );
    }

    /** Delete a user (cascades to student & attendance). */
    public function delete(int $userId): void {
        $this->db->query('DELETE FROM users WHERE id = ?', [$userId]);
    }

    /** Check whether a username already exists. */
    public function usernameExists(string $username, int $excludeId = 0): bool {
        $row = $this->db->query(
            'SELECT id FROM users WHERE username = ? AND id != ?',
            [$username, $excludeId]
        )->fetch();
        return (bool)$row;
    }

    /** Fetch a single user by ID. */
    public function findById(int $id): array|false {
        return $this->db->query('SELECT * FROM users WHERE id = ?', [$id])->fetch();
    }

    /** Get a system setting value. */
    public static function getSetting(string $key): ?string {
        $db  = Database::getInstance();
        $row = $db->query('SELECT setting_value FROM settings WHERE setting_key = ?', [$key])->fetch();
        return $row ? $row['setting_value'] : null;
    }

    /** Update a system setting. */
    public static function setSetting(string $key, string $value): void {
        $db = Database::getInstance();
        $db->query(
            'INSERT INTO settings (setting_key, setting_value) VALUES (?,?)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)',
            [$key, $value]
        );
    }
}
