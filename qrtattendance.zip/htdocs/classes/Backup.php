<?php
// ============================================================
//  classes/Backup.php — CSV Export & Auto-Backup
// ============================================================

class Backup {
    private Database $db;
    private string   $backupDir;

    public function __construct() {
        $this->db        = Database::getInstance();
        $this->backupDir = __DIR__ . '/../backups/';
        if (!is_dir($this->backupDir)) {
            mkdir($this->backupDir, 0755, true);
        }
    }

    // ── CSV Export ────────────────────────────────────────────

    /**
     * Stream attendance CSV directly to browser.
     * Clears all output buffers first (fixes InfinityFree header conflicts).
     * Filters: date_from, date_to, subject_id, status, student_id
     */
    public function streamAttendanceCSV(array $filters = []): void {
        // Flush all output buffers so nothing corrupts the CSV stream
        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        $sql    = 'SELECT
                     a.date,
                     DAYNAME(a.date)                          AS day_of_week,
                     s.student_number,
                     s.last_name,
                     s.first_name,
                     s.course,
                     s.year_level,
                     s.section,
                     COALESCE(sub.code, "—")                 AS subject_code,
                     COALESCE(sub.name, "—")                 AS subject_name,
                     TIME_FORMAT(a.time_in,  "%h:%i %p")     AS time_in,
                     TIME_FORMAT(a.time_out, "%h:%i %p")     AS time_out,
                     a.status,
                     COALESCE(a.notes, "")                   AS notes
                   FROM attendance a
                   JOIN students s   ON s.id  = a.student_id
                   LEFT JOIN subjects sub ON sub.id = a.subject_id
                   WHERE 1=1';
        $params = [];

        if (!empty($filters['date_from'])) {
            $sql .= ' AND a.date >= ?'; $params[] = $filters['date_from'];
        }
        if (!empty($filters['date_to'])) {
            $sql .= ' AND a.date <= ?'; $params[] = $filters['date_to'];
        }
        if (!empty($filters['subject_id'])) {
            $sql .= ' AND a.subject_id = ?'; $params[] = $filters['subject_id'];
        }
        if (!empty($filters['status'])) {
            $sql .= ' AND a.status = ?'; $params[] = $filters['status'];
        }
        if (!empty($filters['student_id'])) {
            $sql .= ' AND a.student_id = ?'; $params[] = $filters['student_id'];
        }

        $sql .= ' ORDER BY a.date DESC, s.last_name, s.first_name';
        $rows  = $this->db->query($sql, $params)->fetchAll();

        $filename = 'attendance_' . date('Y-m-d_His') . '.csv';

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Expires: 0');

        $out = fopen('php://output', 'w');

        // UTF-8 BOM for Excel
        fputs($out, "\xEF\xBB\xBF");

        // Header row
        fputcsv($out, [
            'Date', 'Day', 'Student No.', 'Last Name', 'First Name',
            'Course', 'Year', 'Section',
            'Subject Code', 'Subject Name',
            'Time In', 'Time Out', 'Status', 'Notes',
        ]);

        foreach ($rows as $r) {
            fputcsv($out, [
                $r['date'],
                $r['day_of_week'],
                $r['student_number'],
                $r['last_name'],
                $r['first_name'],
                $r['course'],
                $r['year_level'],
                $r['section'],
                $r['subject_code'],
                $r['subject_name'],
                $r['time_in']  ?? '—',
                $r['time_out'] ?? '—',
                ucfirst($r['status']),
                $r['notes'],
            ]);
        }

        fclose($out);
        exit;
    }

    // ── Auto / Manual Backup ──────────────────────────────────

    public function generateSQLBackup(string $type = 'manual'): array {
        if ($type === 'auto') {
            $today = $this->db->query(
                "SELECT id FROM backups WHERE type='auto' AND DATE(created_at)=CURDATE()"
            )->fetch();
            if ($today) {
                return ['success' => false, 'message' => 'Auto-backup already completed today.'];
            }
        }

        $tables   = ['users','students','attendance','subjects','subject_students','settings','backups'];
        $filename = 'backup_' . $type . '_' . date('Y-m-d_His') . '.sql';
        $filepath = $this->backupDir . $filename;

        $sql  = "-- QR Attendance System Backup\n";
        $sql .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
        $sql .= "-- Type: $type\n\n";
        $sql .= "SET FOREIGN_KEY_CHECKS=0;\n\n";

        foreach ($tables as $table) {
            try {
                $create = $this->db->query("SHOW CREATE TABLE `$table`")->fetch();
                if (!$create) continue;

                $sql .= "-- Table: $table\n";
                $sql .= "DROP TABLE IF EXISTS `$table`;\n";
                $sql .= $create['Create Table'] . ";\n\n";

                $rows = $this->db->query("SELECT * FROM `$table`")->fetchAll();
                if (!empty($rows)) {
                    $cols   = '`' . implode('`,`', array_keys($rows[0])) . '`';
                    $sql   .= "INSERT INTO `$table` ($cols) VALUES\n";
                    $chunks = [];
                    foreach ($rows as $row) {
                        $vals = array_map(function($v) {
                            if ($v === null) return 'NULL';
                            return "'" . addslashes($v) . "'";
                        }, array_values($row));
                        $chunks[] = '(' . implode(',', $vals) . ')';
                    }
                    $sql .= implode(",\n", $chunks) . ";\n\n";
                }
            } catch (Exception $e) {
                $sql .= "-- Skipped table $table: " . $e->getMessage() . "\n\n";
            }
        }

        $sql .= "SET FOREIGN_KEY_CHECKS=1;\n";

        $written = file_put_contents($filepath, $sql);
        if ($written === false) {
            return ['success' => false, 'message' => 'Could not write backup file. Check folder permissions.'];
        }

        $this->db->query(
            'INSERT INTO backups (filename, size_bytes, type) VALUES (?,?,?)',
            [$filename, filesize($filepath), $type]
        );

        return [
            'success'  => true,
            'filename' => $filename,
            'filepath' => $filepath,
            'size'     => $this->formatBytes(filesize($filepath)),
            'message'  => ucfirst($type) . ' backup created: ' . $filename,
        ];
    }

    public function downloadBackup(string $filename): void {
        $filepath = $this->backupDir . basename($filename);
        if (!file_exists($filepath)) {
            die('Backup file not found.');
        }
        while (ob_get_level() > 0) ob_end_clean();
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($filepath) . '"');
        header('Content-Length: ' . filesize($filepath));
        header('Pragma: no-cache');
        readfile($filepath);
        exit;
    }

    public function deleteBackup(int $id): bool {
        $row = $this->db->query('SELECT filename FROM backups WHERE id=?', [$id])->fetch();
        if (!$row) return false;
        $filepath = $this->backupDir . $row['filename'];
        if (file_exists($filepath)) unlink($filepath);
        $this->db->query('DELETE FROM backups WHERE id=?', [$id]);
        return true;
    }

    public function getAll(): array {
        return $this->db->query('SELECT * FROM backups ORDER BY created_at DESC')->fetchAll();
    }

    public function pruneOld(int $keep = 7): void {
        foreach (['auto','manual'] as $type) {
            $rows = $this->db->query(
                'SELECT id, filename FROM backups WHERE type=? ORDER BY created_at DESC',
                [$type]
            )->fetchAll();
            $toDelete = array_slice($rows, $keep);
            foreach ($toDelete as $r) {
                $this->deleteBackup((int)$r['id']);
            }
        }
    }

    public static function triggerAutoBackup(): array {
        $b      = new self();
        $result = $b->generateSQLBackup('auto');
        if ($result['success']) {
            $b->pruneOld(7);
        }
        return $result;
    }

    public static function formatBytes(int $bytes): string {
        if ($bytes >= 1048576) return round($bytes / 1048576, 2) . ' MB';
        if ($bytes >= 1024)    return round($bytes / 1024, 1)    . ' KB';
        return $bytes . ' B';
    }
}
