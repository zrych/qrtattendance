<?php
// ============================================================
//  classes/Attendance.php — Attendance CRUD & Statistics
// ============================================================

class Attendance {
    private Database $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    // ── QR Scan ───────────────────────────────────────────────

    /**
     * Process a QR scan event.
     * First scan  → time_in  (status computed from subject thresholds)
     * Second scan → time_out (clears any auto-timeout note)
     */
    public function processScan(string $qrToken, int $scannedBy, ?array $subject = null): array {
        $studentClass = new Student();
        $student      = $studentClass->findByQrToken($qrToken);

        if (!$student) {
            return ['success' => false, 'message' => 'Unknown QR code — student not found.'];
        }

        $today       = date('Y-m-d');
        $currentTime = date('H:i:s');
        $status      = $subject ? Subject::computeStatus($subject) : 'present';
        $subjectId   = $subject ? (int)$subject['id'] : null;

        // Check for existing record today for this student
        $existing = $this->db->query(
            'SELECT * FROM attendance WHERE student_id=? AND date=? LIMIT 1',
            [$student['id'], $today]
        )->fetch();

        if (!$existing) {
            // First scan — record time_in
            $this->db->query(
                'INSERT INTO attendance
                    (student_id, subject_id, date, time_in, status, scanned_by)
                 VALUES (?,?,?,?,?,?)',
                [$student['id'], $subjectId, $today, $currentTime, $status, $scannedBy]
            );
            $subjectLabel = $subject ? " ({$subject['code']})" : '';
            return [
                'success' => true,
                'action'  => 'time_in',
                'status'  => $status,
                'message' => "Time IN recorded for {$student['first_name']} {$student['last_name']}{$subjectLabel}.",
                'student' => $student,
                'subject' => $subject,
                'time'    => $currentTime,
            ];
        }

        if ($existing['time_out'] === null) {
            // Second scan — record time_out
            // If auto-timed-out note exists, clear it (student scanned out manually)
            $notes = $existing['notes'] ?? '';
            if (str_contains($notes, 'Auto timed-out')) {
                $notes = trim(str_replace(
                    array_filter(explode(' | ', $notes), fn($n) => str_contains($n, 'Auto timed-out')),
                    '',
                    $notes
                ));
                $notes = trim($notes, ' |');
            }
            $this->db->query(
                'UPDATE attendance SET time_out=?, notes=? WHERE id=?',
                [$currentTime, $notes, $existing['id']]
            );
            return [
                'success' => true,
                'action'  => 'time_out',
                'status'  => $existing['status'],
                'message' => "Time OUT recorded for {$student['first_name']} {$student['last_name']}.",
                'student' => $student,
                'subject' => $subject,
                'time'    => $currentTime,
            ];
        }

        // Both already recorded
        return [
            'success' => false,
            'message' => "{$student['first_name']} {$student['last_name']} is already fully recorded for today.",
            'student' => $student,
        ];
    }

    // ── Auto-Timeout ──────────────────────────────────────────

    /**
     * Auto-timeout: sets time_out = subject's time_end and writes a note
     * for any attendance record where:
     *   - time_in is set but time_out is NULL
     *   - the linked subject's class has already ended (time_end < NOW())
     *   - the record is from today
     *   - no auto-timeout note already exists (prevents re-processing)
     *
     * Attendance status (present/late/absent) is preserved unchanged.
     * These records still count toward the student's attendance rate.
     *
     * Returns the number of records updated.
     */
    public function autoTimeout(): int {
        try {
            $now   = date('H:i:s');
            $today = date('Y-m-d');

            $records = $this->db->query(
                "SELECT a.id, a.notes, s.time_end
                 FROM attendance a
                 JOIN subjects s ON s.id = a.subject_id
                 WHERE a.date      = ?
                   AND a.time_out  IS NULL
                   AND a.time_in   IS NOT NULL
                   AND s.time_end  < ?
                   AND (a.notes NOT LIKE '%Auto timed-out%' OR a.notes IS NULL)",
                [$today, $now]
            )->fetchAll();

            if (empty($records)) return 0;

            $count = 0;
            foreach ($records as $r) {
                $autoNote      = 'Auto timed-out — class ended at '
                                 . date('h:i A', strtotime($r['time_end']));
                $existingNotes = trim($r['notes'] ?? '');
                $newNotes      = $existingNotes
                                 ? $existingNotes . ' | ' . $autoNote
                                 : $autoNote;

                $this->db->query(
                    'UPDATE attendance SET time_out=?, notes=? WHERE id=?',
                    [$r['time_end'], $newNotes, $r['id']]
                );
                $count++;
            }

            return $count;

        } catch (Throwable $e) {
            return 0;
        }
    }

    // ── Read ──────────────────────────────────────────────────

    public function getAll(array $filters = []): array {
        $sql    = 'SELECT a.*, s.first_name, s.last_name, s.student_number, s.course,
                          sub.code AS subject_code, sub.name AS subject_name
                   FROM attendance a
                   JOIN students s   ON s.id = a.student_id
                   LEFT JOIN subjects sub ON sub.id = a.subject_id
                   WHERE 1=1';
        $params = [];

        if (!empty($filters['date'])) {
            $sql .= ' AND a.date = ?';
            $params[] = $filters['date'];
        }
        if (!empty($filters['student_id'])) {
            $sql .= ' AND a.student_id = ?';
            $params[] = $filters['student_id'];
        }
        if (!empty($filters['status'])) {
            $sql .= ' AND a.status = ?';
            $params[] = $filters['status'];
        }
        if (!empty($filters['search'])) {
            $like    = '%' . $filters['search'] . '%';
            $sql    .= ' AND (s.first_name LIKE ? OR s.last_name LIKE ? OR s.student_number LIKE ?)';
            $params  = array_merge($params, [$like, $like, $like]);
        }

        $sql .= ' ORDER BY a.date DESC, a.time_in DESC';

        if (!empty($filters['limit'])) {
            $sql .= ' LIMIT ' . (int)$filters['limit'];
        }

        return $this->db->query($sql, $params)->fetchAll();
    }

    public function getByStudent(int $studentId, int $limit = 50): array {
        return $this->getAll(['student_id' => $studentId, 'limit' => $limit]);
    }

    public function getToday(): array {
        return $this->getAll(['date' => date('Y-m-d')]);
    }

    public function countToday(): array {
        $rows = $this->db->query(
            "SELECT status, COUNT(*) AS n FROM attendance WHERE date=CURDATE() GROUP BY status"
        )->fetchAll();
        $counts = ['present' => 0, 'late' => 0, 'absent' => 0, 'total' => 0, 'auto_timeout' => 0];
        foreach ($rows as $r) {
            $counts[$r['status']] = (int)$r['n'];
        }
        // Count auto-timed-out records separately (for dashboard info, not penalty)
        $at = $this->db->query(
            "SELECT COUNT(*) AS n FROM attendance
             WHERE date=CURDATE() AND notes LIKE '%Auto timed-out%'"
        )->fetch();
        $counts['auto_timeout'] = (int)($at['n'] ?? 0);
        $counts['total']        = $counts['present'] + $counts['late'] + $counts['absent'];
        return $counts;
    }

    /**
     * Attendance rate: counts Present and Late as attended.
     * Auto-timed-out records are NOT excluded — their status still counts.
     * (A student who was Present but didn't scan out still counts as Present.)
     */
    public function studentRate(int $studentId): float {
        $row = $this->db->query(
            "SELECT COUNT(*) AS total,
                    SUM(status IN ('present','late')) AS attended
             FROM attendance WHERE student_id=?",
            [$studentId]
        )->fetch();
        if (!$row || $row['total'] == 0) return 0.0;
        return round($row['attended'] / $row['total'] * 100, 1);
    }

    public function summaryByStudent(): array {
        return $this->db->query(
            "SELECT s.id, s.student_number, s.first_name, s.last_name, s.course,
                    COUNT(a.id)                AS total_records,
                    SUM(a.status='present')    AS present_count,
                    SUM(a.status='late')       AS late_count,
                    SUM(a.status='absent')     AS absent_count,
                    SUM(a.notes LIKE '%Auto timed-out%') AS auto_timeout_count,
                    MAX(a.date)                AS last_seen
             FROM students s
             LEFT JOIN attendance a ON a.student_id = s.id
             GROUP BY s.id
             ORDER BY s.last_name, s.first_name"
        )->fetchAll();
    }

    // ── Create / Update / Delete ──────────────────────────────

    public function create(array $data): bool {
        $this->db->query(
            'INSERT INTO attendance
                (student_id, subject_id, date, time_in, time_out, status, notes)
             VALUES (?,?,?,?,?,?,?)',
            [
                $data['student_id'],
                $data['subject_id'] ?? null,
                $data['date'],
                $data['time_in']  ?? null,
                $data['time_out'] ?? null,
                $data['status']   ?? 'present',
                $data['notes']    ?? '',
            ]
        );
        return true;
    }

    public function update(int $id, array $data): bool {
        $this->db->query(
            'UPDATE attendance SET time_in=?, time_out=?, status=?, notes=? WHERE id=?',
            [
                $data['time_in']  ?? null,
                $data['time_out'] ?? null,
                $data['status']   ?? 'present',
                $data['notes']    ?? '',
                $id,
            ]
        );
        return true;
    }

    public function delete(int $id): void {
        $this->db->query('DELETE FROM attendance WHERE id=?', [$id]);
    }

    public function findById(int $id): array|false {
        return $this->db->query(
            'SELECT a.*, s.first_name, s.last_name, s.student_number
             FROM attendance a JOIN students s ON s.id=a.student_id
             WHERE a.id=?',
            [$id]
        )->fetch();
    }
}
