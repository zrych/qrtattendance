<?php
// ============================================================
//  classes/Subject.php — Subject / Schedule Management
// ============================================================

class Subject {
    private Database $db;

    public static array $DAYS = [
        'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'
    ];

    public function __construct() {
        $this->db = Database::getInstance();
    }

    // ── CRUD ──────────────────────────────────────────────────

    public function create(array $data): int {
        $pwHash = !empty($data['enrollment_password'])
            ? password_hash(trim($data['enrollment_password']), PASSWORD_BCRYPT)
            : null;

        $this->db->query(
            'INSERT INTO subjects
               (code, name, day_of_week, time_start, time_end, room, instructor,
                late_minutes, absent_minutes, enrollment_password, enrollment_open)
             VALUES (?,?,?,?,?,?,?,?,?,?,?)',
            [
                strtoupper(trim($data['code'])),
                trim($data['name']),
                $data['day_of_week'],
                $data['time_start'],
                $data['time_end'],
                trim($data['room']           ?? ''),
                trim($data['instructor']     ?? ''),
                (int)($data['late_minutes']   ?? 15),
                (int)($data['absent_minutes'] ?? 45),
                $pwHash,
                isset($data['enrollment_open']) ? (int)$data['enrollment_open'] : 1,
            ]
        );
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id, array $data): void {
        // Only re-hash if a new password was explicitly supplied
        if (isset($data['enrollment_password']) && trim($data['enrollment_password']) !== '') {
            $pwHash = password_hash(trim($data['enrollment_password']), PASSWORD_BCRYPT);
        } else {
            // Keep existing hash
            $existing = $this->findById($id);
            $pwHash   = $existing['enrollment_password'] ?? null;
        }

        $this->db->query(
            'UPDATE subjects
             SET code=?, name=?, day_of_week=?, time_start=?, time_end=?,
                 room=?, instructor=?, is_active=?, late_minutes=?, absent_minutes=?,
                 enrollment_password=?, enrollment_open=?
             WHERE id=?',
            [
                strtoupper(trim($data['code'])),
                trim($data['name']),
                $data['day_of_week'],
                $data['time_start'],
                $data['time_end'],
                trim($data['room']           ?? ''),
                trim($data['instructor']     ?? ''),
                isset($data['is_active']) ? (int)$data['is_active'] : 1,
                (int)($data['late_minutes']   ?? 15),
                (int)($data['absent_minutes'] ?? 45),
                $pwHash,
                isset($data['enrollment_open']) ? (int)$data['enrollment_open'] : 1,
                $id,
            ]
        );
    }

    public function delete(int $id): void {
        $this->db->query('DELETE FROM subjects WHERE id=?', [$id]);
    }

    public function getAll(bool $activeOnly = false): array {
        $sql = 'SELECT s.*,
                  (SELECT COUNT(*) FROM subject_students ss WHERE ss.subject_id = s.id) AS enrolled_count
                FROM subjects s';
        if ($activeOnly) $sql .= ' WHERE s.is_active = 1';
        $sql .= ' ORDER BY FIELD(s.day_of_week,"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"), s.time_start';
        return $this->db->query($sql)->fetchAll();
    }

    public function findById(int $id): array|false {
        return $this->db->query(
            'SELECT s.*, (SELECT COUNT(*) FROM subject_students ss WHERE ss.subject_id=s.id) AS enrolled_count
             FROM subjects s WHERE s.id=?',
            [$id]
        )->fetch();
    }

    public function getByStudent(int $studentId): array {
        return $this->db->query(
            'SELECT s.* FROM subjects s
             JOIN subject_students ss ON ss.subject_id = s.id
             WHERE ss.student_id = ? AND s.is_active = 1
             ORDER BY FIELD(s.day_of_week,"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"), s.time_start',
            [$studentId]
        )->fetchAll();
    }

    // ── Enrollment (admin) ────────────────────────────────────

    public function getEnrolledStudents(int $subjectId): array {
        return $this->db->query(
            'SELECT s.*, u.username FROM students s
             JOIN subject_students ss ON ss.student_id = s.id
             JOIN users u ON u.id = s.user_id
             WHERE ss.subject_id = ?
             ORDER BY s.last_name, s.first_name',
            [$subjectId]
        )->fetchAll();
    }

    public function getUnenrolledStudents(int $subjectId): array {
        return $this->db->query(
            'SELECT s.*, u.username FROM students s
             JOIN users u ON u.id = s.user_id
             WHERE s.id NOT IN (
               SELECT student_id FROM subject_students WHERE subject_id = ?
             )
             ORDER BY s.last_name, s.first_name',
            [$subjectId]
        )->fetchAll();
    }

    public function enroll(int $subjectId, int $studentId): void {
        $this->db->query(
            'INSERT IGNORE INTO subject_students (subject_id, student_id) VALUES (?,?)',
            [$subjectId, $studentId]
        );
    }

    public function unenroll(int $subjectId, int $studentId): void {
        $this->db->query(
            'DELETE FROM subject_students WHERE subject_id=? AND student_id=?',
            [$subjectId, $studentId]
        );
    }

    public function enrollBulk(int $subjectId, array $studentIds): void {
        foreach ($studentIds as $sid) {
            $this->enroll($subjectId, (int)$sid);
        }
    }

    // ── Student Self-Enrollment (password) ───────────────────

    /**
     * Attempt to enroll a student using the subject's enrollment password.
     */
    public function studentEnroll(int $subjectId, int $studentId, string $password): array {
        $subject = $this->findById($subjectId);
        if (!$subject) {
            return ['success' => false, 'message' => 'Subject not found.'];
        }
        if (!(bool)$subject['is_active']) {
            return ['success' => false, 'message' => 'This subject is no longer active.'];
        }
        if (!(bool)$subject['enrollment_open']) {
            return ['success' => false, 'message' => 'Enrollment for this subject is currently closed.'];
        }
        if (empty($subject['enrollment_password'])) {
            return ['success' => false, 'message' => 'This subject has no enrollment password set. Ask your administrator.'];
        }
        if (!password_verify($password, $subject['enrollment_password'])) {
            return ['success' => false, 'message' => 'Incorrect enrollment password. Please try again.'];
        }
        $exists = $this->db->query(
            'SELECT 1 FROM subject_students WHERE subject_id=? AND student_id=?',
            [$subjectId, $studentId]
        )->fetch();
        if ($exists) {
            return ['success' => false, 'message' => 'You are already enrolled in this subject.'];
        }
        $this->enroll($subjectId, $studentId);
        // Mark the invite notification as accepted if one exists
        try {
            (new Notification())->accept($studentId, $subjectId);
        } catch (Exception $e) { /* no notification — that is fine */ }
        return [
            'success' => true,
            'message' => "You have successfully enrolled in {$subject['code']} — {$subject['name']}.",
        ];
    }

    // ── Schedule helpers ──────────────────────────────────────

    public function getTodaysSubjects(): array {
        $today = date('l');
        return $this->db->query(
            'SELECT s.*, (SELECT COUNT(*) FROM subject_students ss WHERE ss.subject_id=s.id) AS enrolled_count
             FROM subjects s WHERE s.day_of_week=? AND s.is_active=1 ORDER BY s.time_start',
            [$today]
        )->fetchAll();
    }

    public function getActiveSubjectForStudent(int $studentId): array|false {
        $today = date('l');
        $now   = date('H:i:s');
        return $this->db->query(
            'SELECT s.* FROM subjects s
             JOIN subject_students ss ON ss.subject_id = s.id
             WHERE ss.student_id = ?
               AND s.day_of_week = ?
               AND s.is_active   = 1
               AND ? >= s.time_start
               AND ? <= s.time_end
             ORDER BY s.time_start
             LIMIT 1',
            [$studentId, $today, $now, $now]
        )->fetch();
    }

    public static function computeStatus(array $subject): string {
        $startTs     = strtotime(date('Y-m-d') . ' ' . $subject['time_start']);
        $nowTs       = time();
        $elapsedMins = max(0, ($nowTs - $startTs) / 60);

        $lateMin   = (int)($subject['late_minutes']   ?? 15);
        $absentMin = (int)($subject['absent_minutes'] ?? 45);

        if ($elapsedMins <= $lateMin)   return 'present';
        if ($elapsedMins <= $absentMin) return 'late';
        return 'absent';
    }

    public static function formatSchedule(array $subject): string {
        return $subject['day_of_week'] . ', '
            . date('h:i A', strtotime($subject['time_start']))
            . ' – '
            . date('h:i A', strtotime($subject['time_end']));
    }

    public static function isOngoing(array $subject): bool {
        $now   = date('H:i:s');
        $today = date('l');
        return $today === $subject['day_of_week']
            && $now >= $subject['time_start']
            && $now <= $subject['time_end'];
    }

    /**
     * Get all distinct section groups from the students table.
     * Returns array of ['key'=>'COURSE|||YEAR|||SECTION', 'label'=>'...', 'count'=>N]
     * sorted by course, year, section.
     */
    public function getAllSections(): array {
        $rows = $this->db->query(
            'SELECT course, year_level, section, COUNT(*) AS student_count
             FROM students
             WHERE section IS NOT NULL AND section != ""
               AND course  IS NOT NULL AND course  != ""
             GROUP BY course, year_level, section
             ORDER BY course, year_level, section'
        )->fetchAll();
        $result = [];
        foreach ($rows as $r) {
            $result[] = [
                'key'   => $r['course'] . '|||' . $r['year_level'] . '|||' . $r['section'],
                'label' => $r['course'] . ' Year ' . $r['year_level'] . ' – Section ' . $r['section'],
                'count' => (int)$r['student_count'],
            ];
        }
        return $result;
    }

    /**
     * Toggle enrollment open/closed for a subject.
     */
    public function toggleEnrollment(int $id, bool $open): void {
        $this->db->query(
            'UPDATE subjects SET enrollment_open=? WHERE id=?',
            [$open ? 1 : 0, $id]
        );
    }
}
