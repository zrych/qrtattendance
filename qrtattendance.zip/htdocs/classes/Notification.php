<?php
// ============================================================
//  classes/Notification.php — Student Notification System
// ============================================================

class Notification {
    private Database $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    // ── Read ──────────────────────────────────────────────────

    /** All notifications for a student, newest first. */
    public function getForStudent(int $studentId): array {
        return $this->db->query(
            'SELECT n.*, s.code, s.name, s.day_of_week, s.time_start, s.time_end,
                    s.room, s.instructor, s.is_active, s.enrollment_open,
                    s.late_minutes, s.absent_minutes,
                    (SELECT 1 FROM subject_students ss
                     WHERE ss.subject_id=s.id AND ss.student_id=n.student_id LIMIT 1) AS already_enrolled
             FROM notifications n
             JOIN subjects s ON s.id = n.subject_id
             WHERE n.student_id = ?
             ORDER BY n.created_at DESC',
            [$studentId]
        )->fetchAll();
    }

    /** Pending (not yet accepted) invitations for a student. */
    public function getPending(int $studentId): array {
        return $this->db->query(
            'SELECT n.*, s.code, s.name, s.day_of_week, s.time_start, s.time_end,
                    s.room, s.instructor, s.is_active, s.enrollment_open,
                    s.late_minutes, s.absent_minutes
             FROM notifications n
             JOIN subjects s ON s.id = n.subject_id
             WHERE n.student_id = ? AND n.status = ?
             ORDER BY n.created_at DESC',
            [$studentId, 'pending']
        )->fetchAll();
    }

    /** Accepted invitations (enrollment history via invite). */
    public function getAccepted(int $studentId): array {
        return $this->db->query(
            'SELECT n.*, s.code, s.name, s.day_of_week, s.time_start, s.time_end,
                    s.room, s.instructor
             FROM notifications n
             JOIN subjects s ON s.id = n.subject_id
             WHERE n.student_id = ? AND n.status = ?
             ORDER BY n.accepted_at DESC',
            [$studentId, 'accepted']
        )->fetchAll();
    }

    /** Unread count — pending only, not yet read. */
    public function getUnreadCount(int $studentId): int {
        $row = $this->db->query(
            "SELECT COUNT(*) AS n FROM notifications
             WHERE student_id=? AND is_read=0 AND status='pending'",
            [$studentId]
        )->fetch();
        return (int)($row['n'] ?? 0);
    }

    /**
     * Count of students who joined a subject via invite (accepted status).
     */
    public function getInviteJoinCount(int $subjectId): int {
        $row = $this->db->query(
            "SELECT COUNT(*) AS n FROM notifications
             WHERE subject_id=? AND status='accepted'",
            [$subjectId]
        )->fetch();
        return (int)($row['n'] ?? 0);
    }

    /**
     * Available subjects the student has NOT enrolled in yet,
     * with enrollment open. Used for the browse section.
     */
    public function getAvailableSubjects(int $studentId): array {
        return $this->db->query(
            'SELECT s.*,
                    (SELECT 1 FROM notifications n
                     WHERE n.subject_id=s.id AND n.student_id=? LIMIT 1) AS has_notification
             FROM subjects s
             WHERE s.is_active = 1
               AND s.enrollment_open = 1
               AND s.enrollment_password IS NOT NULL
               AND s.id NOT IN (
                 SELECT subject_id FROM subject_students WHERE student_id = ?
               )
             ORDER BY FIELD(s.day_of_week,"Monday","Tuesday","Wednesday","Thursday",
                            "Friday","Saturday","Sunday"), s.time_start',
            [$studentId, $studentId]
        )->fetchAll();
    }

    // ── Write ─────────────────────────────────────────────────

    /**
     * Create notifications for students matching the given section groups.
     *
     * $sectionKeys: array of composite strings "COURSE|||YEAR|||SECTION"
     *   e.g. ["BS Information Technology|||2|||A", "BS Information Technology|||2|||B"]
     *
     * Returns the number of notification rows created.
     */
    public function notifySections(int $subjectId, array $sectionKeys): int {
        if (empty($sectionKeys)) return 0;
        $count = 0;
        foreach ($sectionKeys as $key) {
            $parts = explode('|||', $key);
            if (count($parts) !== 3) continue;
            [$course, $year, $section] = $parts;
            $students = $this->db->query(
                'SELECT id FROM students
                 WHERE course = ? AND year_level = ? AND section = ?',
                [trim($course), trim($year), trim($section)]
            )->fetchAll();
            foreach ($students as $s) {
                try {
                    $this->db->query(
                        'INSERT IGNORE INTO notifications (student_id, subject_id) VALUES (?,?)',
                        [$s['id'], $subjectId]
                    );
                    $count++;
                } catch (Exception $e) { /* duplicate — safe */ }
            }
        }
        return $count;
    }

    /** Mark a single notification as read (without accepting). */
    public function markRead(int $studentId, int $subjectId): void {
        $this->db->query(
            'UPDATE notifications SET is_read=1 WHERE student_id=? AND subject_id=?',
            [$studentId, $subjectId]
        );
    }

    /** Mark all pending notifications as read for a student. */
    public function markAllRead(int $studentId): void {
        $this->db->query(
            "UPDATE notifications SET is_read=1 WHERE student_id=? AND status='pending'",
            [$studentId]
        );
    }

    /**
     * Accept a notification — marks it as accepted and records the time.
     * Called after successful enrollment via invite.
     */
    public function accept(int $studentId, int $subjectId): void {
        $this->db->query(
            "UPDATE notifications
             SET status='accepted', is_read=1, accepted_at=NOW()
             WHERE student_id=? AND subject_id=?",
            [$studentId, $subjectId]
        );
    }

    /** Delete a specific notification entirely. */
    public function deleteNotification(int $id, int $studentId): void {
        // Ensure the notification belongs to this student
        $this->db->query(
            'DELETE FROM notifications WHERE id=? AND student_id=?',
            [$id, $studentId]
        );
    }

    /** Delete all notifications for a student (pending only, keep history). */
    public function clearPending(int $studentId): void {
        $this->db->query(
            "DELETE FROM notifications WHERE student_id=? AND status='pending'",
            [$studentId]
        );
    }
}
