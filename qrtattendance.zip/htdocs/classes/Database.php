<?php
// ============================================================
//  classes/Database.php — Singleton PDO Wrapper
// ============================================================

class Database {
    private static ?Database $instance = null;
    private PDO $pdo;

    private function __construct() {
        $dsn = sprintf(
            'mysql:host=%s;dbname=%s;charset=utf8mb4',
            DB_HOST, DB_NAME
        );
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $this->pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Surface-safe error — never expose credentials
            die(json_encode(['success' => false, 'message' => 'Database connection failed.']));
        }
    }

    /** Returns the single Database instance */
    public static function getInstance(): Database {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    /** Returns the underlying PDO connection */
    public function getConnection(): PDO {
        return $this->pdo;
    }

    /** Shorthand prepared query execution */
    public function query(string $sql, array $params = []): PDOStatement {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    /** Returns last inserted ID */
    public function lastInsertId(): string {
        return $this->pdo->lastInsertId();
    }

    // Prevent cloning / unserialization of the singleton
    private function __clone() {}
    public function __wakeup() { throw new \Exception('Cannot unserialize singleton.'); }
}
