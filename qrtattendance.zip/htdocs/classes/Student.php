<?php
// ============================================================
//  classes/Student.php — Student CRUD & QR Token
// ============================================================

class Student {
    private Database $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    // ── Helpers ──────────────────────────────────────────────

    /** Generate a cryptographically secure QR token. */
    public static function generateQrToken(): string {
        return bin2hex(random_bytes(32)); // 64-char hex string
    }

    /** Return full name "Last, First". */
    public static function fullName(array $student): string {
        return htmlspecialchars($student['last_name'] . ', ' . $student['first_name']);
    }

    // ── Create ────────────────────────────────────────────────

    /**
     * Add a new student + linked user account.
     * Returns ['success'=>bool, 'message'=>string, 'student_id'=>int]
     */
    public function create(array $data): array {
        $userClass = new User();

        // Validate student number uniqueness
        if ($this->findByStudentNumber($data['student_number'])) {
            return ['success' => false, 'message' => 'Student number already exists.'];
        }
        // Validate username uniqueness
        if ($userClass->usernameExists($data['username'])) {
            return ['success' => false, 'message' => 'Username already taken.'];
        }

        // Create user account
        $userId   = $userClass->create($data['username'], $data['password'], 'student');
        $qrToken  = self::generateQrToken();

        $this->db->query(
            'INSERT INTO students
             (user_id, student_number, first_name, last_name, course, year_level, section, email, qr_token)
             VALUES (?,?,?,?,?,?,?,?,?)',
            [
                $userId,
                trim($data['student_number']),
                trim($data['first_name']),
                trim($data['last_name']),
                trim($data['course']   ?? ''),
                (int)($data['year_level'] ?? 1),
                trim($data['section']  ?? ''),
                trim($data['email']    ?? ''),
                $qrToken,
            ]
        );

        return [
            'success'    => true,
            'message'    => 'Student added successfully.',
            'student_id' => (int)$this->db->lastInsertId(),
        ];
    }

    // ── Read ─────────────────────────────────────────────────

    /** Fetch all students with username. */
    public function getAll(string $search = ''): array {
        $sql    = 'SELECT s.*, u.username, u.is_active
                   FROM students s
                   JOIN users u ON u.id = s.user_id';
        $params = [];
        if ($search !== '') {
            $sql   .= ' WHERE s.first_name LIKE ? OR s.last_name LIKE ?
                        OR s.student_number LIKE ? OR s.course LIKE ?';
            $like   = "%$search%";
            $params = [$like, $like, $like, $like];
        }
        $sql .= ' ORDER BY s.last_name, s.first_name';
        return $this->db->query($sql, $params)->fetchAll();
    }

    /** Fetch a single student by student ID (primary key). */
    public function findById(int $id): array|false {
        return $this->db->query(
            'SELECT s.*, u.username, u.is_active
             FROM students s JOIN users u ON u.id = s.user_id
             WHERE s.id = ?',
            [$id]
        )->fetch();
    }

    /** Fetch by user_id (for student login linking). */
    public function findByUserId(int $userId): array|false {
        return $this->db->query(
            'SELECT s.*, u.username FROM students s JOIN users u ON u.id = s.user_id WHERE s.user_id = ?',
            [$userId]
        )->fetch();
    }

    /** Fetch by student number. */
    public function findByStudentNumber(string $number): array|false {
        return $this->db->query(
            'SELECT * FROM students WHERE student_number = ?',
            [trim($number)]
        )->fetch();
    }

    /** Fetch by QR token. */
    public function findByQrToken(string $token): array|false {
        return $this->db->query(
            'SELECT s.*, u.username FROM students s JOIN users u ON u.id=s.user_id WHERE s.qr_token = ?',
            [$token]
        )->fetch();
    }

    /** Count total students. */
    public function count(): int {
        return (int)$this->db->query('SELECT COUNT(*) AS n FROM students')->fetch()['n'];
    }

    // ── Update ────────────────────────────────────────────────

    /**
     * Update student details (and optionally username/password).
     */
    public function update(int $id, array $data): array {
        $student   = $this->findById($id);
        if (!$student) return ['success' => false, 'message' => 'Student not found.'];

        $userClass = new User();

        // Username uniqueness (exclude current user)
        if (!empty($data['username']) && $userClass->usernameExists($data['username'], $student['user_id'])) {
            return ['success' => false, 'message' => 'Username already taken.'];
        }

        $this->db->query(
            'UPDATE students SET first_name=?, last_name=?, course=?, year_level=?, section=?, email=?
             WHERE id=?',
            [
                trim($data['first_name']),
                trim($data['last_name']),
                trim($data['course']    ?? ''),
                (int)($data['year_level'] ?? 1),
                trim($data['section']  ?? ''),
                trim($data['email']    ?? ''),
                $id,
            ]
        );

        // Update username if provided
        if (!empty($data['username'])) {
            $this->db->query('UPDATE users SET username=? WHERE id=?', [$data['username'], $student['user_id']]);
        }
        // Update password if provided
        if (!empty($data['password'])) {
            $userClass->updatePassword($student['user_id'], $data['password']);
        }

        return ['success' => true, 'message' => 'Student updated successfully.'];
    }

    /** Regenerate QR token for a student. */
    public function regenerateQr(int $id): string {
        $token = self::generateQrToken();
        $this->db->query('UPDATE students SET qr_token=? WHERE id=?', [$token, $id]);
        return $token;
    }

    // ── Delete ────────────────────────────────────────────────

    /** Delete student (cascades to attendance via FK). */
    public function delete(int $id): bool {
        $student = $this->findById($id);
        if (!$student) return false;
        // Deleting the user cascades to student & attendance
        $userClass = new User();
        $userClass->delete($student['user_id']);
        return true;
    }
}
