<?php
// ============================================================
//  config/database.php — Database Credentials
//  Change these values to match your InfinityFree settings
// ============================================================

define('DB_HOST', 'sql102.infinityfree.com');
define('DB_USER', 'if0_41887476');   // ← change
define('DB_PASS', 'Qrattendance39');   // ← change
define('DB_NAME', 'if0_41887476_qr_attendance');      // ← change if different

// Base URL — no trailing slash
define('BASE_URL', 'https://qrtattendance.free.nf'); // ← change for live (e.g. https://yoursite.infinityfreeapp.com)

// Timezone
date_default_timezone_set('Asia/Manila');
