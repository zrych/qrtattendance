<?php
require_once __DIR__ . '/../includes/auth.php';
User::requireLogin('admin');

$attendanceClass = new Attendance();
$studentClass    = new Student();

// ── Handle POST ───────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postAction = $_POST['post_action'] ?? '';

    if ($postAction === 'add') {
        $attendanceClass->create([
            'student_id' => (int)($_POST['student_id'] ?? 0),
            'date'       => $_POST['date']     ?? date('Y-m-d'),
            'time_in'    => $_POST['time_in']  ?? null,
            'time_out'   => $_POST['time_out'] ?? null,
            'status'     => $_POST['status']   ?? 'present',
            'notes'      => $_POST['notes']    ?? '',
        ]);
        setFlash('success', 'Attendance record added.');
        redirect('admin/attendance.php');
    }

    if ($postAction === 'edit') {
        $attendanceClass->update((int)$_POST['att_id'], [
            'time_in'  => $_POST['time_in']  ?: null,
            'time_out' => $_POST['time_out'] ?: null,
            'status'   => $_POST['status'],
            'notes'    => $_POST['notes'] ?? '',
        ]);
        setFlash('success', 'Attendance record updated.');
        redirect('admin/attendance.php');
    }

    if ($postAction === 'delete') {
        $attendanceClass->delete((int)$_POST['att_id']);
        setFlash('success', 'Attendance record deleted.');
        redirect('admin/attendance.php');
    }
}

// ── Filters ───────────────────────────────────────────────────
$filterDate   = clean($_GET['date']   ?? '');
$filterStatus = clean($_GET['status'] ?? '');
$filterSearch = clean($_GET['q']      ?? '');
$filterAuto   = isset($_GET['auto'])  ? (bool)(int)$_GET['auto'] : null; // null=all, true=auto-only

$records  = $attendanceClass->getAll([
    'date'   => $filterDate,
    'status' => $filterStatus,
    'search' => $filterSearch,
]);

// Apply auto-timeout filter client-side after fetch
if ($filterAuto === true) {
    $records = array_filter($records, fn($r) => str_contains($r['notes'] ?? '', 'Auto timed-out'));
} elseif ($filterAuto === false) {
    $records = array_filter($records, fn($r) => !str_contains($r['notes'] ?? '', 'Auto timed-out'));
}
$records = array_values($records);

$autoCount = count(array_filter($records, fn($r) => str_contains($r['notes'] ?? '', 'Auto timed-out')));
$students  = $studentClass->getAll();

$pageTitle = 'Attendance Records';
$activeNav = 'attendance';
require_once __DIR__ . '/../includes/header_admin.php';

$flash = getFlash();
?>

<?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] ?>">
    <i class="fa-solid fa-circle-info"></i> <?= htmlspecialchars($flash['msg']) ?>
  </div>
<?php endif; ?>

<?php if ($autoCount > 0 && $filterAuto !== true): ?>
<div style="
  background:rgba(245,158,11,.08);
  border:1.5px solid rgba(245,158,11,.3);
  border-radius:var(--radius);
  padding:.85rem 1.2rem;
  margin-bottom:1rem;
  display:flex;align-items:center;justify-content:space-between;gap:.8rem;flex-wrap:wrap">
  <div style="display:flex;align-items:center;gap:.8rem">
    <i class="fa-solid fa-robot" style="color:#f59e0b;font-size:1.1rem"></i>
    <div>
      <strong style="color:#f59e0b"><?= $autoCount ?> auto timed-out record<?= $autoCount > 1 ? 's' : '' ?></strong>
      <span style="color:var(--ad-muted);font-size:.85rem">
        — student<?= $autoCount > 1 ? 's' : '' ?> did not scan out before class ended.
        Their attendance status is unchanged and still counted.
      </span>
    </div>
  </div>
  <a href="?auto=1<?= $filterDate ? '&date='.$filterDate : '' ?>"
     class="btn btn-warning btn-sm">
    <i class="fa-solid fa-filter"></i> View Auto Timed-Out
  </a>
</div>
<?php endif; ?>

<div class="page-header">
  <div>
    <h1>Attendance Records</h1>
    <p><?= count($records) ?> record<?= count($records) !== 1 ? 's' : '' ?> found
      <?php if ($filterAuto === true): ?>
        <span style="color:#f59e0b;font-size:.8rem;margin-left:.4rem">
          <i class="fa-solid fa-robot"></i> Showing auto timed-out only
          — <a href="?" style="color:var(--primary)">Clear filter</a>
        </span>
      <?php endif; ?>
    </p>
  </div>
  <div style="display:flex;gap:.6rem;flex-wrap:wrap">
    <a href="<?= BASE_URL ?>/admin/backup.php?export_csv=1&date_from=<?= urlencode($filterDate ?: date('Y-m-01')) ?>&date_to=<?= urlencode($filterDate ?: date('Y-m-d')) ?>&status=<?= urlencode($filterStatus) ?>"
       class="btn btn-success">
      <i class="fa-solid fa-file-csv"></i> Export CSV
    </a>
    <button class="btn btn-primary" onclick="openModal('modalAdd')">
      <i class="fa-solid fa-plus"></i> Add Manual Record
    </button>
  </div>
</div>

<!-- Filter toolbar -->
<form method="GET" style="margin-bottom:1.2rem">
  <div class="toolbar">
    <div class="search-box">
      <i class="fa-solid fa-search search-icon"></i>
      <input type="text" name="q" class="form-control"
             placeholder="Search student name or ID…"
             value="<?= htmlspecialchars($filterSearch) ?>">
    </div>
    <input type="date" name="date" class="form-control" style="width:auto"
           value="<?= htmlspecialchars($filterDate) ?>">
    <select name="status" class="form-control" style="width:auto">
      <option value="">All Status</option>
      <option value="present" <?= $filterStatus==='present'?'selected':'' ?>>Present</option>
      <option value="late"    <?= $filterStatus==='late'   ?'selected':'' ?>>Late</option>
      <option value="absent"  <?= $filterStatus==='absent' ?'selected':'' ?>>Absent</option>
    </select>
    <select name="auto" class="form-control" style="width:auto">
      <option value="" <?= $filterAuto===null  ?'selected':'' ?>>All Records</option>
      <option value="1" <?= $filterAuto===true  ?'selected':'' ?>>Auto Timed-Out Only</option>
      <option value="0" <?= $filterAuto===false ?'selected':'' ?>>Manual Only</option>
    </select>
    <button type="submit" class="btn btn-primary btn-sm">
      <i class="fa-solid fa-filter"></i> Filter
    </button>
    <a href="<?= BASE_URL ?>/admin/attendance.php" class="btn btn-secondary btn-sm">Reset</a>
  </div>
</form>

<!-- Records table -->
<div class="card card-dark">
  <div class="card-body" style="padding:0">
    <?php if (empty($records)): ?>
      <div class="empty-state">
        <div class="empty-icon">📅</div>
        <h3>No records found</h3>
        <p>Try adjusting your filters or add a manual record.</p>
      </div>
    <?php else: ?>
      <div class="table-wrapper">
        <table class="table table-dark">
          <thead>
            <tr>
              <th>#</th>
              <th>Student</th>
              <th>Subject</th>
              <th>Date</th>
              <th>Time In</th>
              <th>Time Out</th>
              <th>Status</th>
              <th>Notes</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($records as $i => $r):
              $isAutoTimeout = str_contains($r['notes'] ?? '', 'Auto timed-out');
            ?>
            <tr>
              <td style="color:var(--ad-muted)"><?= $i + 1 ?></td>
              <td>
                <div style="font-weight:600">
                  <?= htmlspecialchars($r['last_name'] . ', ' . $r['first_name']) ?>
                </div>
                <div style="font-size:.78rem;color:var(--ad-muted)">
                  <?= htmlspecialchars($r['student_number']) ?>
                </div>
              </td>
              <td style="font-size:.82rem;color:var(--ad-muted)">
                <?= htmlspecialchars($r['subject_code'] ?? '—') ?>
              </td>
              <td>
                <?= date('M j, Y', strtotime($r['date'])) ?>
                <div style="font-size:.72rem;color:var(--ad-muted)">
                  <?= date('D', strtotime($r['date'])) ?>
                </div>
              </td>
              <td>
                <?= $r['time_in']
                    ? date('h:i A', strtotime($r['time_in']))
                    : '<span style="color:var(--ad-muted)">—</span>' ?>
              </td>
              <td>
                <?php if ($r['time_out']): ?>
                  <?= date('h:i A', strtotime($r['time_out'])) ?>
                  <?php if ($isAutoTimeout): ?>
                    <div style="font-size:.68rem;color:#f59e0b;margin-top:.1rem">
                      <i class="fa-solid fa-robot"></i> auto
                    </div>
                  <?php endif; ?>
                <?php else: ?>
                  <span style="color:var(--ad-muted)">—</span>
                <?php endif; ?>
              </td>
              <td>
                <?php if ($r['status'] === 'present'): ?>
                  <span class="badge badge-success">Present</span>
                <?php elseif ($r['status'] === 'late'): ?>
                  <span class="badge badge-warning">Late</span>
                <?php else: ?>
                  <span class="badge badge-danger">Absent</span>
                <?php endif; ?>
              </td>
              <td style="font-size:.8rem;color:var(--ad-muted);max-width:200px">
                <?= htmlspecialchars($r['notes'] ?? '') ?: '—' ?>
              </td>
              <td>
                <div style="display:flex;gap:.35rem">
                  <button class="btn btn-info btn-sm"
                    onclick='openEditAtt(<?= htmlspecialchars(json_encode($r), ENT_QUOTES) ?>)'>
                    <i class="fa-solid fa-pen"></i>
                  </button>
                  <form method="POST" style="display:inline">
                    <input type="hidden" name="post_action" value="delete">
                    <input type="hidden" name="att_id" value="<?= $r['id'] ?>">
                    <button type="submit" class="btn btn-danger btn-sm"
                      data-confirm="Delete this attendance record?">
                      <i class="fa-solid fa-trash"></i>
                    </button>
                  </form>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- ── ADD MODAL ── -->
<div class="modal-overlay hidden" id="modalAdd">
  <div class="modal">
    <div class="modal-header">
      <h3><i class="fa-solid fa-plus" style="color:var(--primary)"></i>&nbsp; Add Manual Attendance</h3>
      <button class="modal-close" onclick="closeModal('modalAdd')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <form method="POST" class="dark-form" id="formAdd">
        <input type="hidden" name="post_action" value="add">
        <div class="form-group">
          <label class="form-label">Student *</label>
          <select name="student_id" class="form-control" required>
            <option value="">— Select Student —</option>
            <?php foreach ($students as $s): ?>
              <option value="<?= $s['id'] ?>">
                <?= htmlspecialchars($s['student_number'] . ' — ' . $s['last_name'] . ', ' . $s['first_name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Date *</label>
          <input type="date" name="date" class="form-control" value="<?= date('Y-m-d') ?>" required>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Time In</label>
            <input type="time" name="time_in"  class="form-control">
          </div>
          <div class="form-group">
            <label class="form-label">Time Out</label>
            <input type="time" name="time_out" class="form-control">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Status *</label>
          <select name="status" class="form-control">
            <option value="present">Present</option>
            <option value="late">Late</option>
            <option value="absent">Absent</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Notes</label>
          <input type="text" name="notes" class="form-control" placeholder="Optional notes…">
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal('modalAdd')">Cancel</button>
      <button class="btn btn-primary" onclick="document.getElementById('formAdd').submit()">
        <i class="fa-solid fa-floppy-disk"></i> Save
      </button>
    </div>
  </div>
</div>

<!-- ── EDIT MODAL ── -->
<div class="modal-overlay hidden" id="modalEdit">
  <div class="modal">
    <div class="modal-header">
      <h3><i class="fa-solid fa-pen" style="color:var(--info)"></i>&nbsp; Edit Attendance</h3>
      <button class="modal-close" onclick="closeModal('modalEdit')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <form method="POST" class="dark-form" id="formEdit">
        <input type="hidden" name="post_action" value="edit">
        <input type="hidden" name="att_id" id="editAttId">
        <div class="form-group">
          <label class="form-label">Student</label>
          <input type="text" id="editAttStudent" class="form-control" disabled>
        </div>
        <div class="form-group">
          <label class="form-label">Date</label>
          <input type="text" id="editAttDate" class="form-control" disabled>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Time In</label>
            <input type="time" name="time_in" id="editTimeIn" class="form-control">
          </div>
          <div class="form-group">
            <label class="form-label">Time Out</label>
            <input type="time" name="time_out" id="editTimeOut" class="form-control">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Status</label>
          <select name="status" id="editStatus" class="form-control">
            <option value="present">Present</option>
            <option value="late">Late</option>
            <option value="absent">Absent</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Notes</label>
          <input type="text" name="notes" id="editNotes" class="form-control">
          <small style="color:var(--ad-muted)">
            Clear the auto-timeout note here if you manually verified the student's departure.
          </small>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal('modalEdit')">Cancel</button>
      <button class="btn btn-info" onclick="document.getElementById('formEdit').submit()">
        <i class="fa-solid fa-floppy-disk"></i> Update
      </button>
    </div>
  </div>
</div>

<script>
function openModal(id)  { document.getElementById(id).classList.remove('hidden'); }
function closeModal(id) { document.getElementById(id).classList.add('hidden'); }

document.querySelectorAll('.modal-overlay').forEach(ov =>
  ov.addEventListener('click', e => { if (e.target===ov) ov.classList.add('hidden'); })
);

function openEditAtt(r) {
  document.getElementById('editAttId').value      = r.id;
  document.getElementById('editAttStudent').value = r.last_name + ', ' + r.first_name
                                                    + ' (' + r.student_number + ')';
  document.getElementById('editAttDate').value    = r.date;
  document.getElementById('editTimeIn').value     = r.time_in  ? r.time_in.substring(0,5)  : '';
  document.getElementById('editTimeOut').value    = r.time_out ? r.time_out.substring(0,5) : '';
  document.getElementById('editStatus').value     = r.status;
  document.getElementById('editNotes').value      = r.notes || '';
  openModal('modalEdit');
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
