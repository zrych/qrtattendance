<?php
require_once __DIR__ . '/../includes/auth.php';
User::requireLogin('admin');

$pageTitle    = 'Scan QR Code';
$pageSubtitle = 'Mark student attendance by scanning their QR code';
$activeNav    = 'scan';
require_once __DIR__ . '/../includes/header_admin.php';
?>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:1.4rem;align-items:start">

  <!-- Scanner Panel -->
  <div class="card card-dark">
    <div class="card-header">
      <h3><i class="fa-solid fa-camera" style="color:var(--primary)"></i>&nbsp; QR Code Scanner</h3>
      <span class="badge badge-success animate-pulse" id="scannerStatus">Ready</span>
    </div>
    <div class="card-body" style="padding:0">
      <div id="qr-reader" style="width:100%"></div>

      <!-- Result display -->
      <div class="scan-result" id="scanResultArea" style="display:none">
        <div class="scan-result-card" id="scanResultCard">
          <div class="scan-result-icon" id="scanResultIcon">✅</div>
          <div class="scan-result-info">
            <div class="result-name"  id="scanResultName">—</div>
            <div class="result-detail" id="scanResultDetail">—</div>
          </div>
          <span class="badge" id="scanResultBadge" style="margin-left:auto">—</span>
        </div>
      </div>

      <div style="padding:1rem 1.2rem;border-top:1px solid var(--ad-border);display:flex;align-items:center;justify-content:space-between">
        <div style="font-size:.82rem;color:var(--ad-muted)">
          <i class="fa-solid fa-circle-info"></i>
          First scan = Time In &nbsp;|&nbsp; Second scan = Time Out
        </div>
        <button class="btn btn-secondary btn-sm" id="btnClearResult">
          <i class="fa-solid fa-rotate-left"></i> Clear
        </button>
      </div>
    </div>
  </div>

  <!-- Log & Manual Entry Panel -->
  <div style="display:flex;flex-direction:column;gap:1rem">

    <!-- Scan log -->
    <div class="card card-dark">
      <div class="card-header">
        <h3><i class="fa-solid fa-list-check" style="color:var(--success)"></i>&nbsp; Scan Log</h3>
        <button class="btn btn-secondary btn-sm" id="btnClearLog">
          <i class="fa-solid fa-trash"></i> Clear
        </button>
      </div>
      <div class="card-body">
        <div class="scan-log" id="scanLog">
          <div style="text-align:center;padding:1.5rem;color:var(--ad-muted);font-size:.875rem">
            <i class="fa-regular fa-clock"></i> Scan log will appear here…
          </div>
        </div>
      </div>
    </div>

    <!-- Manual token entry -->
    <div class="card card-dark">
      <div class="card-header">
        <h3><i class="fa-solid fa-keyboard" style="color:var(--warning)"></i>&nbsp; Manual Entry</h3>
      </div>
      <div class="card-body dark-form">
        <p style="color:var(--ad-muted);font-size:.82rem;margin-bottom:.8rem">
          Enter a student number if the QR scanner isn't working.
        </p>
        <div style="display:flex;gap:.6rem">
          <input type="text" id="manualToken" class="form-control" placeholder="Student number or QR token…">
          <button class="btn btn-warning" onclick="processManual()">
            <i class="fa-solid fa-arrow-right"></i> Submit
          </button>
        </div>
      </div>
    </div>

    <!-- Today's quick stats -->
    <div class="card card-dark">
      <div class="card-header">
        <h3><i class="fa-solid fa-chart-bar" style="color:var(--info)"></i>&nbsp; Today's Progress</h3>
      </div>
      <div class="card-body">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.8rem" id="todayStats">
          <div style="background:var(--ad-bg);border-radius:var(--radius-sm);padding:.9rem;text-align:center">
            <div style="font-size:1.6rem;font-weight:800;color:var(--success)" id="statPresent">—</div>
            <div style="font-size:.75rem;color:var(--ad-muted);text-transform:uppercase;letter-spacing:.5px;margin-top:.2rem">Present</div>
          </div>
          <div style="background:var(--ad-bg);border-radius:var(--radius-sm);padding:.9rem;text-align:center">
            <div style="font-size:1.6rem;font-weight:800;color:var(--warning)" id="statLate">—</div>
            <div style="font-size:.75rem;color:var(--ad-muted);text-transform:uppercase;letter-spacing:.5px;margin-top:.2rem">Late</div>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<!-- html5-qrcode CDN -->
<script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>

<script>
const BASE_URL = '<?= BASE_URL ?>';
let lastScannedToken   = '';
let lastScannedAt      = 0;
let lastScanSuccessful = false;
const DEBOUNCE_MS      = 3000;   // 3s between failed/same scans
const DEBOUNCE_SUCCESS = 30000;  // 30s lock after a successful Time In

// ── Scanner ────────────────────────────────────────────────────
const scanner = new Html5QrcodeScanner('qr-reader', {
  fps: 10,
  qrbox: { width: 260, height: 260 },
  aspectRatio: 1,
}, false);

scanner.render(onScanSuccess, onScanError);

function onScanSuccess(decodedText) {
  const now = Date.now();
  // Debounce: ignore same token within 3 seconds
  const debounceWindow = (lastScanSuccessful && decodedText === lastScannedToken)
  ? DEBOUNCE_SUCCESS
  : DEBOUNCE_MS;
if (decodedText === lastScannedToken && (now - lastScannedAt) < debounceWindow) return;
lastScanSuccessful = false; // reset on new token
  lastScannedToken = decodedText;
  lastScannedAt    = now;
  sendScan(decodedText);
}

function onScanError(err) { /* silent */ }

// ── Send scan to API ────────────────────────────────────────────
function sendScan(token) {
  document.getElementById('scannerStatus').textContent = 'Processing…';

  fetch('/api/scan.php', {   // ← relative URL (Fix #2 already applied)
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token })
  })
  .then(r => {
    // Check if InfinityFree returned a security challenge (HTML) instead of JSON
    const contentType = r.headers.get('Content-Type') || '';
    if (!contentType.includes('application/json')) {
      // Security cookie expired — the page needs a full reload to get a new challenge
      showResult({
        success: false,
        message: 'Session expired. The page will reload automatically…'
      });
      setTimeout(() => location.reload(), 2000);
      return null;
    }
    return r.json();
  })
  .then(data => {
  if (!data) return;
  showResult(data);
  // After a successful Time In, extend the debounce to 30 seconds
  // so the scanner can't immediately re-scan the same student
  if (data.success && data.action === 'time_in') {
    lastScanSuccessful = true;
    lastScannedAt      = Date.now(); // reset the clock from now
  }
})
  .catch(() => showResult({
    success: false,
    message: 'Network error. Please check your connection or reload the page.'
  }));
}

// ── Display result ─────────────────────────────────────────────
function showResult(data) {
  const area   = document.getElementById('scanResultArea');
  const card   = document.getElementById('scanResultCard');
  const icon   = document.getElementById('scanResultIcon');
  const name   = document.getElementById('scanResultName');
  const detail = document.getElementById('scanResultDetail');
  const badge  = document.getElementById('scanResultBadge');
  const status = document.getElementById('scannerStatus');

  area.style.display = 'block';

  if (data.success) {
    card.className  = 'scan-result-card success';
    icon.textContent= data.action === 'time_in' ? '✅' : '👋';
    name.textContent= data.student
      ? data.student.last_name + ', ' + data.student.first_name
      : data.message;
    const actionLabel = data.action === 'time_in' ? 'Time IN' : 'Time OUT';
    detail.textContent= actionLabel + ' at ' + data.time + (data.student ? ' · ' + data.student.student_number : '');

    if (data.status === 'late') {
      badge.textContent  = 'LATE';
      badge.className    = 'badge badge-warning';
    } else {
      badge.textContent  = actionLabel.toUpperCase();
      badge.className    = data.action === 'time_in' ? 'badge badge-success' : 'badge badge-info';
    }
    status.textContent = 'Scanned ✓';
    addLogEntry(true, name.textContent, detail.textContent);
  } else {
    card.className  = 'scan-result-card error';
    icon.textContent= '❌';
    name.textContent= 'Scan Failed';
    detail.textContent = data.message || 'Unknown error.';
    badge.textContent  = 'ERROR';
    badge.className    = 'badge badge-danger';
    status.textContent = 'Error';
    addLogEntry(false, 'Scan Failed', data.message);
  }

  // Reset scanner status after 2s
  setTimeout(() => { status.textContent = 'Ready'; }, 2000);

  // Refresh stats
  fetchStats();
}

// ── Log ────────────────────────────────────────────────────────
function addLogEntry(success, name, detail) {
  const log = document.getElementById('scanLog');
  // Remove placeholder
  const placeholder = log.querySelector('div[style]');
  if (placeholder) placeholder.remove();

  const now  = new Date();
  const time = now.toLocaleTimeString('en-PH', {hour:'2-digit',minute:'2-digit',second:'2-digit'});

  const item = document.createElement('div');
  item.className = 'scan-log-item';
  item.innerHTML = `
    <div class="scan-log-dot ${success ? 'success' : 'error'}"></div>
    <div>
      <div style="font-weight:600;color:var(--ad-text)">${name}</div>
      <div style="font-size:.78rem;color:var(--ad-muted)">${detail}</div>
    </div>
    <div class="scan-log-time">${time}</div>
  `;
  log.insertBefore(item, log.firstChild);
}

document.getElementById('btnClearLog').addEventListener('click', () => {
  document.getElementById('scanLog').innerHTML = `
    <div style="text-align:center;padding:1.5rem;color:var(--ad-muted);font-size:.875rem">
      <i class="fa-regular fa-clock"></i> Scan log will appear here…
    </div>`;
});

document.getElementById('btnClearResult').addEventListener('click', () => {
  document.getElementById('scanResultArea').style.display = 'none';
});

// ── Manual entry ───────────────────────────────────────────────
function processManual() {
  const val = document.getElementById('manualToken').value.trim();
  if (!val) return;
  sendScan(val);
  document.getElementById('manualToken').value = '';
}
document.getElementById('manualToken').addEventListener('keydown', e => {
  if (e.key === 'Enter') processManual();
});

// ── Today stats ────────────────────────────────────────────────
function fetchStats() {
  fetch('/api/scan.php?stats=1')
    .then(r => r.json())
    .then(data => {
      if (data.present !== undefined) {
        document.getElementById('statPresent').textContent = data.present;
        document.getElementById('statLate').textContent    = data.late;
      }
    })
    .catch(() => {});
}
fetchStats();
setInterval(fetchStats, 15000);
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
