<?php
require_once __DIR__ . '/../includes/auth.php';
User::requireLogin('admin');

$backupClass  = new Backup();
$subjectClass = new Subject();
$studentClass = new Student();

// ── CSV Download (streams file, must be before any HTML) ──────
if (isset($_GET['export_csv'])) {
    $filters = [
        'date_from'  => clean($_GET['date_from']   ?? ''),
        'date_to'    => clean($_GET['date_to']     ?? ''),
        'subject_id' => (int)($_GET['subject_id']  ?? 0) ?: null,
        'status'     => clean($_GET['status']      ?? ''),
        'student_id' => (int)($_GET['student_id']  ?? 0) ?: null,
    ];
    $backupClass->streamAttendanceCSV(array_filter($filters));
    exit; // streamed, nothing more needed
}

// ── Backup download ───────────────────────────────────────────
if (isset($_GET['dl'])) {
    $backupClass->downloadBackup(clean($_GET['dl']));
    exit;
}

// ── POST handlers ─────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['post_action'] ?? '';

    if ($act === 'manual_backup') {
        $result = $backupClass->generateSQLBackup('manual');
        setFlash($result['success'] ? 'success' : 'danger', $result['message']);
        redirect('admin/backup.php');
    }

    if ($act === 'delete_backup') {
        $backupClass->deleteBackup((int)$_POST['backup_id']);
        setFlash('success', 'Backup deleted.');
        redirect('admin/backup.php');
    }

    if ($act === 'prune') {
        $backupClass->pruneOld((int)($_POST['keep'] ?? 7));
        setFlash('success', 'Old backups pruned.');
        redirect('admin/backup.php');
    }
}

$backups  = $backupClass->getAll();
$subjects = $subjectClass->getAll();
$students = $studentClass->getAll();

$pageTitle = 'Backup & Export';
$activeNav = 'backup';
require_once __DIR__ . '/../includes/header_admin.php';
$flash = getFlash();
?>

<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type'] ?>">
  <i class="fa-solid fa-circle-info"></i> <?= htmlspecialchars($flash['msg']) ?>
</div>
<?php endif; ?>

<div class="page-header">
  <div><h1>Backup &amp; Export</h1>
    <p>Download attendance as CSV or back up the entire database</p>
  </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:1.2rem;align-items:start">

  <!-- ── CSV Export ── -->
  <div class="card card-dark">
    <div class="card-header">
      <h3><i class="fa-solid fa-file-csv" style="color:var(--success)"></i>&nbsp; Export Attendance CSV</h3>
    </div>
    <div class="card-body dark-form">
      <p style="color:var(--ad-muted);font-size:.85rem;margin-bottom:1.1rem">
        Filter by date range, subject, or student — then download a spreadsheet-ready CSV file.
        Includes: date, day, time in/out, student info, subject, and status.
      </p>
      <form method="GET" action="">
        <input type="hidden" name="export_csv" value="1">

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Date From</label>
            <input type="date" name="date_from" class="form-control"
                   value="<?= date('Y-m-01') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Date To</label>
            <input type="date" name="date_to" class="form-control"
                   value="<?= date('Y-m-d') ?>">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Subject <small style="color:var(--ad-muted)">(optional)</small></label>
          <select name="subject_id" class="form-control">
            <option value="">All Subjects</option>
            <?php foreach ($subjects as $sub): ?>
              <option value="<?= $sub['id'] ?>"><?= htmlspecialchars($sub['code'].' — '.$sub['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group">
          <label class="form-label">Student <small style="color:var(--ad-muted)">(optional)</small></label>
          <select name="student_id" class="form-control">
            <option value="">All Students</option>
            <?php foreach ($students as $s): ?>
              <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['student_number'].' — '.$s['last_name'].', '.$s['first_name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group">
          <label class="form-label">Status <small style="color:var(--ad-muted)">(optional)</small></label>
          <select name="status" class="form-control">
            <option value="">All Statuses</option>
            <option value="present">Present</option>
            <option value="late">Late</option>
            <option value="absent">Absent</option>
          </select>
        </div>

        <button type="submit" class="btn btn-success btn-block btn-lg" style="margin-top:.5rem">
          <i class="fa-solid fa-download"></i> Download CSV
        </button>
      </form>

      <div style="margin-top:1rem;padding:.8rem 1rem;background:var(--ad-bg);border-radius:var(--radius-sm);font-size:.78rem;color:var(--ad-muted)">
        <i class="fa-solid fa-circle-info"></i>
        CSV opens in Excel, Google Sheets, or any spreadsheet app.
        UTF-8 BOM is included so special characters display correctly.
      </div>
    </div>
  </div>

  <!-- ── SQL Backup ── -->
  <div style="display:flex;flex-direction:column;gap:1rem">

    <div class="card card-dark">
      <div class="card-header">
        <h3><i class="fa-solid fa-database" style="color:var(--primary)"></i>&nbsp; Database Backup</h3>
      </div>
      <div class="card-body">
        <p style="color:var(--ad-muted);font-size:.85rem;margin-bottom:1rem">
          Creates a full SQL dump of all tables. Auto-backup runs once daily when any admin logs in.
          Manual backups can be created anytime.
        </p>

        <!-- Auto-backup status -->
        <?php
          $todayAuto = array_filter($backups, fn($b) => $b['type']==='auto' && date('Y-m-d', strtotime($b['created_at'])) === date('Y-m-d'));
        ?>
        <div style="display:flex;align-items:center;gap:.7rem;padding:.7rem 1rem;border-radius:var(--radius-sm);margin-bottom:1rem;
             background:<?= !empty($todayAuto) ? 'rgba(16,185,129,.1)' : 'rgba(245,158,11,.1)' ?>;
             border:1px solid <?= !empty($todayAuto) ? 'rgba(16,185,129,.3)' : 'rgba(245,158,11,.3)' ?>">
          <i class="fa-solid <?= !empty($todayAuto) ? 'fa-circle-check' : 'fa-clock' ?>"
             style="color:<?= !empty($todayAuto) ? 'var(--success)' : 'var(--warning)' ?>"></i>
          <div style="font-size:.85rem;color:var(--ad-text)">
            <?php if (!empty($todayAuto)):
              $ab = array_values($todayAuto)[0];
            ?>
              Today's auto-backup completed at <?= date('h:i A', strtotime($ab['created_at'])) ?>
              <span style="color:var(--ad-muted)">(<?= Backup::formatBytes((int)$ab['size_bytes']) ?>)</span>
            <?php else: ?>
              Auto-backup not yet run today — will trigger on next admin page load.
            <?php endif; ?>
          </div>
        </div>

        <form method="POST">
          <input type="hidden" name="post_action" value="manual_backup">
          <button type="submit" class="btn btn-primary btn-block">
            <i class="fa-solid fa-database"></i> Create Manual Backup Now
          </button>
        </form>
      </div>
    </div>

    <!-- Backup info box -->
    <div class="card card-dark">
      <div class="card-body" style="padding:.9rem 1.1rem">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.6rem;text-align:center">
          <div style="background:var(--ad-bg);border-radius:var(--radius-sm);padding:.7rem">
            <div style="font-size:1.4rem;font-weight:800;color:var(--primary)">
              <?= count(array_filter($backups, fn($b)=>$b['type']==='auto')) ?>
            </div>
            <div style="font-size:.72rem;color:var(--ad-muted);text-transform:uppercase;letter-spacing:.4px">Auto Backups</div>
          </div>
          <div style="background:var(--ad-bg);border-radius:var(--radius-sm);padding:.7rem">
            <div style="font-size:1.4rem;font-weight:800;color:var(--success)">
              <?= count(array_filter($backups, fn($b)=>$b['type']==='manual')) ?>
            </div>
            <div style="font-size:.72rem;color:var(--ad-muted);text-transform:uppercase;letter-spacing:.4px">Manual Backups</div>
          </div>
        </div>
        <form method="POST" style="margin-top:.8rem;display:flex;align-items:center;gap:.5rem">
          <input type="hidden" name="post_action" value="prune">
          <label style="color:var(--ad-muted);font-size:.82rem;white-space:nowrap">Keep latest</label>
          <input type="number" name="keep" value="7" min="1" max="30" class="form-control" style="width:60px;padding:.35rem .5rem;font-size:.82rem">
          <label style="color:var(--ad-muted);font-size:.82rem;white-space:nowrap">backups</label>
          <button type="submit" class="btn btn-secondary btn-sm" style="white-space:nowrap"
            data-confirm="Delete older backups beyond your keep limit?">
            <i class="fa-solid fa-broom"></i> Prune Old
          </button>
        </form>
      </div>
    </div>

  </div>
</div>

<!-- Backup history table -->
<div class="card card-dark" style="margin-top:1.2rem">
  <div class="card-header">
    <h3><i class="fa-solid fa-clock-rotate-left" style="color:var(--warning)"></i>&nbsp; Backup History</h3>
    <span style="font-size:.82rem;color:var(--ad-muted)"><?= count($backups) ?> backups stored</span>
  </div>
  <div class="card-body" style="padding:0">
    <?php if (empty($backups)): ?>
      <div class="empty-state">
        <div class="empty-icon">💾</div>
        <h3>No backups yet</h3>
        <p>Auto-backup runs once daily. You can also create a manual backup above.</p>
      </div>
    <?php else: ?>
    <div class="table-wrapper">
      <table class="table table-dark">
        <thead>
          <tr>
            <th>Filename</th>
            <th>Type</th>
            <th>Size</th>
            <th>Created</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($backups as $b): ?>
          <tr>
            <td>
              <i class="fa-solid fa-file-code" style="color:var(--ad-muted);margin-right:.4rem"></i>
              <code style="font-size:.78rem;color:var(--ad-text)"><?= htmlspecialchars($b['filename']) ?></code>
            </td>
            <td>
              <?php if ($b['type']==='auto'): ?>
                <span class="badge badge-info">Auto</span>
              <?php else: ?>
                <span class="badge badge-success">Manual</span>
              <?php endif; ?>
            </td>
            <td style="color:var(--ad-muted)"><?= Backup::formatBytes((int)$b['size_bytes']) ?></td>
            <td style="color:var(--ad-muted);font-size:.82rem">
              <?= date('M j, Y', strtotime($b['created_at'])) ?><br>
              <span style="font-size:.75rem"><?= date('h:i A', strtotime($b['created_at'])) ?></span>
            </td>
            <td>
              <div style="display:flex;gap:.35rem">
                <a href="?dl=<?= urlencode($b['filename']) ?>" class="btn btn-success btn-sm" title="Download">
                  <i class="fa-solid fa-download"></i>
                </a>
                <form method="POST" style="display:inline">
                  <input type="hidden" name="post_action" value="delete_backup">
                  <input type="hidden" name="backup_id"   value="<?= $b['id'] ?>">
                  <button type="submit" class="btn btn-danger btn-sm"
                    data-confirm="Delete this backup file? This cannot be undone.">
                    <i class="fa-solid fa-trash"></i>
                  </button>
                </form>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
