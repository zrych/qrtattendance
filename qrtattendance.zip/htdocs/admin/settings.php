<?php
require_once __DIR__ . '/../includes/auth.php';
User::requireLogin('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    User::setSetting('school_name', clean($_POST['school_name'] ?? ''));
    setFlash('success', 'Settings saved successfully.');
    redirect('admin/settings.php');
}

$pageTitle = 'Settings';
$activeNav = 'settings';
require_once __DIR__ . '/../includes/header_admin.php';

$flash = getFlash();
?>

<?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] ?>">
    <i class="fa-solid fa-circle-info"></i> <?= htmlspecialchars($flash['msg']) ?>
  </div>
<?php endif; ?>

<div class="page-header">
  <div><h1>System Settings</h1><p>Configure general system preferences</p></div>
</div>

<div style="max-width:600px">
  <div class="card card-dark">
    <div class="card-header">
      <h3><i class="fa-solid fa-gear" style="color:var(--primary)"></i>&nbsp; General Settings</h3>
    </div>
    <div class="card-body">
      <form method="POST" class="dark-form">
        <div class="form-group">
          <label class="form-label">School / Institution Name</label>
          <input type="text" name="school_name" class="form-control"
                 value="<?= htmlspecialchars(User::getSetting('school_name') ?? '') ?>"
                 placeholder="e.g. Mindanao State University">
          <small style="color:var(--ad-muted)">Displayed on the login page and admin header.</small>
        </div>
        <button type="submit" class="btn btn-primary" style="margin-top:.5rem">
          <i class="fa-solid fa-floppy-disk"></i> Save Settings
        </button>
      </form>
    </div>
  </div>

  <div class="card card-dark" style="margin-top:1rem">
    <div class="card-header">
      <h3><i class="fa-solid fa-circle-info" style="color:var(--info)"></i>&nbsp; Attendance Time Rules</h3>
    </div>
    <div class="card-body">
      <p style="color:var(--ad-muted);font-size:.875rem;line-height:1.6">
        Attendance time rules — including the <strong>late threshold</strong> and
        <strong>absent threshold</strong> — are now configured <strong>per subject</strong>
        in the <a href="<?= BASE_URL ?>/admin/subjects.php" style="color:var(--primary)">Subjects &amp; Schedule</a> page.
      </p>
      <p style="color:var(--ad-muted);font-size:.875rem;line-height:1.6;margin-top:.5rem">
        Each subject has its own independent window: attendance opens at the subject's
        start time and closes at its end time. You can define how many minutes after
        start counts as Late, and how many minutes after start counts as Absent —
        directly on each subject's Add or Edit form.
      </p>
      <a href="<?= BASE_URL ?>/admin/subjects.php" class="btn btn-secondary btn-sm" style="margin-top:.5rem">
        <i class="fa-solid fa-calendar-week"></i> Go to Subjects &amp; Schedule
      </a>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
