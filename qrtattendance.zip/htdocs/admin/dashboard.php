<?php
require_once __DIR__ . '/../includes/auth.php';
User::requireLogin('admin');

$attendanceClass = new Attendance();
$studentClass    = new Student();

$todayCounts   = $attendanceClass->countToday();
$totalStudents = $studentClass->count();
$todayList     = $attendanceClass->getToday();
$recentAll     = $attendanceClass->getAll(['limit' => 10]);

$pageTitle    = 'Dashboard';
$pageSubtitle = 'Welcome back, ' . htmlspecialchars($_SESSION['username']);
$activeNav    = 'dashboard';
require_once __DIR__ . '/../includes/header_admin.php';

$flash = getFlash();
?>

<?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] ?>">
    <i class="fa-solid fa-circle-info"></i> <?= htmlspecialchars($flash['msg']) ?>
  </div>
<?php endif; ?>

<!-- Stat cards -->
<div class="stat-cards mb-2">
  <div class="stat-card stat-card-dark">
    <div class="stat-icon stat-icon-primary"><i class="fa-solid fa-users"></i></div>
    <div class="stat-info">
      <div class="stat-label">Total Students</div>
      <div class="stat-value"><?= $totalStudents ?></div>
    </div>
  </div>
  <div class="stat-card stat-card-dark">
    <div class="stat-icon stat-icon-success"><i class="fa-solid fa-user-check"></i></div>
    <div class="stat-info">
      <div class="stat-label">Present Today</div>
      <div class="stat-value"><?= $todayCounts['present'] ?></div>
    </div>
  </div>
  <div class="stat-card stat-card-dark">
    <div class="stat-icon stat-icon-warning"><i class="fa-solid fa-clock"></i></div>
    <div class="stat-info">
      <div class="stat-label">Late Today</div>
      <div class="stat-value"><?= $todayCounts['late'] ?></div>
    </div>
  </div>
  <div class="stat-card stat-card-dark">
    <div class="stat-icon stat-icon-danger"><i class="fa-solid fa-calendar-xmark"></i></div>
    <div class="stat-info">
      <div class="stat-label">Absent Today</div>
      <div class="stat-value"><?= max(0, $totalStudents - $todayCounts['total']) ?></div>
    </div>
  </div>
</div>

<!-- Quick actions -->
<div style="display:flex;gap:.8rem;margin-bottom:1.5rem;flex-wrap:wrap">
  <a href="<?= BASE_URL ?>/admin/scan.php" class="btn btn-primary">
    <i class="fa-solid fa-camera"></i> Start Scanning
  </a>
  <a href="<?= BASE_URL ?>/admin/students.php?action=add" class="btn btn-success">
    <i class="fa-solid fa-user-plus"></i> Add Student
  </a>
  <a href="<?= BASE_URL ?>/admin/attendance.php" class="btn btn-secondary">
    <i class="fa-solid fa-list"></i> View All Records
  </a>
</div>

<!-- Two-column layout -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:1.2rem">

  <!-- Today's attendance -->
  <div class="card card-dark" style="grid-column:1/-1">
    <div class="card-header">
      <h3><i class="fa-solid fa-calendar-day" style="color:var(--primary)"></i>&nbsp; Today's Attendance
        <span class="badge badge-info" style="margin-left:.5rem"><?= date('F j, Y') ?></span>
      </h3>
      <a href="<?= BASE_URL ?>/admin/attendance.php" class="btn btn-secondary btn-sm">View All</a>
    </div>
    <div class="card-body" style="padding:0">
      <?php if (empty($todayList)): ?>
        <div class="empty-state">
          <div class="empty-icon">📋</div>
          <h3>No attendance recorded today</h3>
          <p>Go to Scan QR Code to start marking attendance.</p>
        </div>
      <?php else: ?>
        <div class="table-wrapper">
          <table class="table table-dark">
            <thead>
              <tr>
                <th>Student</th>
                <th>ID Number</th>
                <th>Course</th>
                <th>Time In</th>
                <th>Time Out</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($todayList as $row): ?>
              <tr>
                <td><strong><?= htmlspecialchars($row['last_name'] . ', ' . $row['first_name']) ?></strong></td>
                <td><?= htmlspecialchars($row['student_number']) ?></td>
                <td><?= htmlspecialchars($row['course']) ?></td>
                <td><?= $row['time_in']  ? date('h:i A', strtotime($row['time_in']))  : '—' ?></td>
                <td><?= $row['time_out'] ? date('h:i A', strtotime($row['time_out'])) : '<span style="color:var(--ad-muted)">Not yet</span>' ?></td>
                <td>
                  <?php if ($row['status'] === 'present'): ?>
                    <span class="badge badge-success"><i class="fa-solid fa-check"></i> Present</span>
                  <?php elseif ($row['status'] === 'late'): ?>
                    <span class="badge badge-warning"><i class="fa-solid fa-clock"></i> Late</span>
                  <?php else: ?>
                    <span class="badge badge-danger"><i class="fa-solid fa-xmark"></i> Absent</span>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
