<?php
require_once __DIR__ . '/../includes/auth.php';
User::requireLogin('admin');

$studentClass = new Student();
$userClass    = new User();
$action       = $_GET['action'] ?? 'list';
$editId       = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// ── Handle POST ───────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postAction = $_POST['action'] ?? '';

    if ($postAction === 'add') {
        $result = $studentClass->create([
            'student_number' => $_POST['student_number'] ?? '',
            'first_name'     => $_POST['first_name']     ?? '',
            'last_name'      => $_POST['last_name']      ?? '',
            'course'         => $_POST['course']         ?? '',
            'year_level'     => $_POST['year_level']     ?? 1,
            'section'        => $_POST['section']        ?? '',
            'email'          => $_POST['email']          ?? '',
            'username'       => $_POST['username']       ?? '',
            'password'       => $_POST['password']       ?? '',
        ]);
        setFlash($result['success'] ? 'success' : 'danger', $result['message']);
        redirect('admin/students.php');
    }

    if ($postAction === 'edit') {
        $sid    = (int)($_POST['student_id'] ?? 0);
        $result = $studentClass->update($sid, [
            'first_name'  => $_POST['first_name']  ?? '',
            'last_name'   => $_POST['last_name']   ?? '',
            'course'      => $_POST['course']      ?? '',
            'year_level'  => $_POST['year_level']  ?? 1,
            'section'     => $_POST['section']     ?? '',
            'email'       => $_POST['email']       ?? '',
            'username'    => $_POST['username']    ?? '',
            'password'    => $_POST['password']    ?? '',
        ]);
        setFlash($result['success'] ? 'success' : 'danger', $result['message']);
        redirect('admin/students.php');
    }

    if ($postAction === 'delete') {
        $sid = (int)($_POST['student_id'] ?? 0);
        $ok  = $studentClass->delete($sid);
        setFlash($ok ? 'success' : 'danger', $ok ? 'Student deleted.' : 'Failed to delete student.');
        redirect('admin/students.php');
    }

    if ($postAction === 'regen_qr') {
        $sid = (int)($_POST['student_id'] ?? 0);
        $studentClass->regenerateQr($sid);
        setFlash('success', 'QR code regenerated successfully.');
        redirect('admin/students.php');
    }
}

// ── Fetch data ─────────────────────────────────────────────────
$search   = clean($_GET['q'] ?? '');
$students = $studentClass->getAll($search);
$editStudent = ($action === 'edit' && $editId) ? $studentClass->findById($editId) : null;

$pageTitle = 'Students';
$activeNav = 'students';
require_once __DIR__ . '/../includes/header_admin.php';

$flash = getFlash();
?>

<?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] ?>">
    <i class="fa-solid fa-circle-info"></i> <?= htmlspecialchars($flash['msg']) ?>
  </div>
<?php endif; ?>

<div class="page-header">
  <div>
    <h1>Students</h1>
    <p><?= count($students) ?> student<?= count($students) !== 1 ? 's' : '' ?> registered</p>
  </div>
  <button class="btn btn-primary" onclick="openModal('modalAdd')">
    <i class="fa-solid fa-user-plus"></i> Add Student
  </button>
</div>

<!-- Search toolbar -->
<div class="toolbar">
  <form method="GET" style="display:flex;gap:.6rem;flex:1">
    <div class="search-box">
      <i class="fa-solid fa-search search-icon"></i>
      <input type="text" name="q" class="form-control"
             placeholder="Search by name, ID, course…"
             value="<?= htmlspecialchars($search) ?>">
    </div>
    <button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-search"></i> Search</button>
    <?php if ($search): ?>
      <a href="<?= BASE_URL ?>/admin/students.php" class="btn btn-secondary btn-sm">Clear</a>
    <?php endif; ?>
  </form>
</div>

<!-- Students table -->
<div class="card card-dark">
  <div class="card-body" style="padding:0">
    <?php if (empty($students)): ?>
      <div class="empty-state">
        <div class="empty-icon">👩‍🎓</div>
        <h3>No students found</h3>
        <p><?= $search ? 'Try a different search term.' : 'Click "Add Student" to get started.' ?></p>
      </div>
    <?php else: ?>
      <div class="table-wrapper">
        <table class="table table-dark">
          <thead>
            <tr>
              <th>#</th>
              <th>Student</th>
              <th>Student Number</th>
              <th>Course / Year</th>
              <th>Section</th>
              <th>Username</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($students as $i => $s): ?>
            <tr>
              <td style="color:var(--ad-muted)"><?= $i + 1 ?></td>
              <td>
                <div style="font-weight:600"><?= htmlspecialchars($s['last_name'] . ', ' . $s['first_name']) ?></div>
                <div style="font-size:.78rem;color:var(--ad-muted)"><?= htmlspecialchars($s['email']) ?></div>
              </td>
              <td><code style="background:var(--ad-bg);padding:.15rem .5rem;border-radius:4px;font-size:.82rem"><?= htmlspecialchars($s['student_number']) ?></code></td>
              <td><?= htmlspecialchars($s['course']) ?> <span style="color:var(--ad-muted)">Yr <?= $s['year_level'] ?></span></td>
              <td><?= htmlspecialchars($s['section']) ?: '<span style="color:var(--ad-muted)">—</span>' ?></td>
              <td><?= htmlspecialchars($s['username']) ?></td>
              <td>
                <?php if ($s['is_active']): ?>
                  <span class="badge badge-success">Active</span>
                <?php else: ?>
                  <span class="badge badge-danger">Inactive</span>
                <?php endif; ?>
              </td>
              <td>
                <div style="display:flex;gap:.35rem;flex-wrap:wrap">
                  <button class="btn btn-info btn-sm"
                    onclick="openEdit(<?= htmlspecialchars(json_encode($s)) ?>)">
                    <i class="fa-solid fa-pen"></i>
                  </button>
                  <button class="btn btn-warning btn-sm"
                    onclick="regenQr(<?= $s['id'] ?>, '<?= htmlspecialchars($s['first_name'] . ' ' . $s['last_name']) ?>')">
                    <i class="fa-solid fa-rotate"></i>
                  </button>
                  <form method="POST" style="display:inline">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="student_id" value="<?= $s['id'] ?>">
                    <button type="submit" class="btn btn-danger btn-sm"
                      data-confirm="Delete <?= htmlspecialchars($s['first_name'] . ' ' . $s['last_name']) ?>? This cannot be undone.">
                      <i class="fa-solid fa-trash"></i>
                    </button>
                  </form>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- ── ADD STUDENT MODAL ── -->
<div class="modal-overlay hidden" id="modalAdd">
  <div class="modal">
    <div class="modal-header">
      <h3><i class="fa-solid fa-user-plus" style="color:var(--primary)"></i>&nbsp; Add New Student</h3>
      <button class="modal-close" onclick="closeModal('modalAdd')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <form method="POST" class="dark-form" id="formAdd">
        <input type="hidden" name="action" value="add">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">First Name *</label>
            <input type="text" name="first_name" class="form-control" required placeholder="e.g. Maria">
          </div>
          <div class="form-group">
            <label class="form-label">Last Name *</label>
            <input type="text" name="last_name" class="form-control" required placeholder="e.g. Santos">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Student Number *</label>
          <input type="text" name="student_number" class="form-control" required placeholder="e.g. 2024-00001">
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Course</label>
            <input type="text" name="course" class="form-control" placeholder="e.g. BSIT">
          </div>
          <div class="form-group">
            <label class="form-label">Year Level</label>
            <select name="year_level" class="form-control">
              <?php for ($y = 1; $y <= 5; $y++): ?>
                <option value="<?= $y ?>">Year <?= $y ?></option>
              <?php endfor; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Section</label>
            <input type="text" name="section" class="form-control" placeholder="e.g. A">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-control" placeholder="student@email.com">
        </div>
        <hr style="border-color:var(--ad-border);margin:1rem 0">
        <p style="color:var(--ad-muted);font-size:.82rem;margin-bottom:.8rem">
          <i class="fa-solid fa-circle-info"></i> These credentials will be used by the student to log in.
        </p>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Username *</label>
            <input type="text" name="username" class="form-control" required placeholder="e.g. 2024-00001">
          </div>
          <div class="form-group">
            <label class="form-label">Password *</label>
            <input type="password" name="password" class="form-control" required placeholder="Min. 6 chars">
          </div>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal('modalAdd')">Cancel</button>
      <button class="btn btn-primary" onclick="document.getElementById('formAdd').submit()">
        <i class="fa-solid fa-floppy-disk"></i> Save Student
      </button>
    </div>
  </div>
</div>

<!-- ── EDIT STUDENT MODAL ── -->
<div class="modal-overlay hidden" id="modalEdit">
  <div class="modal">
    <div class="modal-header">
      <h3><i class="fa-solid fa-pen" style="color:var(--info)"></i>&nbsp; Edit Student</h3>
      <button class="modal-close" onclick="closeModal('modalEdit')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <form method="POST" class="dark-form" id="formEdit">
        <input type="hidden" name="action" value="edit">
        <input type="hidden" name="student_id" id="editStudentId">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">First Name *</label>
            <input type="text" name="first_name" id="editFirstName" class="form-control" required>
          </div>
          <div class="form-group">
            <label class="form-label">Last Name *</label>
            <input type="text" name="last_name" id="editLastName" class="form-control" required>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Student Number</label>
          <input type="text" id="editStudentNumber" class="form-control" disabled>
          <small style="color:var(--ad-muted)">Student number cannot be changed.</small>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Course</label>
            <input type="text" name="course" id="editCourse" class="form-control">
          </div>
          <div class="form-group">
            <label class="form-label">Year Level</label>
            <select name="year_level" id="editYearLevel" class="form-control">
              <?php for ($y = 1; $y <= 5; $y++): ?>
                <option value="<?= $y ?>">Year <?= $y ?></option>
              <?php endfor; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Section</label>
            <input type="text" name="section" id="editSection" class="form-control">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" name="email" id="editEmail" class="form-control">
        </div>
        <hr style="border-color:var(--ad-border);margin:1rem 0">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Username</label>
            <input type="text" name="username" id="editUsername" class="form-control">
          </div>
          <div class="form-group">
            <label class="form-label">New Password <small style="color:var(--ad-muted)">(leave blank to keep)</small></label>
            <input type="password" name="password" class="form-control" placeholder="Leave blank to keep current">
          </div>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal('modalEdit')">Cancel</button>
      <button class="btn btn-info" onclick="document.getElementById('formEdit').submit()">
        <i class="fa-solid fa-floppy-disk"></i> Update Student
      </button>
    </div>
  </div>
</div>

<!-- ── REGEN QR FORM (hidden) ── -->
<form method="POST" id="formRegenQr">
  <input type="hidden" name="action" value="regen_qr">
  <input type="hidden" name="student_id" id="regenStudentId">
</form>

<script>
function openModal(id)  { document.getElementById(id).classList.remove('hidden'); }
function closeModal(id) { document.getElementById(id).classList.add('hidden');    }

// Close on overlay click
document.querySelectorAll('.modal-overlay').forEach(ov => {
  ov.addEventListener('click', e => { if (e.target === ov) ov.classList.add('hidden'); });
});

function openEdit(s) {
  document.getElementById('editStudentId').value    = s.id;
  document.getElementById('editFirstName').value    = s.first_name;
  document.getElementById('editLastName').value     = s.last_name;
  document.getElementById('editStudentNumber').value= s.student_number;
  document.getElementById('editCourse').value       = s.course     || '';
  document.getElementById('editYearLevel').value    = s.year_level || 1;
  document.getElementById('editSection').value      = s.section    || '';
  document.getElementById('editEmail').value        = s.email      || '';
  document.getElementById('editUsername').value     = s.username   || '';
  openModal('modalEdit');
}

function regenQr(id, name) {
  if (confirm('Regenerate QR code for ' + name + '?\nThe old QR code will no longer work.')) {
    document.getElementById('regenStudentId').value = id;
    document.getElementById('formRegenQr').submit();
  }
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
