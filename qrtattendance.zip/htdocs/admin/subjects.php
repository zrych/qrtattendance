<?php
require_once __DIR__ . '/../includes/auth.php';
User::requireLogin('admin');

$subjectClass  = new Subject();
$studentClass  = new Student();
$notifClass    = new Notification();

// ── POST Handlers ─────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['post_action'] ?? '';

    if ($act === 'add') {
        $subjectClass->create([
            'code'                => $_POST['code']           ?? '',
            'name'                => $_POST['name']           ?? '',
            'day_of_week'         => $_POST['day_of_week']    ?? 'Monday',
            'time_start'          => $_POST['time_start']     ?? '07:00',
            'time_end'            => $_POST['time_end']       ?? '08:00',
            'room'                => $_POST['room']           ?? '',
            'instructor'          => $_POST['instructor']     ?? '',
            'late_minutes'        => (int)($_POST['late_minutes']        ?? 15),
            'absent_minutes'      => (int)($_POST['absent_minutes']      ?? 45),
            'enrollment_password' => $_POST['enrollment_password']       ?? '',
            'enrollment_open'     => isset($_POST['enrollment_open']) ? 1 : 0,
        ]);
        setFlash('success', 'Subject added successfully.');
        redirect('admin/subjects.php');
    }

    if ($act === 'edit') {
        $subjectClass->update((int)$_POST['subject_id'], [
            'code'                => $_POST['code']           ?? '',
            'name'                => $_POST['name']           ?? '',
            'day_of_week'         => $_POST['day_of_week']    ?? 'Monday',
            'time_start'          => $_POST['time_start']     ?? '07:00',
            'time_end'            => $_POST['time_end']       ?? '08:00',
            'room'                => $_POST['room']           ?? '',
            'instructor'          => $_POST['instructor']     ?? '',
            'is_active'           => $_POST['is_active']      ?? 1,
            'late_minutes'        => (int)($_POST['late_minutes']        ?? 15),
            'absent_minutes'      => (int)($_POST['absent_minutes']      ?? 45),
            'enrollment_password' => $_POST['enrollment_password']       ?? '',
            'enrollment_open'     => isset($_POST['enrollment_open']) ? 1 : 0,
        ]);
        setFlash('success', 'Subject updated.');
        redirect('admin/subjects.php');
    }

    if ($act === 'delete') {
        $subjectClass->delete((int)$_POST['subject_id']);
        setFlash('success', 'Subject deleted.');
        redirect('admin/subjects.php');
    }

    if ($act === 'toggle_enrollment') {
        $sid  = (int)$_POST['subject_id'];
        $open = (bool)(int)$_POST['enrollment_open'];
        $subjectClass->toggleEnrollment($sid, $open);
        setFlash('success', 'Enrollment ' . ($open ? 'opened' : 'closed') . '.');
        redirect('admin/subjects.php');
    }

    if ($act === 'send_invites') {
        $sid      = (int)$_POST['subject_id'];
        $sections = $_POST['section_keys'] ?? [];
        if (empty($sections)) {
            setFlash('warning', 'No sections selected. No invitations sent.');
        } else {
            $n = $notifClass->notifySections($sid, $sections);
            setFlash('success', $n . ' invitation(s) sent across ' . count($sections) . ' section group(s).');
        }
        redirect('admin/subjects.php');
    }

    if ($act === 'enroll') {
        $sid = (int)$_POST['subject_id'];
        $ids = $_POST['student_ids'] ?? [];
        if (!empty($ids)) {
            $subjectClass->enrollBulk($sid, $ids);
            setFlash('success', count($ids) . ' student(s) enrolled.');
        } else {
            setFlash('warning', 'No students selected.');
        }
        redirect('admin/subjects.php?view=' . $sid);
    }

    if ($act === 'unenroll') {
        $subjectClass->unenroll((int)$_POST['subject_id'], (int)$_POST['student_id']);
        setFlash('success', 'Student unenrolled.');
        redirect('admin/subjects.php?view=' . $_POST['subject_id']);
    }
}

// ── View ──────────────────────────────────────────────────────
$viewId      = isset($_GET['view']) ? (int)$_GET['view'] : 0;
$viewSubject = $viewId ? $subjectClass->findById($viewId) : null;
$enrolled    = $viewId ? $subjectClass->getEnrolledStudents($viewId)   : [];
$unenrolled  = $viewId ? $subjectClass->getUnenrolledStudents($viewId) : [];

try {
    $subjects = $subjectClass->getAll();
} catch (Exception $e) {
    $subjects = [];
}

try {
    $allSections = $subjectClass->getAllSections();
} catch (Exception $e) {
    $allSections = [];
}

// Add invite join count — catch DB errors gracefully
foreach ($subjects as &$sub) {
    try {
        $sub['invite_joined']       = $notifClass->getInviteJoinCount((int)$sub['id']);
        $sub['enrollment_open']     = $sub['enrollment_open']     ?? 0;
        $sub['enrollment_password'] = $sub['enrollment_password'] ?? null;
    } catch (Exception $e) {
        $sub['invite_joined']       = 0;
        $sub['enrollment_open']     = 0;
        $sub['enrollment_password'] = null;
    }
}
unset($sub);

$pageTitle = 'Subjects & Schedule';
$activeNav = 'subjects';
require_once __DIR__ . '/../includes/header_admin.php';
$flash = getFlash();
?>

<?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] ?>">
    <i class="fa-solid fa-circle-info"></i> <?= htmlspecialchars($flash['msg']) ?>
  </div>
<?php endif; ?>

<?php if ($viewSubject): ?>
<!-- ═══════════════ ENROLLMENT VIEW ═══════════════ -->
<div class="page-header">
  <div>
    <a href="<?= BASE_URL ?>/admin/subjects.php" style="font-size:.82rem;color:var(--ad-muted)">
      <i class="fa-solid fa-arrow-left"></i> Back to Subjects
    </a>
    <h1 style="margin-top:.3rem">
      <span style="color:var(--primary)"><?= htmlspecialchars($viewSubject['code']) ?></span>
      — <?= htmlspecialchars($viewSubject['name']) ?>
    </h1>
    <p><?= Subject::formatSchedule($viewSubject) ?>
      <?php if ($viewSubject['room']): ?> · Room <?= htmlspecialchars($viewSubject['room']) ?><?php endif; ?>
      <?php if ($viewSubject['instructor']): ?> · <?= htmlspecialchars($viewSubject['instructor']) ?><?php endif; ?>
    </p>
  </div>
  <?php if (Subject::isOngoing($viewSubject)): ?>
    <span class="badge badge-success animate-pulse" style="font-size:.9rem;padding:.5rem 1rem">
      <i class="fa-solid fa-circle"></i> Currently Ongoing
    </span>
  <?php endif; ?>
</div>

<!-- Attendance rules + enrollment status bar -->
<div style="display:grid;grid-template-columns:1fr auto;gap:1rem;margin-bottom:1.2rem;align-items:start">
  <div style="background:rgba(99,102,241,.08);border:1px solid rgba(99,102,241,.25);border-radius:var(--radius);padding:.9rem 1.2rem">
    <div style="font-size:.85rem;color:var(--ad-text)">
      <strong>Attendance Window:</strong>
      <?= date('h:i A', strtotime($viewSubject['time_start'])) ?> – <?= date('h:i A', strtotime($viewSubject['time_end'])) ?>
      &nbsp;|&nbsp;
      <strong>Late after:</strong> <?= (int)($viewSubject['late_minutes'] ?? 15) ?> min
      &nbsp;|&nbsp;
      <strong>Absent after:</strong> <?= (int)($viewSubject['absent_minutes'] ?? 45) ?> min
    </div>
  </div>
  <div>
    <?php $eOpen = (bool)$viewSubject['enrollment_open']; ?>
    <form method="POST" style="display:inline">
      <input type="hidden" name="post_action"     value="toggle_enrollment">
      <input type="hidden" name="subject_id"      value="<?= $viewSubject['id'] ?>">
      <input type="hidden" name="enrollment_open" value="<?= $eOpen ? 0 : 1 ?>">
      <button type="submit" class="btn <?= $eOpen ? 'btn-warning' : 'btn-success' ?>">
        <i class="fa-solid fa-<?= $eOpen ? 'lock-open' : 'lock' ?>"></i>
        Enrollment <?= $eOpen ? 'Open — Click to Close' : 'Closed — Click to Open' ?>
      </button>
    </form>
  </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:1.2rem">

  <!-- Enrolled students -->
  <div class="card card-dark">
    <div class="card-header">
      <h3><i class="fa-solid fa-user-check" style="color:var(--success)"></i>&nbsp;
        Enrolled Students <span class="badge badge-success"><?= count($enrolled) ?></span>
      </h3>
    </div>
    <div class="card-body" style="padding:0">
      <?php if (empty($enrolled)): ?>
        <div class="empty-state"><div class="empty-icon">👥</div>
          <h3>No students enrolled</h3><p>Add students from the right panel or send invitations.</p>
        </div>
      <?php else: ?>
        <div class="table-wrapper">
          <table class="table table-dark">
            <thead><tr><th>Student</th><th>No.</th><th>Course / Year</th><th></th></tr></thead>
            <tbody>
              <?php foreach ($enrolled as $s): ?>
              <tr>
                <td><strong><?= htmlspecialchars($s['last_name'].', '.$s['first_name']) ?></strong></td>
                <td><code style="background:var(--ad-bg);padding:.1rem .4rem;border-radius:4px;font-size:.78rem"><?= htmlspecialchars($s['student_number']) ?></code></td>
                <td style="color:var(--ad-muted);font-size:.82rem"><?= htmlspecialchars($s['course']) ?> Y<?= $s['year_level'] ?></td>
                <td>
                  <form method="POST">
                    <input type="hidden" name="post_action" value="unenroll">
                    <input type="hidden" name="subject_id"  value="<?= $viewId ?>">
                    <input type="hidden" name="student_id"  value="<?= $s['id'] ?>">
                    <button type="submit" class="btn btn-danger btn-sm"
                      data-confirm="Remove <?= htmlspecialchars($s['first_name']) ?> from this subject?">
                      <i class="fa-solid fa-user-minus"></i>
                    </button>
                  </form>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Add students manually -->
  <div class="card card-dark">
    <div class="card-header">
      <h3><i class="fa-solid fa-user-plus" style="color:var(--primary)"></i>&nbsp;
        Add Students Manually <span class="badge badge-secondary"><?= count($unenrolled) ?></span>
      </h3>
    </div>
    <div class="card-body">
      <?php if (empty($unenrolled)): ?>
        <div class="empty-state"><div class="empty-icon">✅</div>
          <h3>All students enrolled</h3>
        </div>
      <?php else: ?>
        <form method="POST" class="dark-form">
          <input type="hidden" name="post_action" value="enroll">
          <input type="hidden" name="subject_id"  value="<?= $viewId ?>">
          <div class="form-group">
            <label class="form-label">Select students to enroll directly</label>
            <div style="background:var(--ad-bg);border:1.5px solid var(--ad-border);border-radius:var(--radius-sm);max-height:280px;overflow-y:auto;padding:.4rem">
              <?php foreach ($unenrolled as $s): ?>
              <label style="display:flex;align-items:center;gap:.7rem;padding:.55rem .7rem;border-radius:6px;cursor:pointer"
                     onmouseover="this.style.background='var(--ad-surface2)'"
                     onmouseout="this.style.background=''">
                <input type="checkbox" name="student_ids[]" value="<?= $s['id'] ?>"
                       style="width:16px;height:16px;accent-color:var(--primary)">
                <div>
                  <div style="font-weight:600;font-size:.875rem"><?= htmlspecialchars($s['last_name'].', '.$s['first_name']) ?></div>
                  <div style="font-size:.75rem;color:var(--ad-muted)"><?= htmlspecialchars($s['student_number']) ?> · <?= htmlspecialchars($s['course']) ?> Y<?= $s['year_level'] ?></div>
                </div>
              </label>
              <?php endforeach; ?>
            </div>
          </div>
          <div style="display:flex;gap:.6rem;margin-top:.5rem">
            <button type="button" class="btn btn-secondary btn-sm" onclick="chkAll(true)">All</button>
            <button type="button" class="btn btn-secondary btn-sm" onclick="chkAll(false)">None</button>
            <button type="submit" class="btn btn-primary btn-sm" style="margin-left:auto">
              <i class="fa-solid fa-user-plus"></i> Enroll Selected
            </button>
          </div>
        </form>
      <?php endif; ?>
    </div>
  </div>

</div>

<script>
function chkAll(s) { document.querySelectorAll('input[name="student_ids[]"]').forEach(c=>c.checked=s); }
</script>

<?php else: ?>
<!-- ═══════════════ SUBJECTS LIST ═══════════════ -->
<div class="page-header">
  <div>
    <h1>Subjects &amp; Schedule</h1>
    <p><?= count($subjects) ?> subject<?= count($subjects)!==1?'s':'' ?> configured</p>
  </div>
  <button class="btn btn-primary" onclick="openModal('modalAdd')">
    <i class="fa-solid fa-plus"></i> Add Subject
  </button>
</div>

<!-- Today highlight -->
<?php try { $todaySubjects = $subjectClass->getTodaysSubjects(); } catch(Exception $e) { $todaySubjects = []; } ?>
<?php if (!empty($todaySubjects)): ?>
<div style="background:rgba(99,102,241,.08);border:1px solid rgba(99,102,241,.2);border-radius:var(--radius);padding:1rem 1.3rem;margin-bottom:1.2rem;display:flex;align-items:center;gap:1rem;flex-wrap:wrap">
  <div style="font-size:1.3rem">📅</div>
  <div>
    <div style="font-weight:700">Today — <?= date('l') ?></div>
    <div style="display:flex;gap:.6rem;flex-wrap:wrap;margin-top:.4rem">
      <?php foreach ($todaySubjects as $ts): ?>
        <span class="badge <?= Subject::isOngoing($ts)?'badge-success':'badge-secondary' ?>">
          <?php if (Subject::isOngoing($ts)): ?><i class="fa-solid fa-circle" style="font-size:.5rem"></i>&nbsp;<?php endif; ?>
          <?= htmlspecialchars($ts['code']) ?> · <?= date('h:i',strtotime($ts['time_start'])) ?>–<?= date('h:i',strtotime($ts['time_end'])) ?>
        </span>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- Weekly calendar strip -->
<div class="card card-dark" style="margin-bottom:1.2rem">
  <div class="card-header">
    <h3><i class="fa-solid fa-calendar-week" style="color:var(--primary)"></i>&nbsp; Weekly Schedule</h3>
  </div>
  <div class="card-body" style="padding:1rem">
    <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:.5rem;text-align:center">
      <?php foreach (Subject::$DAYS as $day):
        $ds      = array_filter($subjects, fn($s)=>$s['day_of_week']===$day);
        $isToday = date('l')===$day;
      ?>
      <div style="background:<?=$isToday?'rgba(99,102,241,.12)':'var(--ad-bg)'?>;border:1px solid <?=$isToday?'var(--primary)':'var(--ad-border)'?>;border-radius:var(--radius-sm);padding:.6rem .4rem;min-height:80px">
        <div style="font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:<?=$isToday?'var(--primary-light)':'var(--ad-muted)'?>;margin-bottom:.4rem"><?= substr($day,0,3) ?></div>
        <?php foreach ($ds as $d): ?>
          <div style="background:var(--primary);color:#fff;border-radius:4px;padding:.2rem .3rem;font-size:.65rem;font-weight:600;margin-bottom:.2rem;line-height:1.3">
            <?= htmlspecialchars($d['code']) ?><br>
            <span style="opacity:.85;font-weight:400"><?= date('h:i',strtotime($d['time_start'])) ?>–<?= date('h:i',strtotime($d['time_end'])) ?></span>
          </div>
        <?php endforeach; ?>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- Subjects table -->
<div class="card card-dark">
  <div class="card-body" style="padding:0">
    <?php if (empty($subjects)): ?>
      <div class="empty-state"><div class="empty-icon">📚</div><h3>No subjects yet</h3></div>
    <?php else: ?>
    <div class="table-wrapper">
      <table class="table table-dark">
        <thead>
          <tr>
            <th>Code</th><th>Subject Name</th><th>Schedule</th>
            <th>Time Rules</th><th>Room</th><th>Enrollment</th>
            <th>Students</th><th>Status</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($subjects as $sub): ?>
          <tr>
            <td><strong style="color:var(--primary-light);font-family:monospace"><?= htmlspecialchars($sub['code']) ?></strong></td>
            <td><?= htmlspecialchars($sub['name']) ?></td>
            <td>
              <div style="font-weight:600"><?= $sub['day_of_week'] ?></div>
              <div style="font-size:.78rem;color:var(--ad-muted)"><?= date('h:i A',strtotime($sub['time_start'])) ?> – <?= date('h:i A',strtotime($sub['time_end'])) ?></div>
            </td>
            <td style="font-size:.78rem">
              <div style="color:var(--success)">✓ ≤<?= (int)($sub['late_minutes']??15) ?>m</div>
              <div style="color:var(--warning)">⏰ ≤<?= (int)($sub['absent_minutes']??45) ?>m</div>
            </td>
            <td style="color:var(--ad-muted)"><?= htmlspecialchars($sub['room'] ?: '—') ?></td>
            <td>
              <?php if ($sub['enrollment_open']): ?>
                <span class="badge badge-success" style="font-size:.7rem"><i class="fa-solid fa-lock-open"></i> Open</span>
              <?php else: ?>
                <span class="badge badge-secondary" style="font-size:.7rem"><i class="fa-solid fa-lock"></i> Closed</span>
              <?php endif; ?>
              <?php if (empty($sub['enrollment_password'])): ?>
                <div style="font-size:.7rem;color:var(--warning);margin-top:.2rem">⚠ No code set</div>
              <?php else: ?>
                <div style="font-size:.7rem;color:var(--ad-muted);margin-top:.2rem"><i class="fa-solid fa-key"></i> Code set</div>
              <?php endif; ?>
            </td>
            <td>
              <div>
                <a href="?view=<?= $sub['id'] ?>" class="badge badge-info" style="text-decoration:none">
                  <i class="fa-solid fa-users"></i> <?= $sub['enrolled_count'] ?> enrolled
                </a>
              </div>
              <?php if ($sub['invite_joined'] > 0): ?>
                <div style="margin-top:.25rem">
                  <span class="badge badge-success" style="font-size:.7rem">
                    <i class="fa-solid fa-envelope-open-text"></i> <?= $sub['invite_joined'] ?> via invite
                  </span>
                </div>
              <?php endif; ?>
            </td>
            <td>
              <?php if ($sub['is_active']): ?>
                <span class="badge badge-success">Active</span>
              <?php else: ?>
                <span class="badge badge-secondary">Inactive</span>
              <?php endif; ?>
              <?php if (Subject::isOngoing($sub)): ?>
                <span class="badge badge-warning animate-pulse" style="margin-left:.3rem">Ongoing</span>
              <?php endif; ?>
            </td>
            <td>
              <div style="display:flex;gap:.3rem;flex-wrap:wrap">
                <a href="?view=<?= $sub['id'] ?>" class="btn btn-success btn-sm" title="Manage enrollment">
                  <i class="fa-solid fa-users"></i>
                </a>
                <button class="btn btn-warning btn-sm" title="Send invitations"
                  onclick='openInviteModal(<?= $sub["id"] ?>, <?= htmlspecialchars(json_encode($sub["code"]." — ".$sub["name"]), ENT_QUOTES) ?>)'>
                  <i class="fa-solid fa-envelope"></i>
                </button>
                <button class="btn btn-info btn-sm" title="Edit"
                  onclick='openEdit(<?= htmlspecialchars(json_encode($sub), ENT_QUOTES) ?>)'>
                  <i class="fa-solid fa-pen"></i>
                </button>
                <form method="POST" style="display:inline">
                  <input type="hidden" name="post_action" value="delete">
                  <input type="hidden" name="subject_id"  value="<?= $sub['id'] ?>">
                  <button type="submit" class="btn btn-danger btn-sm"
                    data-confirm="Delete <?= htmlspecialchars($sub['code']) ?>? This removes all enrollment data.">
                    <i class="fa-solid fa-trash"></i>
                  </button>
                </form>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- ── ADD MODAL ─────────────────────────────────────────── -->
<div class="modal-overlay hidden" id="modalAdd">
  <div class="modal" style="max-width:640px">
    <div class="modal-header">
      <h3><i class="fa-solid fa-plus" style="color:var(--primary)"></i>&nbsp; Add Subject</h3>
      <button class="modal-close" onclick="closeModal('modalAdd')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <form method="POST" class="dark-form" id="formAdd">
        <input type="hidden" name="post_action" value="add">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Code <span style="color:var(--danger)">*</span></label>
            <input type="text" name="code" class="form-control" placeholder="e.g. ITEP207" style="text-transform:uppercase" required>
          </div>
          <div class="form-group">
            <label class="form-label">Subject Name <span style="color:var(--danger)">*</span></label>
            <input type="text" name="name" class="form-control" placeholder="Web Systems & Technologies" required>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Day <span style="color:var(--danger)">*</span></label>
            <select name="day_of_week" class="form-control" required>
              <?php foreach (Subject::$DAYS as $d): ?><option value="<?=$d?>"><?=$d?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Start <span style="color:var(--danger)">*</span></label>
            <input type="time" name="time_start" class="form-control" value="07:00" required>
          </div>
          <div class="form-group">
            <label class="form-label">End <span style="color:var(--danger)">*</span></label>
            <input type="time" name="time_end" class="form-control" value="10:00" required>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Room</label>
            <input type="text" name="room" class="form-control" placeholder="e.g. Lab 3">
          </div>
          <div class="form-group">
            <label class="form-label">Instructor</label>
            <input type="text" name="instructor" class="form-control">
          </div>
        </div>

        <hr style="border-color:var(--ad-border);margin:1rem 0">
        <p style="font-size:.82rem;color:var(--ad-muted);margin-bottom:.8rem">
          <i class="fa-solid fa-clock"></i> <strong style="color:var(--ad-text)">Attendance Time Rules</strong>
        </p>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label"><i class="fa-solid fa-clock" style="color:var(--warning)"></i> Late Threshold (min)</label>
            <input type="number" name="late_minutes" class="form-control" value="15" min="1" max="120" required>
          </div>
          <div class="form-group">
            <label class="form-label"><i class="fa-solid fa-circle-xmark" style="color:var(--danger)"></i> Absent Threshold (min)</label>
            <input type="number" name="absent_minutes" class="form-control" value="45" min="1" max="240" required>
          </div>
        </div>

        <hr style="border-color:var(--ad-border);margin:1rem 0">
        <p style="font-size:.82rem;color:var(--ad-muted);margin-bottom:.8rem">
          <i class="fa-solid fa-key"></i> <strong style="color:var(--ad-text)">Self-Enrollment</strong>
          — students enter this code to join from their Subjects page
        </p>
        <div class="form-row">
          <div class="form-group" style="flex:2">
            <label class="form-label">Enrollment Code (invite password)</label>
            <div style="position:relative">
              <input type="text" name="enrollment_password" id="addEnrollPw" class="form-control"
                     placeholder="e.g. ITEP207-2A or leave blank to disable self-enrollment"
                     autocomplete="off">
              <button type="button" onclick="togglePw('addEnrollPw','addEnrollEye')"
                style="position:absolute;right:.7rem;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:var(--ad-muted)">
                <i id="addEnrollEye" class="fa-solid fa-eye"></i>
              </button>
            </div>
            <small style="color:var(--ad-muted)">Leave blank to prevent self-enrollment entirely.</small>
          </div>
          <div class="form-group" style="flex:1;display:flex;align-items:center;gap:.6rem;padding-top:1.5rem">
            <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;font-size:.9rem">
              <input type="checkbox" name="enrollment_open" id="addEnrollOpen" checked
                     style="width:16px;height:16px;accent-color:var(--primary)">
              <span style="color:var(--ad-text);font-weight:600">Enrollment Open</span>
            </label>
          </div>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal('modalAdd')">Cancel</button>
      <button class="btn btn-primary" onclick="document.getElementById('formAdd').submit()">
        <i class="fa-solid fa-floppy-disk"></i> Save Subject
      </button>
    </div>
  </div>
</div>

<!-- ── EDIT MODAL ────────────────────────────────────────── -->
<div class="modal-overlay hidden" id="modalEdit">
  <div class="modal" style="max-width:640px">
    <div class="modal-header">
      <h3><i class="fa-solid fa-pen" style="color:var(--info)"></i>&nbsp; Edit Subject</h3>
      <button class="modal-close" onclick="closeModal('modalEdit')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <form method="POST" class="dark-form" id="formEdit">
        <input type="hidden" name="post_action" value="edit">
        <input type="hidden" name="subject_id" id="editSubjectId">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Code <span style="color:var(--danger)">*</span></label>
            <input type="text" name="code" id="editCode" class="form-control" style="text-transform:uppercase" required>
          </div>
          <div class="form-group">
            <label class="form-label">Subject Name <span style="color:var(--danger)">*</span></label>
            <input type="text" name="name" id="editName" class="form-control" required>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Day</label>
            <select name="day_of_week" id="editDay" class="form-control">
              <?php foreach (Subject::$DAYS as $d): ?><option value="<?=$d?>"><?=$d?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Start</label>
            <input type="time" name="time_start" id="editTimeStart" class="form-control">
          </div>
          <div class="form-group">
            <label class="form-label">End</label>
            <input type="time" name="time_end" id="editTimeEnd" class="form-control">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Room</label>
            <input type="text" name="room" id="editRoom" class="form-control">
          </div>
          <div class="form-group">
            <label class="form-label">Instructor</label>
            <input type="text" name="instructor" id="editInstructor" class="form-control">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Status</label>
          <select name="is_active" id="editActive" class="form-control">
            <option value="1">Active</option><option value="0">Inactive</option>
          </select>
        </div>

        <hr style="border-color:var(--ad-border);margin:1rem 0">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label"><i class="fa-solid fa-clock" style="color:var(--warning)"></i> Late Threshold (min)</label>
            <input type="number" name="late_minutes" id="editLateMinutes" class="form-control" min="1" max="120" required>
          </div>
          <div class="form-group">
            <label class="form-label"><i class="fa-solid fa-circle-xmark" style="color:var(--danger)"></i> Absent Threshold (min)</label>
            <input type="number" name="absent_minutes" id="editAbsentMinutes" class="form-control" min="1" max="240" required>
          </div>
        </div>
        <div style="background:var(--ad-bg);border-radius:var(--radius-sm);padding:.7rem 1rem;font-size:.78rem;color:var(--ad-muted)" id="editRulePreview"></div>

        <hr style="border-color:var(--ad-border);margin:1rem 0">
        <p style="font-size:.82rem;color:var(--ad-muted);margin-bottom:.8rem">
          <i class="fa-solid fa-key"></i> <strong style="color:var(--ad-text)">Self-Enrollment</strong>
        </p>
        <div class="form-row">
          <div class="form-group" style="flex:2">
            <label class="form-label">Enrollment Code</label>
            <div style="position:relative">
              <input type="text" name="enrollment_password" id="editEnrollPw" class="form-control"
                     placeholder="Leave blank to keep existing code" autocomplete="off">
              <button type="button" onclick="togglePw('editEnrollPw','editEnrollEye')"
                style="position:absolute;right:.7rem;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:var(--ad-muted)">
                <i id="editEnrollEye" class="fa-solid fa-eye"></i>
              </button>
            </div>
            <small style="color:var(--ad-muted)" id="editPwHint"></small>
          </div>
          <div class="form-group" style="flex:1;display:flex;align-items:center;gap:.6rem;padding-top:1.5rem">
            <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;font-size:.9rem">
              <input type="checkbox" name="enrollment_open" id="editEnrollOpen"
                     style="width:16px;height:16px;accent-color:var(--primary)">
              <span style="color:var(--ad-text);font-weight:600">Enrollment Open</span>
            </label>
          </div>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal('modalEdit')">Cancel</button>
      <button class="btn btn-info" onclick="document.getElementById('formEdit').submit()">
        <i class="fa-solid fa-floppy-disk"></i> Update Subject
      </button>
    </div>
  </div>
</div>

<!-- ── SEND INVITES MODAL ──────────────────────────────── -->
<div class="modal-overlay hidden" id="modalInvite">
  <div class="modal" style="max-width:560px">
    <div class="modal-header">
      <h3><i class="fa-solid fa-envelope" style="color:var(--warning)"></i>&nbsp; Send Course Invitations</h3>
      <button class="modal-close" onclick="closeModal('modalInvite')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <p id="inviteSubjectLabel" style="color:var(--ad-muted);margin-bottom:1rem;font-size:.9rem"></p>

      <form method="POST" class="dark-form" id="formInvite">
        <input type="hidden" name="post_action" value="send_invites">
        <input type="hidden" name="subject_id"  id="inviteSubjectId">

        <div class="form-group">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:.6rem">
            <label class="form-label" style="margin:0">Select Section Groups to Invite</label>
            <div style="display:flex;gap:.4rem">
              <button type="button" class="btn btn-secondary btn-sm" onclick="inviteAll(true)">All</button>
              <button type="button" class="btn btn-secondary btn-sm" onclick="inviteAll(false)">None</button>
            </div>
          </div>

          <?php if (empty($allSections)): ?>
            <div style="color:var(--ad-muted);font-size:.85rem;padding:1rem;text-align:center;background:var(--ad-bg);border-radius:var(--radius-sm)">
              No sections found. Students must have their Course, Year Level, and Section filled in.
            </div>
          <?php else: ?>
            <div style="background:var(--ad-bg);border:1.5px solid var(--ad-border);border-radius:var(--radius-sm);max-height:300px;overflow-y:auto;padding:.4rem">
              <?php foreach ($allSections as $sec): ?>
              <label style="display:flex;align-items:center;gap:.75rem;padding:.6rem .75rem;border-radius:6px;cursor:pointer"
                     onmouseover="this.style.background='var(--ad-surface2)'"
                     onmouseout="this.style.background=''">
                <input type="checkbox" name="section_keys[]"
                       value="<?= htmlspecialchars($sec['key']) ?>"
                       class="invite-checkbox"
                       style="width:16px;height:16px;accent-color:var(--primary)">
                <div style="flex:1">
                  <div style="font-weight:600;font-size:.875rem;color:var(--ad-text)"><?= htmlspecialchars($sec['label']) ?></div>
                  <div style="font-size:.75rem;color:var(--ad-muted)"><?= $sec['count'] ?> student<?= $sec['count']!==1?'s':'' ?></div>
                </div>
              </label>
              <?php endforeach; ?>
            </div>
            <div id="inviteCount" style="font-size:.8rem;color:var(--ad-muted);margin-top:.5rem;text-align:right">
              0 section groups selected
            </div>
          <?php endif; ?>
        </div>

        <div style="background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.3);border-radius:var(--radius-sm);padding:.8rem 1rem;font-size:.82rem;color:var(--ad-text)">
          <i class="fa-solid fa-circle-info" style="color:var(--warning)"></i>
          Students will see a notification in their <strong>Subjects</strong> tab. They'll need to enter the enrollment code to confirm joining. Make sure this subject has an enrollment code set before sending.
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal('modalInvite')">Cancel</button>
      <button class="btn btn-warning" onclick="document.getElementById('formInvite').submit()">
        <i class="fa-solid fa-paper-plane"></i> Send Invitations
      </button>
    </div>
  </div>
</div>

<script>
function openModal(id)  { document.getElementById(id).classList.remove('hidden'); }
function closeModal(id) { document.getElementById(id).classList.add('hidden'); }
document.querySelectorAll('.modal-overlay').forEach(ov =>
  ov.addEventListener('click', e => { if (e.target===ov) ov.classList.add('hidden'); })
);

function togglePw(inputId, eyeId) {
  const inp = document.getElementById(inputId);
  const eye = document.getElementById(eyeId);
  if (inp.type === 'password' || inp.type === 'text') {
    const hide = inp.type === 'text';
    inp.type = hide ? 'password' : 'text';
    eye.className = hide ? 'fa-solid fa-eye' : 'fa-solid fa-eye-slash';
  }
}

function openEdit(s) {
  document.getElementById('editSubjectId').value     = s.id;
  document.getElementById('editCode').value          = s.code;
  document.getElementById('editName').value          = s.name;
  document.getElementById('editDay').value           = s.day_of_week;
  document.getElementById('editTimeStart').value     = s.time_start.substring(0,5);
  document.getElementById('editTimeEnd').value       = s.time_end.substring(0,5);
  document.getElementById('editRoom').value          = s.room        || '';
  document.getElementById('editInstructor').value    = s.instructor  || '';
  document.getElementById('editActive').value        = s.is_active;
  document.getElementById('editLateMinutes').value   = s.late_minutes   ?? 15;
  document.getElementById('editAbsentMinutes').value = s.absent_minutes ?? 45;
  document.getElementById('editEnrollOpen').checked  = !!parseInt(s.enrollment_open);
  document.getElementById('editEnrollPw').value      = '';
  document.getElementById('editPwHint').textContent  = s.enrollment_password
    ? 'A code is already set. Enter a new one to replace it, or leave blank to keep the current code.'
    : 'No code set yet. Add one to allow self-enrollment.';
  updatePreview();
  openModal('modalEdit');
}

function updatePreview() {
  const late   = parseInt(document.getElementById('editLateMinutes').value)   || 15;
  const absent = parseInt(document.getElementById('editAbsentMinutes').value) || 45;
  document.getElementById('editRulePreview').innerHTML =
    `<i class="fa-solid fa-circle-info"></i> `+
    `0–${late}m = <span style="color:var(--success)">Present</span> &nbsp;·&nbsp; `+
    `${late+1}–${absent}m = <span style="color:var(--warning)">Late</span> &nbsp;·&nbsp; `+
    `>${absent}m = <span style="color:var(--danger)">Absent</span>`;
}
document.getElementById('editLateMinutes')  ?.addEventListener('input', updatePreview);
document.getElementById('editAbsentMinutes')?.addEventListener('input', updatePreview);

// Invite modal
function openInviteModal(id, label) {
  document.getElementById('inviteSubjectId').value    = id;
  document.getElementById('inviteSubjectLabel').textContent = 'Subject: ' + label;
  document.querySelectorAll('.invite-checkbox').forEach(c => c.checked = false);
  updateInviteCount();
  openModal('modalInvite');
}
function inviteAll(s) {
  document.querySelectorAll('.invite-checkbox').forEach(c => c.checked = s);
  updateInviteCount();
}
function updateInviteCount() {
  const n = document.querySelectorAll('.invite-checkbox:checked').length;
  const el = document.getElementById('inviteCount');
  if (el) el.textContent = n + ' section group' + (n!==1?'s':'') + ' selected';
}
document.querySelectorAll('.invite-checkbox').forEach(c =>
  c.addEventListener('change', updateInviteCount)
);
</script>

<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
