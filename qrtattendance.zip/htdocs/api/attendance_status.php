<?php
// ============================================================
//  api/attendance_status.php
//  Polled by student/qrcode.php every 2 seconds.
//
//  Tracks which attendance events have already been delivered
//  as popups using the PHP session. This survives page refreshes.
//
//  Response fields:
//    recorded  bool   — a record exists for today
//    new_scan  bool   — this event has NOT been shown yet (show overlay)
//    action    string — 'time_in' or 'time_out'
//    status    string — 'present' | 'late' | 'absent'
//    time_in   string — formatted time or null
//    time_out  string — formatted time or null
// ============================================================
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('X-Content-Type-Options: nosniff');

if (session_status() === PHP_SESSION_NONE) session_start();

if (empty($_SESSION['logged_in']) || $_SESSION['role'] !== 'student') {
    http_response_code(403);
    echo json_encode(['success' => false]);
    exit;
}

try {
    $student = (new Student())->findByUserId((int)$_SESSION['user_id']);

    if (!$student) {
        echo json_encode(['success' => false]);
        exit;
    }

    $record = Database::getInstance()->query(
        "SELECT id, time_in, time_out, status
         FROM attendance
         WHERE student_id = ? AND date = CURDATE()
         ORDER BY id DESC
         LIMIT 1",
        [$student['id']]
    )->fetch();

    // No record today — clear session tracking so future scans work fresh
    if (!$record) {
        unset($_SESSION['popup_timein_id'], $_SESSION['popup_timeout_id']);
        echo json_encode(['success' => true, 'recorded' => false, 'new_scan' => false]);
        exit;
    }

    $recId    = (int)$record['id'];
    $hasIn    = !empty($record['time_in']);
    $hasOut   = !empty($record['time_out']);
    $new_scan = false;
    $action   = null;

    if ($hasOut) {
        // Time-out event: show overlay only if this record's timeout hasn't been delivered yet
        if (($_SESSION['popup_timeout_id'] ?? null) !== $recId) {
            $_SESSION['popup_timeout_id'] = $recId;
            $new_scan = true;
            $action   = 'time_out';
        }
        // Also make sure time_in is marked as delivered
        if (($_SESSION['popup_timein_id'] ?? null) !== $recId) {
            $_SESSION['popup_timein_id'] = $recId;
        }
    } elseif ($hasIn) {
        // Time-in event: show overlay only if not yet delivered
        if (($_SESSION['popup_timein_id'] ?? null) !== $recId) {
            $_SESSION['popup_timein_id'] = $recId;
            $new_scan = true;
            $action   = 'time_in';
        }
    }

    echo json_encode([
        'success'  => true,
        'recorded' => true,
        'new_scan' => $new_scan,
        'action'   => $action ?? ($hasOut ? 'time_out' : 'time_in'),
        'status'   => $record['status'],
        'time_in'  => $hasIn  ? date('h:i A', strtotime($record['time_in']))  : null,
        'time_out' => $hasOut ? date('h:i A', strtotime($record['time_out'])) : null,
    ]);

} catch (Throwable $e) {
    echo json_encode(['success' => false, 'recorded' => false, 'new_scan' => false]);
}
exit;
