<?php
// ============================================================
//  includes/header_admin.php — Admin Layout Header
//  Usage: include at top of every admin page
//  Requires: $pageTitle, $activeNav to be set before including
// ============================================================
$pageTitle  = $pageTitle  ?? 'Dashboard';
$activeNav  = $activeNav  ?? '';
$pageSubtitle = $pageSubtitle ?? date('l, F j Y');

// ── Silent daily auto-backup (runs once per day) ──────────────
if (class_exists('Backup')) {
    $lastAuto = Database::getInstance()->query(
        "SELECT id FROM backups WHERE type='auto' AND DATE(created_at)=CURDATE() LIMIT 1"
    )->fetch();
    if (!$lastAuto) {
        try { Backup::triggerAutoBackup(); } catch(Throwable $e) { /* silent */ }
    }
}

// ── Silent auto-timeout (runs on every admin page load) ────────
// Marks attendance records as invalid (is_valid=0) when a student
// has a pending time_out and their class has already ended.
if (class_exists('Attendance')) {
    try { (new Attendance())->autoTimeout(); } catch(Throwable $e) { /* silent */ }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($pageTitle) ?> — QR Attendance Admin</title>
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="admin-body">

<!-- Sidebar -->
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo">
    <div class="logo-icon"><i class="fa-solid fa-qrcode"></i></div>
    <div>
      <div class="logo-text">QR Attendance</div>
      <div class="logo-sub">Admin Panel</div>
    </div>
  </div>

  <nav class="sidebar-nav">
    <div class="sidebar-section">Main</div>

    <a href="<?= BASE_URL ?>/admin/dashboard.php"
       class="nav-item <?= $activeNav === 'dashboard' ? 'active' : '' ?>">
      <i class="fa-solid fa-gauge nav-icon"></i> Dashboard
    </a>

    <a href="<?= BASE_URL ?>/admin/scan.php"
       class="nav-item <?= $activeNav === 'scan' ? 'active' : '' ?>">
      <i class="fa-solid fa-camera nav-icon"></i> Scan QR Code
      <span class="nav-badge">LIVE</span>
    </a>

    <div class="sidebar-section">Management</div>

    <a href="<?= BASE_URL ?>/admin/students.php"
       class="nav-item <?= $activeNav === 'students' ? 'active' : '' ?>">
      <i class="fa-solid fa-users nav-icon"></i> Students
    </a>

    <a href="<?= BASE_URL ?>/admin/subjects.php"
       class="nav-item <?= $activeNav === 'subjects' ? 'active' : '' ?>">
      <i class="fa-solid fa-book nav-icon"></i> Subjects &amp; Schedule
    </a>

    <a href="<?= BASE_URL ?>/admin/attendance.php"
       class="nav-item <?= $activeNav === 'attendance' ? 'active' : '' ?>">
      <i class="fa-solid fa-calendar-check nav-icon"></i> Attendance Records
    </a>

    <div class="sidebar-section">Reports &amp; System</div>

    <a href="<?= BASE_URL ?>/admin/backup.php"
       class="nav-item <?= $activeNav === 'backup' ? 'active' : '' ?>">
      <i class="fa-solid fa-database nav-icon"></i> Backup &amp; Export
    </a>

    <a href="<?= BASE_URL ?>/admin/settings.php"
       class="nav-item <?= $activeNav === 'settings' ? 'active' : '' ?>">
      <i class="fa-solid fa-gear nav-icon"></i> Settings
    </a>
  </nav>

  <div class="sidebar-footer">
    <div class="sidebar-user">
      <div class="sidebar-avatar"><?= strtoupper(substr($_SESSION['username'] ?? 'A', 0, 1)) ?></div>
      <div class="sidebar-user-info">
        <div class="user-name"><?= htmlspecialchars($_SESSION['username'] ?? '') ?></div>
        <div class="user-role">Administrator</div>
      </div>
    </div>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-item mt-1" style="color:#ef4444">
      <i class="fa-solid fa-right-from-bracket nav-icon"></i> Logout
    </a>
  </div>
</aside>

<!-- Main content -->
<div class="admin-content">
  <header class="admin-topbar">
    <div style="display:flex;align-items:center;gap:1rem">
      <button class="btn btn-secondary btn-sm" id="sidebarToggle" style="display:none">
        <i class="fa-solid fa-bars"></i>
      </button>
      <div class="topbar-title">
        <h2><?= htmlspecialchars($pageTitle) ?></h2>
        <p><?= htmlspecialchars($pageSubtitle) ?></p>
      </div>
    </div>
    <div class="topbar-right">
      <div class="topbar-time" id="liveClock"></div>
      <a href="<?= BASE_URL ?>/logout.php" class="btn btn-danger btn-sm">
        <i class="fa-solid fa-right-from-bracket"></i> Logout
      </a>
    </div>
  </header>

  <main class="admin-main">
