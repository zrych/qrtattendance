-- QR Attendance System Backup
-- Generated: 2026-05-16 15:51:36
-- Type: auto

SET FOREIGN_KEY_CHECKS=0;

-- Table: users
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','student') NOT NULL DEFAULT 'student',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `users` (`id`,`username`,`password`,`role`,`is_active`,`created_at`,`updated_at`) VALUES
('1','admin','$2y$10$NNuxuhbUCVqVe05G.kRx4.1PKJm6eLQa6wbyHIruWDTOV8ovwqFhq','admin','1','2026-05-11 03:47:02','2026-05-11 03:57:51'),
('3','Jho','$2y$10$DvMwp7c8CPiyZRZua.PKneHUfa/Ps1hgSYJR21RE2zn9gbZ/aMDnO','student','1','2026-05-14 18:25:43','2026-05-14 18:25:43'),
('4','manueltan','$2y$10$Q2YKb/C6t4zk2MJMzV1eWeaalKMH72gEeX6Pchd25qRK.wudf0eMu','student','1','2026-05-15 18:00:50','2026-05-15 18:00:50');

-- Table: students
DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `student_number` varchar(20) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `course` varchar(100) DEFAULT NULL,
  `year_level` tinyint(4) DEFAULT NULL,
  `section` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `qr_token` varchar(64) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `student_number` (`student_number`),
  UNIQUE KEY `qr_token` (`qr_token`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `students_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `students` (`id`,`user_id`,`student_number`,`first_name`,`last_name`,`course`,`year_level`,`section`,`email`,`qr_token`,`created_at`,`updated_at`) VALUES
('2','3','0324-0467','Maria Jhoerica','Reyes','BSIT','1','A','0324-0467@lspu.edu.ph','bce2d5e06d9a8e8575b4e687dbf378d7a4217e6aeaaa2ee15c533a78ed62b5be','2026-05-14 18:25:43','2026-05-14 18:25:43'),
('3','4','0324-0576','Manuel Edgardo','Tan','BSIT','2','A','manueltan@gmail.com','87738bcccb4443aa4bfcdac636146c9a24cc2224e996546a5951e9985a56dd0d','2026-05-15 18:00:50','2026-05-15 18:00:50');

-- Table: attendance
DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `time_in` time DEFAULT NULL,
  `time_out` time DEFAULT NULL,
  `status` enum('present','late','absent') DEFAULT 'present',
  `is_valid` tinyint(1) NOT NULL DEFAULT 1,
  `notes` varchar(255) DEFAULT NULL,
  `scanned_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_attendance` (`student_id`,`date`),
  KEY `scanned_by` (`scanned_by`),
  CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`scanned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `attendance` (`id`,`student_id`,`subject_id`,`date`,`time_in`,`time_out`,`status`,`is_valid`,`notes`,`scanned_by`,`created_at`) VALUES
('7','2','1','2026-05-15','07:08:00','10:00:00','present','1','','1','2026-05-14 18:31:27'),
('9','3','9','2026-05-16','09:26:15','10:00:00','present','1','Auto timed-out — class ended at 10:00 AM','1','2026-05-15 18:26:15');

-- Table: subjects
DROP TABLE IF EXISTS `subjects`;
CREATE TABLE `subjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `day_of_week` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
  `time_start` time NOT NULL,
  `time_end` time NOT NULL,
  `room` varchar(50) DEFAULT '',
  `instructor` varchar(100) DEFAULT '',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `late_minutes` int(11) NOT NULL DEFAULT 15 COMMENT 'Minutes after start time before a student is marked Late',
  `absent_minutes` int(11) NOT NULL DEFAULT 45 COMMENT 'Minutes after start time before a student is marked Absent',
  `enrollment_password` varchar(255) DEFAULT NULL COMMENT 'bcrypt hash of the invite/enrollment code set by admin',
  `enrollment_open` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 = students can self-enroll with password, 0 = closed',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `subjects` (`id`,`code`,`name`,`day_of_week`,`time_start`,`time_end`,`room`,`instructor`,`is_active`,`created_at`,`updated_at`,`late_minutes`,`absent_minutes`,`enrollment_password`,`enrollment_open`) VALUES
('9','ITEP207','Database Management Systems','Saturday','09:25:00','10:00:00','Lab 1','','1','2026-05-15 18:25:08','2026-05-15 18:25:08','15','45','$2y$10$vedCbYyPPj1PEjSAlVjRHeY6S8CKHeoQzlJAQmLyhGONwGwXApK1S','1');

-- Table: subject_students
DROP TABLE IF EXISTS `subject_students`;
CREATE TABLE `subject_students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_enroll` (`subject_id`,`student_id`),
  KEY `student_id` (`student_id`),
  CONSTRAINT `subject_students_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subject_students_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `subject_students` (`id`,`subject_id`,`student_id`) VALUES
('10','9','3');

-- Table: settings
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(50) NOT NULL,
  `setting_value` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `settings` (`id`,`setting_key`,`setting_value`,`updated_at`) VALUES
('1','school_name','Laguna State Polytechnic University - San Pablo City Campus','2026-05-12 18:15:47'),
('2','late_threshold','08:30:00','2026-05-11 03:47:02'),
('3','attendance_start','07:00:00','2026-05-11 03:47:02'),
('4','attendance_end','20:00','2026-05-11 04:25:08');

-- Table: backups
DROP TABLE IF EXISTS `backups`;
CREATE TABLE `backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `size_bytes` bigint(20) DEFAULT 0,
  `type` enum('auto','manual') DEFAULT 'manual',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `backups` (`id`,`filename`,`size_bytes`,`type`,`created_at`) VALUES
('1','backup_auto_2026-05-11_185854.sql','5584','auto','2026-05-11 03:58:55'),
('2','backup_manual_2026-05-11_211246.sql','6489','manual','2026-05-11 06:12:47'),
('3','backup_auto_2026-05-12_175007.sql','6570','auto','2026-05-12 02:50:07'),
('4','backup_auto_2026-05-13_155631.sql','7240','auto','2026-05-13 00:56:30'),
('5','backup_manual_2026-05-14_083908.sql','7637','manual','2026-05-13 17:39:09'),
('6','backup_auto_2026-05-15_072058.sql','8280','auto','2026-05-14 16:20:59'),
('7','backup_auto_2026-05-15_173844.sql','9103','auto','2026-05-15 02:38:44');

SET FOREIGN_KEY_CHECKS=1;
