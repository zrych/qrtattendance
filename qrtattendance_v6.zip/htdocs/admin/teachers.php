<?php
require_once __DIR__ . '/../includes/auth.php';
User::requireLogin('admin');

$teacherClass = new Teacher();

// ── POST handlers ─────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['post_action'] ?? '';

    if ($act === 'approve') {
        $teacherClass->approve((int)$_POST['user_id']);
        setFlash('success', 'Teacher account approved.');
        redirect('admin/teachers.php');
    }
    if ($act === 'reject') {
        $teacherClass->reject((int)$_POST['user_id']);
        setFlash('success', 'Teacher account rejected.');
        redirect('admin/teachers.php');
    }
    if ($act === 'delete') {
        $teacherClass->delete((int)$_POST['user_id']);
        setFlash('success', 'Teacher account deleted.');
        redirect('admin/teachers.php');
    }
    if ($act === 'approve_request') {
        Teacher::approveRequest((int)$_POST['request_id']);
        setFlash('success', 'Subject assigned to teacher.');
        redirect('admin/teachers.php?tab=requests');
    }
    if ($act === 'reject_request') {
        Teacher::rejectRequest((int)$_POST['request_id'], $_POST['admin_note'] ?? '');
        setFlash('success', 'Request rejected.');
        redirect('admin/teachers.php?tab=requests');
    }
}

// ── Data ──────────────────────────────────────────────────────
$activeTab     = clean($_GET['tab'] ?? 'pending');
$pendingTeachers= $teacherClass->getAll('pending');
$activeTeachers = $teacherClass->getAll('active');
$pendingRequests= Teacher::getPendingRequests();

$pageTitle = 'Teacher Management';
$activeNav = 'teachers';
require_once __DIR__ . '/../includes/header_admin.php';
$flash = getFlash();
?>

<?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] ?>"><i class="fa-solid fa-circle-info"></i> <?= htmlspecialchars($flash['msg']) ?></div>
<?php endif; ?>

<div class="page-header">
  <div><h1>Teacher Management</h1><p>Approve registrations and manage subject assignments</p></div>
</div>

<!-- Tabs -->
<div class="page-tabs" style="margin-bottom:1.2rem">
  <button class="page-tab <?= $activeTab==='pending'?'active':'' ?>" onclick="switchTab('pending')">
    <i class="fa-solid fa-clock"></i> Pending Approval
    <?php if (!empty($pendingTeachers)): ?><span class="badge badge-warning" style="margin-left:.3rem"><?= count($pendingTeachers) ?></span><?php endif; ?>
  </button>
  <button class="page-tab <?= $activeTab==='active'?'active':'' ?>" onclick="switchTab('active')">
    <i class="fa-solid fa-user-check"></i> Active Teachers
    <span class="badge badge-success" style="margin-left:.3rem"><?= count($activeTeachers) ?></span>
  </button>
  <button class="page-tab <?= $activeTab==='requests'?'active':'' ?>" onclick="switchTab('requests')">
    <i class="fa-solid fa-book-open"></i> Subject Requests
    <?php if (!empty($pendingRequests)): ?><span class="badge badge-warning" style="margin-left:.3rem"><?= count($pendingRequests) ?></span><?php endif; ?>
  </button>
</div>

<!-- Pending Approvals -->
<div id="tab-pending" style="display:<?= $activeTab==='pending'?'block':'none' ?>">
  <?php if (empty($pendingTeachers)): ?>
    <div class="card card-dark"><div class="empty-state"><div class="empty-icon">✅</div>
      <h3 style="color:var(--ad-muted)">No pending registrations</h3>
    </div></div>
  <?php else: ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1rem">
      <?php foreach ($pendingTeachers as $t): ?>
      <div class="card card-dark" style="border:1.5px solid rgba(245,158,11,.3)">
        <div class="card-body" style="padding:1.2rem">
          <div style="display:flex;align-items:center;gap:.8rem;margin-bottom:.9rem">
            <div style="width:44px;height:44px;background:rgba(245,158,11,.15);border-radius:12px;
                        display:flex;align-items:center;justify-content:center;font-size:1.2rem;font-weight:800;color:#f59e0b">
              <?= strtoupper(substr($t['first_name'],0,1)) ?>
            </div>
            <div>
              <div style="font-weight:800;color:var(--ad-text)"><?= htmlspecialchars($t['first_name'].' '.$t['last_name']) ?></div>
              <div style="font-size:.78rem;color:var(--ad-muted)">@<?= htmlspecialchars($t['username']) ?></div>
            </div>
            <span class="badge badge-warning" style="margin-left:auto">Pending</span>
          </div>
          <div style="font-size:.8rem;color:var(--ad-muted);margin-bottom:.8rem;display:flex;flex-direction:column;gap:.25rem">
            <?php if ($t['employee_id']): ?><div><i class="fa-solid fa-id-card"></i> <?= htmlspecialchars($t['employee_id']) ?></div><?php endif; ?>
            <?php if ($t['department']): ?><div><i class="fa-solid fa-building"></i> <?= htmlspecialchars($t['department']) ?></div><?php endif; ?>
            <?php if ($t['email']): ?>     <div><i class="fa-solid fa-envelope"></i> <?= htmlspecialchars($t['email']) ?></div><?php endif; ?>
          </div>
          <div style="display:flex;gap:.5rem">
            <form method="POST" style="flex:1">
              <input type="hidden" name="post_action" value="approve">
              <input type="hidden" name="user_id"     value="<?= $t['user_id'] ?>">
              <button class="btn btn-success" style="width:100%;justify-content:center">
                <i class="fa-solid fa-check"></i> Approve
              </button>
            </form>
            <form method="POST" style="flex:1">
              <input type="hidden" name="post_action" value="reject">
              <input type="hidden" name="user_id"     value="<?= $t['user_id'] ?>">
              <button class="btn btn-danger" style="width:100%;justify-content:center"
                data-confirm="Reject this teacher registration?">
                <i class="fa-solid fa-xmark"></i> Reject
              </button>
            </form>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<!-- Active Teachers -->
<div id="tab-active" style="display:<?= $activeTab==='active'?'block':'none' ?>">
  <?php if (empty($activeTeachers)): ?>
    <div class="card card-dark"><div class="empty-state"><div class="empty-icon">👨‍🏫</div>
      <h3 style="color:var(--ad-muted)">No active teachers yet</h3>
    </div></div>
  <?php else: ?>
    <div class="card card-dark"><div class="card-body" style="padding:0">
      <div class="table-wrapper">
        <table class="table table-dark">
          <thead><tr><th>Teacher</th><th>Username</th><th>Employee ID</th><th>Department</th><th>Email</th><th>Subjects</th><th></th></tr></thead>
          <tbody>
            <?php foreach ($activeTeachers as $t): ?>
            <?php
              // Count subjects assigned
              $tSubjects = (new Subject())->getAll();
              $assigned  = count(array_filter($tSubjects, fn($s) => (int)($s['teacher_user_id'] ?? 0) === (int)$t['user_id']));
            ?>
            <tr>
              <td>
                <div style="display:flex;align-items:center;gap:.7rem">
                  <div style="width:34px;height:34px;background:rgba(99,102,241,.15);border-radius:8px;
                              display:flex;align-items:center;justify-content:center;font-weight:800;color:var(--primary-light)">
                    <?= strtoupper(substr($t['first_name'],0,1)) ?>
                  </div>
                  <div>
                    <div style="font-weight:600"><?= htmlspecialchars($t['first_name'].' '.$t['last_name']) ?></div>
                  </div>
                </div>
              </td>
              <td style="color:var(--ad-muted);font-size:.85rem">@<?= htmlspecialchars($t['username']) ?></td>
              <td style="color:var(--ad-muted);font-size:.85rem"><?= htmlspecialchars($t['employee_id'] ?: '—') ?></td>
              <td style="color:var(--ad-muted);font-size:.85rem"><?= htmlspecialchars($t['department'] ?: '—') ?></td>
              <td style="color:var(--ad-muted);font-size:.82rem"><?= htmlspecialchars($t['email'] ?: '—') ?></td>
              <td><span class="badge badge-info"><?= $assigned ?> subject<?= $assigned!==1?'s':'' ?></span></td>
              <td>
                <form method="POST" style="display:inline">
                  <input type="hidden" name="post_action" value="delete">
                  <input type="hidden" name="user_id"     value="<?= $t['user_id'] ?>">
                  <button type="submit" class="btn btn-danger btn-sm"
                    data-confirm="Delete teacher <?= htmlspecialchars($t['first_name'].' '.$t['last_name']) ?>? Their subject assignments will be removed.">
                    <i class="fa-solid fa-trash"></i>
                  </button>
                </form>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div></div>
  <?php endif; ?>
</div>

<!-- Subject Requests -->
<div id="tab-requests" style="display:<?= $activeTab==='requests'?'block':'none' ?>">
  <?php if (empty($pendingRequests)): ?>
    <div class="card card-dark"><div class="empty-state"><div class="empty-icon">📋</div>
      <h3 style="color:var(--ad-muted)">No pending subject requests</h3>
    </div></div>
  <?php else: ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:1rem">
      <?php foreach ($pendingRequests as $req): ?>
      <div class="card card-dark" style="border:1.5px solid rgba(99,102,241,.25)">
        <div class="card-body" style="padding:1.2rem">
          <div style="margin-bottom:.8rem">
            <div style="font-weight:800;color:var(--primary-light);font-family:monospace"><?= htmlspecialchars($req['code']) ?></div>
            <div style="color:var(--ad-text);font-size:.88rem"><?= htmlspecialchars($req['name']) ?></div>
            <div style="font-size:.77rem;color:var(--ad-muted);margin-top:.25rem">
              <?= $req['day_of_week'] ?> · <?= date('h:i A',strtotime($req['time_start'])) ?>–<?= date('h:i A',strtotime($req['time_end'])) ?>
            </div>
          </div>
          <div style="background:var(--ad-bg);border-radius:var(--radius-sm);padding:.6rem .8rem;margin-bottom:.8rem">
            <div style="font-size:.82rem;font-weight:600;color:var(--ad-text)">
              <i class="fa-solid fa-chalkboard-user" style="color:var(--primary)"></i>
              <?= htmlspecialchars($req['first_name'].' '.$req['last_name']) ?>
            </div>
            <div style="font-size:.75rem;color:var(--ad-muted)">
              @<?= htmlspecialchars($req['username']) ?>
              <?php if ($req['employee_id']): ?> · <?= htmlspecialchars($req['employee_id']) ?><?php endif; ?>
            </div>
          </div>
          <?php if ($req['message']): ?>
          <div style="font-size:.8rem;color:var(--ad-muted);font-style:italic;margin-bottom:.8rem;
                      background:rgba(99,102,241,.06);padding:.5rem .7rem;border-radius:6px;border-left:3px solid var(--primary)">
            "<?= htmlspecialchars($req['message']) ?>"
          </div>
          <?php endif; ?>
          <div style="font-size:.72rem;color:var(--ad-muted);margin-bottom:.8rem">
            Requested <?= date('M j, Y \a\t h:i A', strtotime($req['created_at'])) ?>
          </div>
          <div style="display:flex;gap:.5rem">
            <form method="POST" style="flex:1">
              <input type="hidden" name="post_action" value="approve_request">
              <input type="hidden" name="request_id"  value="<?= $req['id'] ?>">
              <button class="btn btn-success" style="width:100%;justify-content:center">
                <i class="fa-solid fa-check"></i> Approve
              </button>
            </form>
            <button class="btn btn-danger" style="flex:1;justify-content:center"
              onclick="openRejectModal(<?= $req['id'] ?>)">
              <i class="fa-solid fa-xmark"></i> Reject
            </button>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<!-- Reject request modal -->
<div id="rejectModal" style="display:none;position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.5);backdrop-filter:blur(4px);align-items:center;justify-content:center">
  <div style="background:var(--ad-surface);border-radius:18px;padding:2rem;max-width:380px;width:90%;box-shadow:0 20px 60px rgba(0,0,0,.4)">
    <h3 style="color:var(--ad-text);margin-bottom:.8rem"><i class="fa-solid fa-xmark" style="color:var(--danger)"></i>&nbsp; Reject Request</h3>
    <form method="POST" class="dark-form">
      <input type="hidden" name="post_action" value="reject_request">
      <input type="hidden" name="request_id"  id="rejectRequestId">
      <div class="form-group">
        <label class="form-label">Reason (shown to teacher)</label>
        <textarea name="admin_note" class="form-control" rows="3" placeholder="e.g. Subject already assigned to another teacher."></textarea>
      </div>
      <div style="display:flex;gap:.7rem;margin-top:.5rem">
        <button type="button" class="btn btn-secondary" style="flex:1;justify-content:center" onclick="closeRejectModal()">Cancel</button>
        <button type="submit" class="btn btn-danger" style="flex:1;justify-content:center"><i class="fa-solid fa-xmark"></i> Reject</button>
      </div>
    </form>
  </div>
</div>

<script>
function switchTab(tab) {
  ['pending','active','requests'].forEach(t => {
    document.getElementById('tab-'+t).style.display = t===tab?'block':'none';
  });
}
const rejectModal = document.getElementById('rejectModal');
function openRejectModal(id) {
  document.getElementById('rejectRequestId').value = id;
  rejectModal.style.display = 'flex';
}
function closeRejectModal() { rejectModal.style.display = 'none'; }
rejectModal.addEventListener('click', e => { if (e.target===rejectModal) closeRejectModal(); });
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
