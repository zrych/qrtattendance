<?php
// ============================================================
//  classes/Teacher.php — Teacher Role Management
// ============================================================

class Teacher {
    private Database $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    // ── Registration & Profile ────────────────────────────────

    /**
     * Create a teacher account (user + profile).
     * User status is set to 'pending' — admin must approve.
     * Returns ['success'=>bool, 'message'=>string]
     */
    public function create(array $data): array {
        $userClass = new User();

        if ($userClass->usernameExists(trim($data['username']))) {
            return ['success' => false, 'message' => 'Username is already taken.'];
        }

        // Check employee_id uniqueness if provided
        if (!empty($data['employee_id'])) {
            $exists = $this->db->query(
                'SELECT id FROM teachers WHERE employee_id = ?',
                [trim($data['employee_id'])]
            )->fetch();
            if ($exists) {
                return ['success' => false, 'message' => 'Employee ID is already registered.'];
            }
        }

        try {
            // Create user with pending status
            $hash = password_hash($data['password'], PASSWORD_BCRYPT);
            $this->db->query(
                "INSERT INTO users (username, password, role, status) VALUES (?, ?, 'teacher', 'pending')",
                [trim($data['username']), $hash]
            );
            $userId = (int)$this->db->lastInsertId();

            // Create teacher profile
            $this->db->query(
                'INSERT INTO teachers (user_id, first_name, last_name, email, department, employee_id)
                 VALUES (?,?,?,?,?,?)',
                [
                    $userId,
                    trim($data['first_name']),
                    trim($data['last_name']),
                    trim($data['email']       ?? ''),
                    trim($data['department']  ?? ''),
                    trim($data['employee_id'] ?? ''),
                ]
            );

            return ['success' => true, 'message' => 'Registration submitted. Please wait for admin approval.'];
        } catch (Throwable $e) {
            return ['success' => false, 'message' => 'Registration failed. Please try again.'];
        }
    }

    /** Find teacher profile by user_id. */
    public function findByUserId(int $userId): array|false {
        return $this->db->query(
            'SELECT t.*, u.username, u.status, u.is_active
             FROM teachers t
             JOIN users u ON u.id = t.user_id
             WHERE t.user_id = ?',
            [$userId]
        )->fetch();
    }

    /** Get all teachers, optionally filtered by status. */
    public function getAll(string $status = ''): array {
        $sql    = 'SELECT t.*, u.username, u.status, u.is_active, u.id AS user_id
                   FROM teachers t JOIN users u ON u.id = t.user_id';
        $params = [];
        if ($status !== '') {
            $sql   .= ' WHERE u.status = ?';
            $params[] = $status;
        }
        $sql .= ' ORDER BY t.last_name, t.first_name';
        return $this->db->query($sql, $params)->fetchAll();
    }

    /** Count pending teacher registrations (for admin badge). */
    public static function countPending(): int {
        $db  = Database::getInstance();
        $row = $db->query(
            "SELECT COUNT(*) AS n FROM users WHERE role='teacher' AND status='pending'"
        )->fetch();
        return (int)($row['n'] ?? 0);
    }

    // ── Admin Actions ─────────────────────────────────────────

    /** Approve a teacher account. */
    public function approve(int $userId): void {
        $this->db->query(
            "UPDATE users SET status='active', is_active=1 WHERE id=?",
            [$userId]
        );
    }

    /** Reject a teacher account. */
    public function reject(int $userId): void {
        $this->db->query(
            "UPDATE users SET status='rejected', is_active=0 WHERE id=?",
            [$userId]
        );
    }

    /** Delete a teacher (user + profile + requests). */
    public function delete(int $userId): void {
        $this->db->query('DELETE FROM users WHERE id=?', [$userId]);
    }

    // ── Subject Requests ──────────────────────────────────────

    /**
     * Teacher submits a request to claim a subject.
     * Returns ['success'=>bool, 'message'=>string]
     */
    public function requestSubject(int $teacherUserId, int $subjectId, string $message = ''): array {
        // Check not already assigned to this subject
        $subject = $this->db->query(
            'SELECT teacher_user_id FROM subjects WHERE id=?', [$subjectId]
        )->fetch();
        if ($subject && (int)$subject['teacher_user_id'] === $teacherUserId) {
            return ['success' => false, 'message' => 'You are already assigned to this subject.'];
        }

        try {
            $this->db->query(
                "INSERT INTO subject_requests (teacher_user_id, subject_id, message)
                 VALUES (?,?,?)
                 ON DUPLICATE KEY UPDATE
                   status='pending', message=VALUES(message), reviewed_at=NULL",
                [$teacherUserId, $subjectId, trim($message)]
            );
            return ['success' => true, 'message' => 'Request submitted. Waiting for admin approval.'];
        } catch (Throwable $e) {
            return ['success' => false, 'message' => 'Could not submit request. Please try again.'];
        }
    }

    /** Get all subject requests by a teacher. */
    public function getMyRequests(int $teacherUserId): array {
        return $this->db->query(
            'SELECT sr.*, s.code, s.name, s.day_of_week, s.time_start, s.time_end, s.room
             FROM subject_requests sr
             JOIN subjects s ON s.id = sr.subject_id
             WHERE sr.teacher_user_id = ?
             ORDER BY sr.created_at DESC',
            [$teacherUserId]
        )->fetchAll();
    }

    /** Get subjects currently assigned to (approved) a teacher. */
    public function getMySubjects(int $teacherUserId): array {
        return $this->db->query(
            'SELECT s.*,
                    (SELECT COUNT(*) FROM subject_students ss WHERE ss.subject_id=s.id) AS enrolled_count
             FROM subjects s
             WHERE s.teacher_user_id = ? AND s.is_active = 1
             ORDER BY FIELD(s.day_of_week,"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"),
                      s.time_start',
            [$teacherUserId]
        )->fetchAll();
    }

    /**
     * Subjects available to request (active, not yet claimed by this teacher,
     * not already having a pending request from this teacher).
     */
    public function getAvailableToRequest(int $teacherUserId): array {
        return $this->db->query(
            'SELECT s.*,
                    t2.first_name AS current_teacher_first,
                    t2.last_name  AS current_teacher_last,
                    (SELECT status FROM subject_requests sr
                     WHERE sr.subject_id=s.id AND sr.teacher_user_id=? LIMIT 1) AS my_request_status
             FROM subjects s
             LEFT JOIN teachers t2 ON t2.user_id = s.teacher_user_id
             WHERE s.is_active = 1
               AND s.teacher_user_id != ? OR s.teacher_user_id IS NULL
             ORDER BY s.day_of_week, s.time_start',
            [$teacherUserId, $teacherUserId]
        )->fetchAll();
    }

    /** All pending subject requests (for admin). */
    public static function getPendingRequests(): array {
        $db = Database::getInstance();
        return $db->query(
            'SELECT sr.*, s.code, s.name, s.day_of_week, s.time_start, s.time_end,
                    t.first_name, t.last_name, t.employee_id, u.username
             FROM subject_requests sr
             JOIN subjects  s ON s.id  = sr.subject_id
             JOIN teachers  t ON t.user_id = sr.teacher_user_id
             JOIN users     u ON u.id  = sr.teacher_user_id
             WHERE sr.status = ?
             ORDER BY sr.created_at ASC',
            ['pending']
        )->fetchAll();
    }

    /** Admin approves a subject request — assigns teacher to subject. */
    public static function approveRequest(int $requestId): void {
        $db  = Database::getInstance();
        $req = $db->query('SELECT * FROM subject_requests WHERE id=?', [$requestId])->fetch();
        if (!$req) return;

        $db->query(
            "UPDATE subject_requests SET status='approved', reviewed_at=NOW() WHERE id=?",
            [$requestId]
        );
        // Assign teacher to subject
        $db->query(
            'UPDATE subjects SET teacher_user_id=? WHERE id=?',
            [$req['teacher_user_id'], $req['subject_id']]
        );
        // Auto-reject other pending requests for same subject
        $db->query(
            "UPDATE subject_requests SET status='rejected', reviewed_at=NOW(),
                    admin_note='Another teacher was assigned to this subject.'
             WHERE subject_id=? AND id!=? AND status='pending'",
            [$req['subject_id'], $requestId]
        );
    }

    /** Admin rejects a subject request. */
    public static function rejectRequest(int $requestId, string $note = ''): void {
        $db = Database::getInstance();
        $db->query(
            "UPDATE subject_requests SET status='rejected', admin_note=?, reviewed_at=NOW() WHERE id=?",
            [trim($note), $requestId]
        );
    }

    /** Count pending subject requests (for admin badge). */
    public static function countPendingRequests(): int {
        $db  = Database::getInstance();
        $row = $db->query(
            "SELECT COUNT(*) AS n FROM subject_requests WHERE status='pending'"
        )->fetch();
        return (int)($row['n'] ?? 0);
    }

    // ── Teacher Dashboard Data ────────────────────────────────

    /**
     * Today's attendance counts across all of this teacher's subjects.
     */
    public function getTodayStats(int $teacherUserId): array {
        $row = $this->db->query(
            "SELECT
               SUM(a.status='present') AS present,
               SUM(a.status='late')    AS late,
               SUM(a.status='absent')  AS absent,
               COUNT(a.id)             AS total
             FROM attendance a
             JOIN subjects s ON s.id = a.subject_id
             WHERE s.teacher_user_id = ? AND a.date = CURDATE()",
            [$teacherUserId]
        )->fetch();
        return [
            'present' => (int)($row['present'] ?? 0),
            'late'    => (int)($row['late']    ?? 0),
            'absent'  => (int)($row['absent']  ?? 0),
            'total'   => (int)($row['total']   ?? 0),
        ];
    }

    /**
     * Summary per student across all of this teacher's subjects.
     * Returns rate, present/late/absent counts, last seen, subject code.
     */
    public function getStudentSummary(int $teacherUserId): array {
        return $this->db->query(
            "SELECT st.id, st.student_number, st.first_name, st.last_name,
                    st.course, st.year_level, st.section,
                    s.id AS subject_id, s.code AS subject_code, s.name AS subject_name,
                    COUNT(a.id)             AS total_records,
                    SUM(a.status='present') AS present_count,
                    SUM(a.status='late')    AS late_count,
                    SUM(a.status='absent')  AS absent_count,
                    MAX(a.date)             AS last_seen,
                    ROUND(
                      SUM(a.status IN ('present','late')) / NULLIF(COUNT(a.id),0) * 100, 1
                    ) AS rate
             FROM subjects s
             JOIN subject_students ss ON ss.subject_id = s.id
             JOIN students st ON st.id = ss.student_id
             LEFT JOIN attendance a ON a.student_id = st.id
                                   AND a.subject_id = s.id
             WHERE s.teacher_user_id = ?
             GROUP BY st.id, s.id
             ORDER BY st.last_name, st.first_name, s.code",
            [$teacherUserId]
        )->fetchAll();
    }

    /**
     * Full attendance records for teacher's subjects with optional filters.
     */
    public function getAttendanceRecords(int $teacherUserId, array $filters = []): array {
        $sql    = "SELECT a.*, st.first_name, st.last_name, st.student_number,
                          s.code AS subject_code, s.name AS subject_name
                   FROM attendance a
                   JOIN students st ON st.id = a.student_id
                   JOIN subjects  s  ON s.id  = a.subject_id
                   WHERE s.teacher_user_id = ?";
        $params = [$teacherUserId];

        if (!empty($filters['date'])) {
            $sql .= ' AND a.date = ?'; $params[] = $filters['date'];
        }
        if (!empty($filters['subject_id'])) {
            $sql .= ' AND a.subject_id = ?'; $params[] = $filters['subject_id'];
        }
        if (!empty($filters['status'])) {
            $sql .= ' AND a.status = ?'; $params[] = $filters['status'];
        }
        if (!empty($filters['search'])) {
            $like = '%' . $filters['search'] . '%';
            $sql .= ' AND (st.first_name LIKE ? OR st.last_name LIKE ? OR st.student_number LIKE ?)';
            $params = array_merge($params, [$like, $like, $like]);
        }
        $sql .= ' ORDER BY a.date DESC, a.time_in DESC';
        if (!empty($filters['limit'])) {
            $sql .= ' LIMIT ' . (int)$filters['limit'];
        }
        return $this->db->query($sql, $params)->fetchAll();
    }
}
