<?php
// ============================================================
//  includes/header_teacher.php — Teacher Layout Header
// ============================================================
$pageTitle  = $pageTitle  ?? 'Teacher Dashboard';
$activeNav  = $activeNav  ?? '';

// Auto-timeout on every teacher page load
if (class_exists('Attendance')) {
    try { (new Attendance())->autoTimeout(); } catch(Throwable $e) {}
}

// Pending subject request count for badge
$_pendingReqCount = 0;
try {
    $teacherClass    = new Teacher();
    $_teacherProfile = $teacherClass->findByUserId((int)$_SESSION['user_id']);
    $_myRequests     = $teacherClass->getMyRequests((int)$_SESSION['user_id']);
    $_pendingReqCount= count(array_filter($_myRequests, fn($r) => $r['status'] === 'pending'));
} catch(Throwable $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($pageTitle) ?> — QR Attendance</title>
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="icon"             type="image/x-icon" href="<?= BASE_URL ?>/assets/favicon.ico">
  <link rel="icon"             type="image/png" sizes="32x32" href="<?= BASE_URL ?>/assets/favicon-32.png">
  <link rel="apple-touch-icon" sizes="180x180"    href="<?= BASE_URL ?>/assets/favicon-180.png">
</head>
<body class="admin-body">

<!-- Sidebar -->
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo">
    <div class="logo-icon"><i class="fa-solid fa-chalkboard-user"></i></div>
    <div>
      <div class="logo-text">QR Attendance</div>
      <div class="logo-sub">Teacher Panel</div>
    </div>
  </div>

  <nav class="sidebar-nav">
    <div class="sidebar-section">Main</div>

    <a href="<?= BASE_URL ?>/teacher/dashboard.php"
       class="nav-item <?= $activeNav === 'dashboard' ? 'active' : '' ?>">
      <i class="fa-solid fa-gauge nav-icon"></i> Dashboard
    </a>

    <a href="<?= BASE_URL ?>/teacher/scan.php"
       class="nav-item <?= $activeNav === 'scan' ? 'active' : '' ?>">
      <i class="fa-solid fa-camera nav-icon"></i> Scan QR Code
      <span class="nav-badge">LIVE</span>
    </a>

    <div class="sidebar-section">My Classes</div>

    <a href="<?= BASE_URL ?>/teacher/subjects.php"
       class="nav-item <?= $activeNav === 'subjects' ? 'active' : '' ?>">
      <i class="fa-solid fa-book nav-icon"></i> My Subjects
      <?php if ($_pendingReqCount > 0): ?>
        <span class="nav-badge"><?= $_pendingReqCount ?></span>
      <?php endif; ?>
    </a>

    <a href="<?= BASE_URL ?>/teacher/students.php"
       class="nav-item <?= $activeNav === 'students' ? 'active' : '' ?>">
      <i class="fa-solid fa-users nav-icon"></i> My Students
    </a>

    <a href="<?= BASE_URL ?>/teacher/attendance.php"
       class="nav-item <?= $activeNav === 'attendance' ? 'active' : '' ?>">
      <i class="fa-solid fa-calendar-check nav-icon"></i> Attendance Records
    </a>
  </nav>

  <div class="sidebar-footer">
    <div class="sidebar-user">
      <div class="sidebar-avatar" style="background:linear-gradient(135deg,#0ea5e9,#6366f1)">
        <?= strtoupper(substr($_teacherProfile['first_name'] ?? $_SESSION['username'] ?? 'T', 0, 1)) ?>
      </div>
      <div class="sidebar-user-info">
        <div class="user-name">
          <?= htmlspecialchars(($_teacherProfile['first_name'] ?? '') . ' ' . ($_teacherProfile['last_name'] ?? '')) ?>
        </div>
        <div class="user-role">Teacher</div>
      </div>
    </div>
    <a href="<?= BASE_URL ?>/logout.php" class="btn btn-secondary btn-sm sidebar-logout">
      <i class="fa-solid fa-right-from-bracket"></i> Logout
    </a>
  </div>
</aside>

<!-- Main content -->
<div class="main-content">
  <div class="topbar">
    <button class="sidebar-toggle" id="sidebarToggle" onclick="toggleSidebar()">
      <i class="fa-solid fa-bars"></i>
    </button>
    <div class="topbar-title"><?= htmlspecialchars($pageTitle) ?></div>
    <div class="topbar-right">
      <div id="liveClock" style="color:var(--ad-muted);font-size:.85rem;font-variant-numeric:tabular-nums"></div>
    </div>
  </div>
  <div class="content-area">
