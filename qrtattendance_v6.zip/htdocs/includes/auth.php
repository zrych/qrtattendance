<?php
// ============================================================
//  includes/auth.php — Bootstrap & Session Guard
//  Include at the TOP of every protected page
// ============================================================

if (session_status() === PHP_SESSION_NONE) session_start();

// Load config & classes
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../classes/Database.php';
require_once __DIR__ . '/../classes/User.php';
require_once __DIR__ . '/../classes/Student.php';
require_once __DIR__ . '/../classes/Attendance.php';
require_once __DIR__ . '/../classes/Subject.php';
require_once __DIR__ . '/../classes/Backup.php';
require_once __DIR__ . '/../classes/Notification.php';
require_once __DIR__ . '/../classes/Teacher.php';

/**
 * Flash message helpers
 */
function setFlash(string $type, string $msg): void {
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
}

function getFlash(): ?array {
    if (isset($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

/**
 * Sanitise user input
 */
function clean(string $value): string {
    return htmlspecialchars(strip_tags(trim($value)));
}

/**
 * Redirect helper
 */
function redirect(string $path): void {
    header('Location: ' . BASE_URL . '/' . ltrim($path, '/'));
    exit;
}
