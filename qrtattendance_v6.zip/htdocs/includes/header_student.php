<?php
// ============================================================
//  includes/header_student.php — Student Layout Header
// ============================================================
$pageTitle = $pageTitle ?? 'Dashboard';
$activeNav = $activeNav ?? '';

// Auto-timeout: mark pending attendance records as invalid when class has ended
if (class_exists('Attendance')) {
    try { (new Attendance())->autoTimeout(); } catch(Throwable $e) { /* silent */ }
}

// Unread notification count for badge
$_unreadCount = 0;
if (!empty($_SESSION['logged_in']) && $_SESSION['role'] === 'student') {
    try {
        $_st = (new Student())->findByUserId((int)$_SESSION['user_id']);
        if ($_st) {
            $_unreadCount = (new Notification())->getUnreadCount((int)$_st['id']);
        }
    } catch (Throwable $e) { $_unreadCount = 0; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($pageTitle) ?> — QR Attendance</title>
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="icon"             type="image/x-icon" href="<?= BASE_URL ?>/assets/favicon.ico">
  <link rel="icon"             type="image/png" sizes="32x32" href="<?= BASE_URL ?>/assets/favicon-32.png">
  <link rel="apple-touch-icon" sizes="180x180"    href="<?= BASE_URL ?>/assets/favicon-180.png">
</head>
<body class="student-body">

<header class="student-topbar">
  <div class="brand">
    <div class="brand-icon"><i class="fa-solid fa-qrcode"></i></div>
    <span class="brand-name">QR Attendance</span>
  </div>

  <nav class="student-nav">
    <a href="<?= BASE_URL ?>/student/dashboard.php"
       class="student-nav-link <?= $activeNav==='dashboard'?'active':'' ?>">
      <i class="fa-solid fa-gauge"></i> Dashboard
    </a>
    <a href="<?= BASE_URL ?>/student/qrcode.php"
       class="student-nav-link <?= $activeNav==='qrcode'?'active':'' ?>">
      <i class="fa-solid fa-qrcode"></i> My QR Code
    </a>
    <a href="<?= BASE_URL ?>/student/my_attendance.php"
       class="student-nav-link <?= $activeNav==='attendance'?'active':'' ?>">
      <i class="fa-solid fa-calendar-check"></i> Attendance
    </a>
    <a href="<?= BASE_URL ?>/student/notifications.php"
       class="student-nav-link <?= $activeNav==='notifications'?'active':'' ?>"
       style="position:relative">
      <i class="fa-solid fa-bell"></i> Subjects
      <?php if ($_unreadCount > 0): ?>
        <span style="
          position:absolute;top:-4px;right:-8px;
          background:#ef4444;color:#fff;
          font-size:.6rem;font-weight:800;
          min-width:17px;height:17px;
          border-radius:999px;
          display:inline-flex;align-items:center;justify-content:center;
          padding:0 3px;line-height:1;
          box-shadow:0 0 0 2px var(--st-bg)">
          <?= $_unreadCount > 9 ? '9+' : $_unreadCount ?>
        </span>
      <?php endif; ?>
    </a>
    <a href="<?= BASE_URL ?>/logout.php"
       class="student-nav-link" style="color:#ef4444">
      <i class="fa-solid fa-right-from-bracket"></i> Logout
    </a>
  </nav>
</header>

<main class="student-main">