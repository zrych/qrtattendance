<?php
require_once __DIR__ . '/../includes/auth.php';
User::requireLogin('teacher');

$teacherClass  = new Teacher();
$teacherUserId = (int)$_SESSION['user_id'];
$mySubjects    = $teacherClass->getMySubjects($teacherUserId);

// ── Handle edit ───────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['post_action'] ?? '';

    if ($act === 'edit') {
        $attId   = (int)$_POST['att_id'];
        $attClass= new Attendance();
        $rec     = $attClass->findById($attId);

        // Verify this record belongs to one of the teacher's subjects
        $mySubjectIds = array_column($mySubjects, 'id');
        if ($rec && in_array((int)$rec['subject_id'], $mySubjectIds)) {
            $attClass->update($attId, [
                'time_in'  => $_POST['time_in']  ?: null,
                'time_out' => $_POST['time_out'] ?: null,
                'status'   => $_POST['status'],
                'notes'    => $_POST['notes'] ?? '',
            ]);
            setFlash('success', 'Attendance record updated.');
        } else {
            setFlash('danger', 'Access denied — this record is not in your subject.');
        }
        redirect('teacher/attendance.php');
    }
}

// ── Filters ───────────────────────────────────────────────────
$filterDate    = clean($_GET['date']       ?? '');
$filterStatus  = clean($_GET['status']    ?? '');
$filterSubject = clean($_GET['subject_id'] ?? '');
$filterSearch  = clean($_GET['q']         ?? '');

$records = $teacherClass->getAttendanceRecords($teacherUserId, [
    'date'       => $filterDate,
    'status'     => $filterStatus,
    'subject_id' => $filterSubject,
    'search'     => $filterSearch,
]);

$autoCount = count(array_filter($records, fn($r) => str_contains($r['notes'] ?? '', 'Auto timed-out')));

$pageTitle = 'Attendance Records';
$activeNav = 'attendance';
require_once __DIR__ . '/../includes/header_teacher.php';
$flash = getFlash();
?>

<?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] ?>"><i class="fa-solid fa-circle-info"></i> <?= htmlspecialchars($flash['msg']) ?></div>
<?php endif; ?>

<?php if ($autoCount > 0): ?>
<div style="background:rgba(245,158,11,.08);border:1.5px solid rgba(245,158,11,.3);border-radius:var(--radius);padding:.85rem 1.2rem;margin-bottom:1rem;display:flex;align-items:center;gap:.8rem;flex-wrap:wrap">
  <i class="fa-solid fa-robot" style="color:#f59e0b;font-size:1.1rem"></i>
  <div style="font-size:.85rem;color:var(--ad-text)">
    <strong style="color:#f59e0b"><?= $autoCount ?> record<?= $autoCount>1?'s':'' ?></strong> were auto timed-out — students did not scan out before class ended.
  </div>
</div>
<?php endif; ?>

<div class="page-header">
  <div>
    <h1>Attendance Records</h1>
    <p><?= count($records) ?> record<?= count($records)!==1?'s':'' ?> found</p>
  </div>
</div>

<!-- Filters -->
<form method="GET" style="margin-bottom:1.2rem">
  <div class="toolbar">
    <div class="search-box">
      <i class="fa-solid fa-search search-icon"></i>
      <input type="text" name="q" class="form-control" placeholder="Search student…" value="<?= htmlspecialchars($filterSearch) ?>">
    </div>
    <input type="date" name="date" class="form-control" style="width:auto" value="<?= htmlspecialchars($filterDate) ?>">
    <select name="subject_id" class="form-control" style="width:auto">
      <option value="">All Subjects</option>
      <?php foreach ($mySubjects as $s): ?>
        <option value="<?= $s['id'] ?>" <?= $filterSubject==$s['id']?'selected':'' ?>><?= htmlspecialchars($s['code']) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="status" class="form-control" style="width:auto">
      <option value="">All Status</option>
      <option value="present" <?= $filterStatus==='present'?'selected':'' ?>>Present</option>
      <option value="late"    <?= $filterStatus==='late'   ?'selected':'' ?>>Late</option>
      <option value="absent"  <?= $filterStatus==='absent' ?'selected':'' ?>>Absent</option>
    </select>
    <button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-filter"></i> Filter</button>
    <a href="<?= BASE_URL ?>/teacher/attendance.php" class="btn btn-secondary btn-sm">Reset</a>
  </div>
</form>

<!-- Records table -->
<div class="card card-dark">
  <div class="card-body" style="padding:0">
    <?php if (empty($records)): ?>
      <div class="empty-state"><div class="empty-icon">📅</div>
        <h3 style="color:var(--ad-muted)">No records found</h3>
        <p style="color:var(--ad-muted)">Scan student QR codes to start recording attendance.</p>
      </div>
    <?php else: ?>
      <div class="table-wrapper">
        <table class="table table-dark">
          <thead>
            <tr><th>#</th><th>Student</th><th>Subject</th><th>Date</th><th>Time In</th><th>Time Out</th><th>Status</th><th>Notes</th><th></th></tr>
          </thead>
          <tbody>
            <?php foreach ($records as $i => $r):
              $isAuto = str_contains($r['notes'] ?? '', 'Auto timed-out');
            ?>
            <tr>
              <td style="color:var(--ad-muted)"><?= $i+1 ?></td>
              <td>
                <div style="font-weight:600"><?= htmlspecialchars($r['last_name'].', '.$r['first_name']) ?></div>
                <div style="font-size:.75rem;color:var(--ad-muted)"><?= htmlspecialchars($r['student_number']) ?></div>
              </td>
              <td style="font-size:.82rem;color:var(--primary-light);font-family:monospace"><?= htmlspecialchars($r['subject_code'] ?? '—') ?></td>
              <td><?= date('M j, Y',strtotime($r['date'])) ?><div style="font-size:.72rem;color:var(--ad-muted)"><?= date('D',strtotime($r['date'])) ?></div></td>
              <td><?= $r['time_in']  ? date('h:i A',strtotime($r['time_in']))  : '—' ?></td>
              <td>
                <?php if ($r['time_out'] && $isAuto): ?>
                  <span style="color:#f59e0b"><?= date('h:i A',strtotime($r['time_out'])) ?></span>
                  <div style="font-size:.68rem;color:#f59e0b"><i class="fa-solid fa-robot"></i> auto</div>
                <?php elseif ($r['time_out']): ?>
                  <?= date('h:i A',strtotime($r['time_out'])) ?>
                <?php else: ?>
                  <span style="color:var(--ad-muted)">—</span>
                <?php endif; ?>
              </td>
              <td>
                <?php if ($r['status']==='present'): ?><span class="badge badge-success">Present</span>
                <?php elseif ($r['status']==='late'):   ?><span class="badge badge-warning">Late</span>
                <?php else: ?>                           <span class="badge badge-danger">Absent</span><?php endif; ?>
              </td>
              <td style="font-size:.78rem;color:var(--ad-muted);max-width:160px"><?= htmlspecialchars($r['notes'] ?? '') ?: '—' ?></td>
              <td>
                <button class="btn btn-info btn-sm" onclick='openEditModal(<?= htmlspecialchars(json_encode($r), ENT_QUOTES) ?>)'>
                  <i class="fa-solid fa-pen"></i>
                </button>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay hidden" id="modalEdit">
  <div class="modal">
    <div class="modal-header">
      <h3><i class="fa-solid fa-pen" style="color:var(--info)"></i>&nbsp; Edit Attendance</h3>
      <button class="modal-close" onclick="document.getElementById('modalEdit').classList.add('hidden')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <form method="POST" class="dark-form" id="formEdit">
        <input type="hidden" name="post_action" value="edit">
        <input type="hidden" name="att_id" id="editAttId">
        <div class="form-group">
          <label class="form-label">Student</label>
          <input type="text" id="editStudent" class="form-control" disabled>
        </div>
        <div class="form-group">
          <label class="form-label">Date</label>
          <input type="text" id="editDate" class="form-control" disabled>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Time In</label>
            <input type="time" name="time_in" id="editTimeIn" class="form-control">
          </div>
          <div class="form-group">
            <label class="form-label">Time Out</label>
            <input type="time" name="time_out" id="editTimeOut" class="form-control">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Status</label>
          <select name="status" id="editStatus" class="form-control">
            <option value="present">Present</option>
            <option value="late">Late</option>
            <option value="absent">Absent</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Notes</label>
          <input type="text" name="notes" id="editNotes" class="form-control">
          <small style="color:var(--ad-muted)">Clear the auto-timeout note here if you verified the student's departure.</small>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="document.getElementById('modalEdit').classList.add('hidden')">Cancel</button>
      <button class="btn btn-info" onclick="document.getElementById('formEdit').submit()"><i class="fa-solid fa-floppy-disk"></i> Update</button>
    </div>
  </div>
</div>

<script>
function openEditModal(r) {
  document.getElementById('editAttId').value    = r.id;
  document.getElementById('editStudent').value  = r.last_name+', '+r.first_name+' ('+r.student_number+')';
  document.getElementById('editDate').value     = r.date;
  document.getElementById('editTimeIn').value   = r.time_in  ? r.time_in.substring(0,5)  : '';
  document.getElementById('editTimeOut').value  = r.time_out ? r.time_out.substring(0,5) : '';
  document.getElementById('editStatus').value   = r.status;
  document.getElementById('editNotes').value    = r.notes || '';
  document.getElementById('modalEdit').classList.remove('hidden');
}
document.querySelectorAll('.modal-overlay').forEach(ov =>
  ov.addEventListener('click', e => { if (e.target===ov) ov.classList.add('hidden'); })
);
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
