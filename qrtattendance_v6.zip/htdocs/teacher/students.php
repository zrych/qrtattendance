<?php
require_once __DIR__ . '/../includes/auth.php';
User::requireLogin('teacher');

$teacherClass  = new Teacher();
$teacherUserId = (int)$_SESSION['user_id'];
$mySubjects    = $teacherClass->getMySubjects($teacherUserId);
$studentSummary= $teacherClass->getStudentSummary($teacherUserId);

// Filter by subject
$filterSubject = isset($_GET['subject_id']) ? (int)$_GET['subject_id'] : 0;
if ($filterSubject) {
    $studentSummary = array_filter($studentSummary, fn($s) => (int)$s['subject_id'] === $filterSubject);
    $studentSummary = array_values($studentSummary);
}

// Filter by search
$search = clean($_GET['q'] ?? '');
if ($search) {
    $sl = strtolower($search);
    $studentSummary = array_filter($studentSummary, fn($s) =>
        str_contains(strtolower($s['first_name'].' '.$s['last_name']), $sl) ||
        str_contains(strtolower($s['student_number'] ?? ''), $sl)
    );
    $studentSummary = array_values($studentSummary);
}

$pageTitle = 'My Students';
$activeNav = 'students';
require_once __DIR__ . '/../includes/header_teacher.php';
$flash = getFlash();
?>

<?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] ?>"><i class="fa-solid fa-circle-info"></i> <?= htmlspecialchars($flash['msg']) ?></div>
<?php endif; ?>

<div class="page-header">
  <div>
    <h1>My Students</h1>
    <p><?= count($studentSummary) ?> student–subject record<?= count($studentSummary)!==1?'s':'' ?> found</p>
  </div>
</div>

<!-- Filters -->
<form method="GET" style="margin-bottom:1.2rem">
  <div class="toolbar">
    <div class="search-box">
      <i class="fa-solid fa-search search-icon"></i>
      <input type="text" name="q" class="form-control" placeholder="Search student name or ID…" value="<?= htmlspecialchars($search) ?>">
    </div>
    <select name="subject_id" class="form-control" style="width:auto">
      <option value="">All My Subjects</option>
      <?php foreach ($mySubjects as $s): ?>
        <option value="<?= $s['id'] ?>" <?= $filterSubject===$s['id']?'selected':'' ?>><?= htmlspecialchars($s['code'].' — '.$s['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-filter"></i> Filter</button>
    <a href="<?= BASE_URL ?>/teacher/students.php" class="btn btn-secondary btn-sm">Reset</a>
  </div>
</form>

<!-- Summary cards per subject -->
<?php if (!$filterSubject && !$search): ?>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:.8rem;margin-bottom:1.4rem">
  <?php foreach ($mySubjects as $s): ?>
  <?php $count = count(array_filter($studentSummary, fn($st) => (int)$st['subject_id']===$s['id'])); ?>
  <a href="?subject_id=<?= $s['id'] ?>" style="text-decoration:none">
    <div class="card card-dark" style="padding:1rem;cursor:pointer;transition:border-color .2s" onmouseover="this.style.borderColor='var(--primary)'" onmouseout="this.style.borderColor='var(--ad-border)'">
      <div style="font-weight:800;color:var(--primary-light);font-family:monospace;font-size:.9rem"><?= htmlspecialchars($s['code']) ?></div>
      <div style="font-size:.78rem;color:var(--ad-muted);margin:.2rem 0"><?= htmlspecialchars($s['name']) ?></div>
      <div style="font-size:1.3rem;font-weight:800;color:var(--ad-text)"><?= $count ?> <span style="font-size:.75rem;font-weight:400;color:var(--ad-muted)">students</span></div>
    </div>
  </a>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Students table -->
<div class="card card-dark">
  <div class="card-body" style="padding:0">
    <?php if (empty($studentSummary)): ?>
      <div class="empty-state"><div class="empty-icon">👥</div>
        <h3 style="color:var(--ad-muted)">No students found</h3>
        <p style="color:var(--ad-muted)">Enroll students from the <a href="<?= BASE_URL ?>/teacher/subjects.php" style="color:var(--primary)">Subjects</a> page.</p>
      </div>
    <?php else: ?>
      <div class="table-wrapper">
        <table class="table table-dark">
          <thead>
            <tr>
              <th>#</th><th>Student</th><th>Subject</th>
              <th>Present</th><th>Late</th><th>Absent</th><th>Rate</th><th>Last Seen</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($studentSummary as $i => $s):
              $rate = (float)($s['rate'] ?? 0);
            ?>
            <tr>
              <td style="color:var(--ad-muted)"><?= $i+1 ?></td>
              <td>
                <div style="font-weight:600"><?= htmlspecialchars($s['last_name'].', '.$s['first_name']) ?></div>
                <div style="font-size:.75rem;color:var(--ad-muted)"><?= htmlspecialchars($s['student_number']) ?></div>
                <div style="font-size:.72rem;color:var(--ad-muted)"><?= htmlspecialchars($s['course']) ?> Y<?= $s['year_level'] ?><?= $s['section']?' S'.$s['section']:'' ?></div>
              </td>
              <td><span style="color:var(--primary-light);font-family:monospace;font-size:.85rem"><?= htmlspecialchars($s['subject_code']) ?></span><div style="font-size:.72rem;color:var(--ad-muted)"><?= htmlspecialchars($s['subject_name']) ?></div></td>
              <td><span class="badge badge-success"><?= (int)$s['present_count'] ?></span></td>
              <td><span class="badge badge-warning"><?= (int)$s['late_count'] ?></span></td>
              <td><span class="badge badge-danger"><?= (int)$s['absent_count'] ?></span></td>
              <td>
                <span style="font-weight:700;color:<?= $rate>=75?'var(--success)':($rate>=50?'var(--warning)':'var(--danger)') ?>"><?= $rate ?>%</span>
                <div style="width:60px;height:4px;background:var(--ad-border);border-radius:2px;margin-top:.25rem">
                  <div style="width:<?= min($rate,100) ?>%;height:100%;border-radius:2px;background:<?= $rate>=75?'var(--success)':($rate>=50?'var(--warning)':'var(--danger)') ?>"></div>
                </div>
              </td>
              <td style="color:var(--ad-muted);font-size:.82rem"><?= $s['last_seen'] ? date('M j, Y',strtotime($s['last_seen'])) : '—' ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
