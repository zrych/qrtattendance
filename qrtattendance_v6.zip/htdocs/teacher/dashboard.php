<?php
require_once __DIR__ . '/../includes/auth.php';
User::requireLogin('teacher');

$teacherClass = new Teacher();
$teacher      = $teacherClass->findByUserId((int)$_SESSION['user_id']);
if (!$teacher) { User::logout(); }

$mySubjects    = $teacherClass->getMySubjects((int)$_SESSION['user_id']);
$todayStats    = $teacherClass->getTodayStats((int)$_SESSION['user_id']);
$studentSummary= $teacherClass->getStudentSummary((int)$_SESSION['user_id']);
$recentRecords = $teacherClass->getAttendanceRecords((int)$_SESSION['user_id'], ['limit' => 8]);

// Build week schedule from my subjects
$subjectsByDay = [];
foreach ($mySubjects as $s) {
    $subjectsByDay[$s['day_of_week']][] = $s;
}

$days    = Subject::$DAYS;
$today   = date('l');
$nowTime = date('H:i:s');

$pageTitle = 'Teacher Dashboard';
require_once __DIR__ . '/../includes/header_teacher.php';
?>

<!-- Welcome banner -->
<div style="background:linear-gradient(135deg,#0ea5e9,#6366f1);border-radius:var(--radius);padding:1.8rem 2rem;margin-bottom:1.5rem;color:#fff;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem">
  <div>
    <div style="font-size:.82rem;opacity:.8;text-transform:uppercase;letter-spacing:.6px;margin-bottom:.3rem">Welcome back</div>
    <h2 style="font-size:1.5rem;font-weight:800;margin-bottom:.2rem">
      <?= htmlspecialchars($teacher['first_name'] . ' ' . $teacher['last_name']) ?>
    </h2>
    <div style="opacity:.85;font-size:.9rem">
      <?php if ($teacher['employee_id']): ?><?= htmlspecialchars($teacher['employee_id']) ?> &nbsp;·&nbsp; <?php endif; ?>
      <?php if ($teacher['department']): ?><?= htmlspecialchars($teacher['department']) ?><?php endif; ?>
    </div>
  </div>
  <a href="<?= BASE_URL ?>/teacher/scan.php" class="btn" style="background:rgba(255,255,255,.2);color:#fff;border:2px solid rgba(255,255,255,.4);font-weight:700">
    <i class="fa-solid fa-camera"></i> Start Scanning
  </a>
</div>

<!-- Stats -->
<div class="stat-cards" style="margin-bottom:1.5rem">
  <div class="stat-card stat-card-dark">
    <div class="stat-icon stat-icon-primary"><i class="fa-solid fa-book"></i></div>
    <div class="stat-info"><div class="stat-label">My Subjects</div><div class="stat-value"><?= count($mySubjects) ?></div></div>
  </div>
  <div class="stat-card stat-card-dark">
    <div class="stat-icon stat-icon-success"><i class="fa-solid fa-user-check"></i></div>
    <div class="stat-info"><div class="stat-label">Present Today</div><div class="stat-value"><?= $todayStats['present'] ?></div></div>
  </div>
  <div class="stat-card stat-card-dark">
    <div class="stat-icon stat-icon-warning"><i class="fa-solid fa-clock"></i></div>
    <div class="stat-info"><div class="stat-label">Late Today</div><div class="stat-value"><?= $todayStats['late'] ?></div></div>
  </div>
  <div class="stat-card stat-card-dark">
    <div class="stat-icon stat-icon-info"><i class="fa-solid fa-users"></i></div>
    <div class="stat-info">
      <div class="stat-label">Total Students</div>
      <div class="stat-value"><?= count(array_unique(array_column($studentSummary,'id'))) ?></div>
    </div>
  </div>
</div>

<!-- Week Schedule + Recent side by side -->
<div style="display:grid;grid-template-columns:2fr 1fr;gap:1.2rem;margin-bottom:1.4rem">

  <!-- Weekly Schedule -->
  <div class="card card-dark">
    <div class="card-header">
      <h3><i class="fa-solid fa-calendar-week" style="color:var(--primary)"></i>&nbsp; My Weekly Schedule</h3>
      <span style="font-size:.8rem;color:var(--ad-muted)"><?= date('l, F j') ?></span>
    </div>
    <div class="card-body" style="padding:.8rem">
      <?php if (empty($mySubjects)): ?>
        <div class="empty-state" style="padding:1rem">
          <div class="empty-icon">📚</div>
          <p style="color:var(--ad-muted)">No subjects assigned yet. <a href="<?= BASE_URL ?>/teacher/subjects.php" style="color:var(--primary)">Request a subject →</a></p>
        </div>
      <?php else: ?>
        <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:.35rem">
          <?php foreach ($days as $day):
            $ds      = $subjectsByDay[$day] ?? [];
            $isToday = $day === $today;
          ?>
          <div style="background:<?= $isToday?'rgba(99,102,241,.12)':'var(--ad-bg)'?>;
                      border:1px solid <?= $isToday?'var(--primary)':'var(--ad-border)'?>;
                      border-radius:var(--radius-sm);padding:.45rem .3rem;min-height:60px;text-align:center">
            <div style="font-size:.62rem;font-weight:700;text-transform:uppercase;color:<?= $isToday?'var(--primary-light)':'var(--ad-muted)'?>;margin-bottom:.3rem">
              <?= substr($day,0,3) ?>
            </div>
            <?php foreach ($ds as $d):
              $ongoing = Subject::isOngoing($d);
            ?>
              <div style="background:<?= $ongoing?'var(--success)':'var(--primary)'?>;color:#fff;border-radius:3px;padding:.15rem .25rem;font-size:.58rem;font-weight:600;margin-bottom:.15rem;line-height:1.3">
                <?= htmlspecialchars($d['code']) ?><br>
                <span style="opacity:.85;font-weight:400"><?= date('h:i',strtotime($d['time_start'])) ?></span>
              </div>
            <?php endforeach; ?>
          </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Today's ongoing -->
  <div class="card card-dark">
    <div class="card-header">
      <h3><i class="fa-solid fa-calendar-day" style="color:var(--success)"></i>&nbsp; Today's Classes</h3>
    </div>
    <div class="card-body" style="padding:.8rem">
      <?php $todayClasses = $subjectsByDay[$today] ?? []; ?>
      <?php if (empty($todayClasses)): ?>
        <div style="text-align:center;padding:1rem;color:var(--ad-muted);font-size:.85rem">No classes today</div>
      <?php else: ?>
        <?php foreach ($todayClasses as $tc):
          $ongoing = Subject::isOngoing($tc);
        ?>
        <div style="background:var(--ad-bg);border:1px solid <?= $ongoing?'var(--success)':'var(--ad-border)'?>;
                    border-radius:var(--radius-sm);padding:.7rem .85rem;margin-bottom:.5rem">
          <div style="display:flex;align-items:center;justify-content:space-between">
            <strong style="color:<?= $ongoing?'var(--success)':'var(--ad-text)' ?>;font-size:.88rem">
              <?= htmlspecialchars($tc['code']) ?>
              <?php if ($ongoing): ?><span style="display:inline-block;width:7px;height:7px;background:var(--success);border-radius:50%;margin-left:4px;animation:pulse 1.5s infinite"></span><?php endif; ?>
            </strong>
            <?php if ($ongoing): ?>
              <a href="<?= BASE_URL ?>/teacher/scan.php" class="btn btn-success btn-sm" style="font-size:.7rem;padding:.25rem .6rem">Scan</a>
            <?php endif; ?>
          </div>
          <div style="font-size:.75rem;color:var(--ad-muted);margin-top:.15rem">
            <?= date('h:i A',strtotime($tc['time_start'])) ?> – <?= date('h:i A',strtotime($tc['time_end'])) ?>
            <?php if ($tc['room']): ?> · <?= htmlspecialchars($tc['room']) ?><?php endif; ?>
          </div>
          <div style="font-size:.72rem;color:var(--ad-muted);margin-top:.1rem">
            <i class="fa-solid fa-users" style="font-size:.6rem"></i> <?= $tc['enrolled_count'] ?> students
          </div>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Student Summary Table -->
<div class="card card-dark" style="margin-bottom:1.4rem">
  <div class="card-header">
    <h3><i class="fa-solid fa-chart-bar" style="color:var(--primary)"></i>&nbsp; Student Attendance Summary</h3>
    <a href="<?= BASE_URL ?>/teacher/students.php" class="btn btn-secondary btn-sm">View All</a>
  </div>
  <div class="card-body" style="padding:0">
    <?php if (empty($studentSummary)): ?>
      <div class="empty-state"><div class="empty-icon">👥</div><p style="color:var(--ad-muted)">No students enrolled in your subjects yet.</p></div>
    <?php else: ?>
      <div class="table-wrapper">
        <table class="table table-dark">
          <thead><tr><th>Student</th><th>Subject</th><th>Present</th><th>Late</th><th>Absent</th><th>Rate</th><th>Last Seen</th></tr></thead>
          <tbody>
            <?php foreach (array_slice($studentSummary, 0, 10) as $s): ?>
            <tr>
              <td>
                <div style="font-weight:600"><?= htmlspecialchars($s['last_name'].', '.$s['first_name']) ?></div>
                <div style="font-size:.75rem;color:var(--ad-muted)"><?= htmlspecialchars($s['student_number']) ?></div>
              </td>
              <td><span style="color:var(--primary-light);font-family:monospace;font-size:.85rem"><?= htmlspecialchars($s['subject_code']) ?></span></td>
              <td><span class="badge badge-success"><?= $s['present_count'] ?></span></td>
              <td><span class="badge badge-warning"><?= $s['late_count'] ?></span></td>
              <td><span class="badge badge-danger"><?= $s['absent_count'] ?></span></td>
              <td>
                <?php $rate = (float)($s['rate'] ?? 0); ?>
                <span style="color:<?= $rate>=75?'var(--success)':($rate>=50?'var(--warning)':'var(--danger)') ?>;font-weight:700"><?= $rate ?>%</span>
              </td>
              <td style="color:var(--ad-muted);font-size:.82rem">
                <?= $s['last_seen'] ? date('M j', strtotime($s['last_seen'])) : '—' ?>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- Recent attendance -->
<div class="card card-dark">
  <div class="card-header">
    <h3><i class="fa-solid fa-clock-rotate-left" style="color:var(--primary)"></i>&nbsp; Recent Scans</h3>
    <a href="<?= BASE_URL ?>/teacher/attendance.php" class="btn btn-secondary btn-sm">View All</a>
  </div>
  <div class="card-body" style="padding:0">
    <?php if (empty($recentRecords)): ?>
      <div class="empty-state"><div class="empty-icon">📋</div><p style="color:var(--ad-muted)">No records yet.</p></div>
    <?php else: ?>
      <div class="table-wrapper">
        <table class="table table-dark">
          <thead><tr><th>Student</th><th>Subject</th><th>Date</th><th>Time In</th><th>Status</th></tr></thead>
          <tbody>
            <?php foreach ($recentRecords as $r): ?>
            <tr>
              <td><strong><?= htmlspecialchars($r['last_name'].', '.$r['first_name']) ?></strong></td>
              <td style="color:var(--primary-light);font-family:monospace;font-size:.82rem"><?= htmlspecialchars($r['subject_code'] ?? '—') ?></td>
              <td style="font-size:.82rem"><?= date('M j',strtotime($r['date'])) ?></td>
              <td style="font-size:.82rem"><?= $r['time_in'] ? date('h:i A',strtotime($r['time_in'])) : '—' ?></td>
              <td>
                <?php if ($r['status']==='present'): ?><span class="badge badge-success">Present</span>
                <?php elseif ($r['status']==='late'):   ?><span class="badge badge-warning">Late</span>
                <?php else: ?>                           <span class="badge badge-danger">Absent</span>
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
