<?php
require_once __DIR__ . '/../includes/auth.php';
User::requireLogin('teacher');

$teacherClass = new Teacher();
$mySubjects   = $teacherClass->getMySubjects((int)$_SESSION['user_id']);

$pageTitle = 'Scan QR Code';
$activeNav = 'scan';
require_once __DIR__ . '/../includes/header_teacher.php';
?>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:1.4rem;align-items:start">

  <!-- Scanner Panel -->
  <div class="card card-dark">
    <div class="card-header">
      <h3><i class="fa-solid fa-camera" style="color:var(--primary)"></i>&nbsp; QR Scanner</h3>
      <span class="badge badge-success animate-pulse" id="scannerStatus">Ready</span>
    </div>
    <div class="card-body" style="padding:0">
      <div id="qr-reader" style="width:100%"></div>

      <div class="scan-result" id="scanResultArea" style="display:none">
        <div class="scan-result-card" id="scanResultCard">
          <div class="scan-result-icon" id="scanResultIcon">✅</div>
          <div class="scan-result-info">
            <div class="result-name"   id="scanResultName">—</div>
            <div class="result-detail" id="scanResultDetail">—</div>
          </div>
          <span class="badge" id="scanResultBadge" style="margin-left:auto">—</span>
        </div>
      </div>

      <div style="padding:1rem 1.2rem;border-top:1px solid var(--ad-border);display:flex;align-items:center;justify-content:space-between">
        <div style="font-size:.82rem;color:var(--ad-muted)">
          <i class="fa-solid fa-circle-info"></i>
          First scan = Time In &nbsp;|&nbsp; Second scan = Time Out
        </div>
        <button class="btn btn-secondary btn-sm" id="btnClearResult">
          <i class="fa-solid fa-rotate-left"></i> Clear
        </button>
      </div>
    </div>
  </div>

  <!-- Right panel -->
  <div style="display:flex;flex-direction:column;gap:1rem">

    <!-- Today's subjects -->
    <div class="card card-dark">
      <div class="card-header">
        <h3><i class="fa-solid fa-calendar-day" style="color:var(--success)"></i>&nbsp; Today — <?= date('l') ?></h3>
      </div>
      <div class="card-body" style="padding:.8rem">
        <?php $todaySubjects = array_filter($mySubjects, fn($s) => $s['day_of_week'] === date('l')); ?>
        <?php if (empty($todaySubjects)): ?>
          <div style="color:var(--ad-muted);font-size:.85rem;text-align:center;padding:.5rem">No subjects scheduled today</div>
        <?php else: ?>
          <?php foreach ($todaySubjects as $s):
            $ongoing = Subject::isOngoing($s);
          ?>
          <div style="background:var(--ad-bg);border:1px solid <?= $ongoing?'var(--success)':'var(--ad-border)' ?>;border-radius:var(--radius-sm);padding:.6rem .8rem;margin-bottom:.4rem">
            <div style="display:flex;align-items:center;justify-content:space-between">
              <strong style="color:<?= $ongoing?'var(--success)':'var(--ad-text)' ?>;font-size:.88rem">
                <?= htmlspecialchars($s['code']) ?>
                <?php if ($ongoing): ?><span style="display:inline-block;width:6px;height:6px;background:var(--success);border-radius:50%;margin-left:4px;animation:pulse 1.5s infinite"></span><?php endif; ?>
              </strong>
              <?php if ($ongoing): ?><span class="badge badge-success" style="font-size:.65rem">ONGOING</span><?php endif; ?>
            </div>
            <div style="font-size:.75rem;color:var(--ad-muted)"><?= date('h:i A',strtotime($s['time_start'])) ?> – <?= date('h:i A',strtotime($s['time_end'])) ?>
              <?php if ($s['room']): ?> · <?= htmlspecialchars($s['room']) ?><?php endif; ?>
            </div>
          </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>

    <!-- Scan Log -->
    <div class="card card-dark">
      <div class="card-header">
        <h3><i class="fa-solid fa-list-check" style="color:var(--success)"></i>&nbsp; Scan Log</h3>
        <button class="btn btn-secondary btn-sm" id="btnClearLog"><i class="fa-solid fa-trash"></i></button>
      </div>
      <div class="card-body">
        <div class="scan-log" id="scanLog">
          <div style="text-align:center;padding:1.5rem;color:var(--ad-muted);font-size:.875rem">
            <i class="fa-regular fa-clock"></i> Scan log will appear here…
          </div>
        </div>
      </div>
    </div>

    <!-- Manual Entry -->
    <div class="card card-dark">
      <div class="card-header">
        <h3><i class="fa-solid fa-keyboard" style="color:var(--warning)"></i>&nbsp; Manual Entry</h3>
      </div>
      <div class="card-body dark-form">
        <p style="color:var(--ad-muted);font-size:.82rem;margin-bottom:.8rem">Enter a student number if the QR scanner isn't working.</p>
        <div style="display:flex;gap:.6rem">
          <input type="text" id="manualToken" class="form-control" placeholder="Student number or QR token…">
          <button class="btn btn-warning" onclick="processManual()"><i class="fa-solid fa-arrow-right"></i></button>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
<script>
const BASE_URL = '<?= BASE_URL ?>';
let lastScannedToken = '';
let lastScannedAt    = 0;
let lastScanSuccess  = false;
const DEBOUNCE_MS    = 3000;
const DEBOUNCE_OK    = 30000;

const scanner = new Html5QrcodeScanner('qr-reader', { fps:10, qrbox:{width:260,height:260} }, false);
scanner.render(onScanSuccess, () => {});

function onScanSuccess(decodedText) {
    const now = Date.now();
    const deb = (lastScanSuccess && decodedText === lastScannedToken) ? DEBOUNCE_OK : DEBOUNCE_MS;
    if (decodedText === lastScannedToken && (now - lastScannedAt) < deb) return;
    lastScannedToken  = decodedText;
    lastScannedAt     = now;
    lastScanSuccess   = false;
    sendScan(decodedText);
}

function sendScan(token) {
    document.getElementById('scannerStatus').textContent = 'Processing…';
    fetch('/api/scan.php', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({token})
    })
    .then(r => {
        const ct = r.headers.get('Content-Type') || '';
        if (!ct.includes('application/json')) { location.reload(); return null; }
        return r.json();
    })
    .then(data => {
        if (!data) return;
        showResult(data);
        if (data.success && data.action === 'time_in') {
            lastScanSuccess = true;
            lastScannedAt   = Date.now();
        }
        addLogEntry(data.success, data.student?.first_name + ' ' + (data.student?.last_name || ''), data.message);
    })
    .catch(() => showResult({success:false, message:'Network error. Please try again.'}))
    .finally(() => { document.getElementById('scannerStatus').textContent = 'Ready'; });
}

function showResult(data) {
    const area   = document.getElementById('scanResultArea');
    const card   = document.getElementById('scanResultCard');
    const icon   = document.getElementById('scanResultIcon');
    const name   = document.getElementById('scanResultName');
    const detail = document.getElementById('scanResultDetail');
    const badge  = document.getElementById('scanResultBadge');
    area.style.display = 'block';
    if (data.success) {
        const statusIcons = {present:'✅', late:'🕐', absent:'⚠️'};
        const action = data.action === 'time_out' ? '👋' : (statusIcons[data.status] || '✅');
        icon.textContent  = action;
        card.className    = 'scan-result-card success';
        name.textContent  = data.student ? data.student.first_name + ' ' + data.student.last_name : '—';
        detail.textContent= data.message;
        badge.textContent = data.action === 'time_out' ? 'Time Out' : ucfirst(data.status || '');
        badge.className   = 'badge badge-' + (data.status === 'present' ? 'success' : data.status === 'late' ? 'warning' : 'danger');
    } else {
        icon.textContent  = '❌';
        card.className    = 'scan-result-card error';
        name.textContent  = data.student ? data.student.first_name + ' ' + data.student.last_name : 'Unknown';
        detail.textContent= data.message || 'Scan failed.';
        badge.textContent = 'Error';
        badge.className   = 'badge badge-danger';
    }
}

function ucfirst(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : ''; }

function addLogEntry(success, name, msg) {
    const log  = document.getElementById('scanLog');
    if (log.children.length === 1 && log.children[0].style.textAlign === 'center') log.innerHTML = '';
    const entry = document.createElement('div');
    entry.className = 'scan-log-entry';
    entry.innerHTML = `<div class="scan-log-dot ${success?'success':'error'}"></div>
      <div><strong>${name}</strong><div style="font-size:.75rem;color:var(--ad-muted)">${msg}</div></div>
      <div style="font-size:.72rem;color:var(--ad-muted);margin-left:auto">${new Date().toLocaleTimeString()}</div>`;
    log.prepend(entry);
}

function processManual() {
    const val = document.getElementById('manualToken').value.trim();
    if (!val) return;
    lastScannedToken = val; lastScannedAt = Date.now(); lastScanSuccess = false;
    sendScan(val);
    document.getElementById('manualToken').value = '';
}

document.getElementById('manualToken').addEventListener('keydown', e => { if (e.key==='Enter') processManual(); });
document.getElementById('btnClearResult').addEventListener('click', () => { document.getElementById('scanResultArea').style.display='none'; });
document.getElementById('btnClearLog').addEventListener('click', () => { document.getElementById('scanLog').innerHTML = '<div style="text-align:center;padding:1.5rem;color:var(--ad-muted);font-size:.875rem"><i class="fa-regular fa-clock"></i> Scan log will appear here…</div>'; });
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
