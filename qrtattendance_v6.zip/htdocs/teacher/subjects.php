<?php
require_once __DIR__ . '/../includes/auth.php';
User::requireLogin('teacher');

$teacherClass  = new Teacher();
$subjectClass  = new Subject();
$notifClass    = new Notification();
$teacher       = $teacherClass->findByUserId((int)$_SESSION['user_id']);
$teacherUserId = (int)$_SESSION['user_id'];

// ── POST handlers ─────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['post_action'] ?? '';

    if ($act === 'request_subject') {
        $result = $teacherClass->requestSubject($teacherUserId, (int)$_POST['subject_id'], $_POST['message'] ?? '');
        setFlash($result['success'] ? 'success' : 'danger', $result['message']);
        redirect('teacher/subjects.php');
    }

    // Enrollment actions (same as admin but scoped to teacher's subjects)
    if ($act === 'enroll') {
        $sid = (int)$_POST['subject_id'];
        // Verify this subject belongs to this teacher
        $subj = $subjectClass->findById($sid);
        if ($subj && (int)$subj['teacher_user_id'] === $teacherUserId) {
            $ids = $_POST['student_ids'] ?? [];
            if (!empty($ids)) { $subjectClass->enrollBulk($sid, $ids); setFlash('success', count($ids).' student(s) enrolled.'); }
            else setFlash('warning', 'No students selected.');
        } else {
            setFlash('danger', 'Access denied.');
        }
        redirect('teacher/subjects.php?view='.$sid);
    }

    if ($act === 'unenroll') {
        $sid = (int)$_POST['subject_id'];
        $subj = $subjectClass->findById($sid);
        if ($subj && (int)$subj['teacher_user_id'] === $teacherUserId) {
            $subjectClass->unenroll($sid, (int)$_POST['student_id']);
            setFlash('success', 'Student unenrolled.');
        } else { setFlash('danger', 'Access denied.'); }
        redirect('teacher/subjects.php?view='.$sid);
    }

    if ($act === 'send_invites') {
        $sid  = (int)$_POST['subject_id'];
        $subj = $subjectClass->findById($sid);
        if ($subj && (int)$subj['teacher_user_id'] === $teacherUserId) {
            $sections = $_POST['section_keys'] ?? [];
            if (!empty($sections)) {
                $n = $notifClass->notifySections($sid, $sections);
                setFlash('success', $n.' invitation(s) sent.');
            } else { setFlash('warning', 'No sections selected.'); }
        } else { setFlash('danger', 'Access denied.'); }
        redirect('teacher/subjects.php');
    }

    if ($act === 'toggle_enrollment') {
        $sid  = (int)$_POST['subject_id'];
        $subj = $subjectClass->findById($sid);
        if ($subj && (int)$subj['teacher_user_id'] === $teacherUserId) {
            $subjectClass->toggleEnrollment($sid, (bool)(int)$_POST['enrollment_open']);
            setFlash('success', 'Enrollment status updated.');
        } else { setFlash('danger', 'Access denied.'); }
        redirect('teacher/subjects.php');
    }
}

// ── View ──────────────────────────────────────────────────────
$viewId      = isset($_GET['view']) ? (int)$_GET['view'] : 0;
$viewSubject = $viewId ? $subjectClass->findById($viewId) : null;
// Validate teacher owns this subject
if ($viewSubject && (int)$viewSubject['teacher_user_id'] !== $teacherUserId) {
    setFlash('danger', 'Access denied.'); redirect('teacher/subjects.php');
}

$mySubjects    = $teacherClass->getMySubjects($teacherUserId);
$myRequests    = $teacherClass->getMyRequests($teacherUserId);
$allSections   = $subjectClass->getAllSections();
$enrolled      = $viewId ? $subjectClass->getEnrolledStudents($viewId) : [];
$unenrolled    = $viewId ? $subjectClass->getUnenrolledStudents($viewId) : [];

// Available subjects to request (not yet claimed by this teacher)
$allSubjects   = $subjectClass->getAll(true);
$mySubjectIds  = array_column($mySubjects, 'id');
$pendingIds    = array_column(array_filter($myRequests, fn($r) => $r['status']==='pending'), 'subject_id');
$availableReq  = array_filter($allSubjects, fn($s) =>
    !in_array($s['id'], $mySubjectIds) && !in_array($s['id'], $pendingIds)
);

$activeTab = $_GET['tab'] ?? ($viewId ? 'my' : 'my');

$pageTitle = 'My Subjects';
$activeNav = 'subjects';
require_once __DIR__ . '/../includes/header_teacher.php';
$flash = getFlash();
?>

<?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] ?>"><i class="fa-solid fa-circle-info"></i> <?= htmlspecialchars($flash['msg']) ?></div>
<?php endif; ?>

<?php if ($viewSubject): ?>
<!-- ═══ ENROLLMENT VIEW ═══ -->
<div class="page-header">
  <div>
    <a href="<?= BASE_URL ?>/teacher/subjects.php" style="font-size:.82rem;color:var(--ad-muted)">
      <i class="fa-solid fa-arrow-left"></i> Back to My Subjects
    </a>
    <h1 style="margin-top:.3rem"><span style="color:var(--primary)"><?= htmlspecialchars($viewSubject['code']) ?></span> — <?= htmlspecialchars($viewSubject['name']) ?></h1>
    <p><?= Subject::formatSchedule($viewSubject) ?><?php if ($viewSubject['room']): ?> · Room <?= htmlspecialchars($viewSubject['room']) ?><?php endif; ?></p>
  </div>
  <?php $eOpen = (bool)$viewSubject['enrollment_open']; ?>
  <form method="POST" style="display:inline">
    <input type="hidden" name="post_action"     value="toggle_enrollment">
    <input type="hidden" name="subject_id"      value="<?= $viewSubject['id'] ?>">
    <input type="hidden" name="enrollment_open" value="<?= $eOpen ? 0 : 1 ?>">
    <button class="btn <?= $eOpen?'btn-warning':'btn-success' ?>">
      <i class="fa-solid fa-<?= $eOpen?'lock-open':'lock' ?>"></i>
      Enrollment <?= $eOpen?'Open — Click to Close':'Closed — Click to Open' ?>
    </button>
  </form>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:1.2rem">
  <!-- Enrolled -->
  <div class="card card-dark">
    <div class="card-header">
      <h3><i class="fa-solid fa-user-check" style="color:var(--success)"></i>&nbsp; Enrolled <span class="badge badge-success"><?= count($enrolled) ?></span></h3>
    </div>
    <div class="card-body" style="padding:0">
      <?php if (empty($enrolled)): ?>
        <div class="empty-state"><div class="empty-icon">👥</div><p style="color:var(--ad-muted)">No students enrolled yet.</p></div>
      <?php else: ?>
        <div class="table-wrapper">
          <table class="table table-dark">
            <thead><tr><th>Student</th><th>No.</th><th>Course</th><th></th></tr></thead>
            <tbody>
              <?php foreach ($enrolled as $s): ?>
              <tr>
                <td><strong><?= htmlspecialchars($s['last_name'].', '.$s['first_name']) ?></strong></td>
                <td><code style="background:var(--ad-bg);padding:.1rem .4rem;border-radius:4px;font-size:.78rem"><?= htmlspecialchars($s['student_number']) ?></code></td>
                <td style="color:var(--ad-muted);font-size:.82rem"><?= htmlspecialchars($s['course']) ?> Y<?= $s['year_level'] ?></td>
                <td>
                  <form method="POST">
                    <input type="hidden" name="post_action" value="unenroll">
                    <input type="hidden" name="subject_id"  value="<?= $viewId ?>">
                    <input type="hidden" name="student_id"  value="<?= $s['id'] ?>">
                    <button type="submit" class="btn btn-danger btn-sm" data-confirm="Remove this student?"><i class="fa-solid fa-user-minus"></i></button>
                  </form>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Add / Invite -->
  <div style="display:flex;flex-direction:column;gap:1rem">
    <!-- Add manually -->
    <div class="card card-dark">
      <div class="card-header"><h3><i class="fa-solid fa-user-plus" style="color:var(--primary)"></i>&nbsp; Add Manually</h3></div>
      <div class="card-body">
        <?php if (empty($unenrolled)): ?>
          <div style="color:var(--ad-muted);font-size:.85rem;text-align:center">All students enrolled.</div>
        <?php else: ?>
          <form method="POST" class="dark-form">
            <input type="hidden" name="post_action" value="enroll">
            <input type="hidden" name="subject_id"  value="<?= $viewId ?>">
            <div style="background:var(--ad-bg);border:1.5px solid var(--ad-border);border-radius:var(--radius-sm);max-height:220px;overflow-y:auto;padding:.4rem">
              <?php foreach ($unenrolled as $s): ?>
              <label style="display:flex;align-items:center;gap:.7rem;padding:.5rem .7rem;border-radius:6px;cursor:pointer">
                <input type="checkbox" name="student_ids[]" value="<?= $s['id'] ?>" style="accent-color:var(--primary)">
                <div>
                  <div style="font-size:.875rem;font-weight:600"><?= htmlspecialchars($s['last_name'].', '.$s['first_name']) ?></div>
                  <div style="font-size:.75rem;color:var(--ad-muted)"><?= htmlspecialchars($s['student_number']) ?></div>
                </div>
              </label>
              <?php endforeach; ?>
            </div>
            <button type="submit" class="btn btn-primary btn-sm" style="margin-top:.5rem;width:100%;justify-content:center">
              <i class="fa-solid fa-user-plus"></i> Enroll Selected
            </button>
          </form>
        <?php endif; ?>
      </div>
    </div>

    <!-- Send invites -->
    <div class="card card-dark">
      <div class="card-header"><h3><i class="fa-solid fa-envelope" style="color:var(--warning)"></i>&nbsp; Send Invitations</h3></div>
      <div class="card-body">
        <?php if (empty($allSections)): ?>
          <div style="color:var(--ad-muted);font-size:.85rem">No section groups found.</div>
        <?php else: ?>
          <form method="POST" class="dark-form">
            <input type="hidden" name="post_action" value="send_invites">
            <input type="hidden" name="subject_id"  value="<?= $viewId ?>">
            <div style="background:var(--ad-bg);border:1.5px solid var(--ad-border);border-radius:var(--radius-sm);max-height:180px;overflow-y:auto;padding:.4rem">
              <?php foreach ($allSections as $sec): ?>
              <label style="display:flex;align-items:center;gap:.7rem;padding:.45rem .7rem;border-radius:6px;cursor:pointer">
                <input type="checkbox" name="section_keys[]" value="<?= htmlspecialchars($sec['key']) ?>" style="accent-color:var(--primary)">
                <div>
                  <div style="font-size:.85rem;font-weight:600"><?= htmlspecialchars($sec['label']) ?></div>
                  <div style="font-size:.72rem;color:var(--ad-muted)"><?= $sec['count'] ?> students</div>
                </div>
              </label>
              <?php endforeach; ?>
            </div>
            <button type="submit" class="btn btn-warning btn-sm" style="margin-top:.5rem;width:100%;justify-content:center">
              <i class="fa-solid fa-paper-plane"></i> Send Invitations
            </button>
          </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php else: ?>
<!-- ═══ SUBJECTS LIST VIEW ═══ -->
<div class="page-header">
  <div><h1>My Subjects</h1><p>Manage your assigned subjects and request new ones</p></div>
</div>

<!-- Tabs -->
<div class="page-tabs" style="margin-bottom:1.2rem">
  <button class="page-tab <?= $activeTab==='my'?'active':'' ?>" onclick="switchSubjectTab('my')">
    <i class="fa-solid fa-book"></i> My Subjects <span class="badge badge-primary" style="margin-left:.3rem"><?= count($mySubjects) ?></span>
  </button>
  <button class="page-tab <?= $activeTab==='request'?'active':'' ?>" onclick="switchSubjectTab('request')">
    <i class="fa-solid fa-hand-pointer"></i> Request Subject
  </button>
  <button class="page-tab <?= $activeTab==='requests'?'active':'' ?>" onclick="switchSubjectTab('requests')">
    <i class="fa-solid fa-clock-rotate-left"></i> My Requests
    <?php $pending = array_filter($myRequests, fn($r)=>$r['status']==='pending'); ?>
    <?php if (!empty($pending)): ?><span class="badge badge-warning" style="margin-left:.3rem"><?= count($pending) ?></span><?php endif; ?>
  </button>
</div>

<!-- My Subjects tab -->
<div id="tab-my" style="display:<?= $activeTab==='my'?'block':'none' ?>">
  <?php if (empty($mySubjects)): ?>
    <div class="card card-dark"><div class="empty-state"><div class="empty-icon">📚</div>
      <h3 style="color:var(--ad-muted)">No subjects yet</h3>
      <p style="color:var(--ad-muted)">Use the "Request Subject" tab to claim subjects.</p>
    </div></div>
  <?php else: ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1rem">
      <?php foreach ($mySubjects as $s):
        $ongoing = Subject::isOngoing($s);
      ?>
      <div class="card card-dark" style="border:1.5px solid <?= $ongoing?'var(--success)':'var(--ad-border)' ?>">
        <div class="card-body" style="padding:1.1rem">
          <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:.7rem">
            <div>
              <div style="font-weight:800;font-size:1rem;color:var(--primary-light);font-family:monospace"><?= htmlspecialchars($s['code']) ?></div>
              <div style="font-size:.85rem;color:var(--ad-text)"><?= htmlspecialchars($s['name']) ?></div>
            </div>
            <?php if ($ongoing): ?><span class="badge badge-success animate-pulse">ONGOING</span><?php endif; ?>
          </div>
          <div style="font-size:.78rem;color:var(--ad-muted);margin-bottom:.6rem">
            <i class="fa-solid fa-calendar"></i> <?= $s['day_of_week'] ?>
            &nbsp;·&nbsp; <?= date('h:i A',strtotime($s['time_start'])) ?>–<?= date('h:i A',strtotime($s['time_end'])) ?>
            <?php if ($s['room']): ?><br><i class="fa-solid fa-door-open"></i> <?= htmlspecialchars($s['room']) ?><?php endif; ?>
          </div>
          <div style="display:flex;align-items:center;justify-content:space-between">
            <span style="font-size:.78rem;color:var(--ad-muted)"><i class="fa-solid fa-users"></i> <?= $s['enrolled_count'] ?> enrolled</span>
            <a href="?view=<?= $s['id'] ?>" class="btn btn-success btn-sm"><i class="fa-solid fa-users"></i> Manage</a>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<!-- Request tab -->
<div id="tab-request" style="display:<?= $activeTab==='request'?'block':'none' ?>">
  <?php if (empty($availableReq)): ?>
    <div class="card card-dark"><div class="empty-state"><div class="empty-icon">✅</div>
      <p style="color:var(--ad-muted)">No available subjects to request.</p>
    </div></div>
  <?php else: ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1rem">
      <?php foreach ($availableReq as $s): ?>
      <div class="card card-dark">
        <div class="card-body" style="padding:1.1rem">
          <div style="font-weight:800;color:var(--primary-light);font-family:monospace;font-size:.95rem"><?= htmlspecialchars($s['code']) ?></div>
          <div style="font-size:.85rem;color:var(--ad-text);margin-bottom:.5rem"><?= htmlspecialchars($s['name']) ?></div>
          <div style="font-size:.77rem;color:var(--ad-muted);margin-bottom:.8rem">
            <?= $s['day_of_week'] ?> · <?= date('h:i A',strtotime($s['time_start'])) ?>–<?= date('h:i A',strtotime($s['time_end'])) ?>
            <?php if ($s['room']): ?> · <?= htmlspecialchars($s['room']) ?><?php endif; ?>
          </div>
          <?php if (!empty($s['current_teacher_first'])): ?>
            <div style="font-size:.75rem;color:var(--warning);margin-bottom:.5rem">
              <i class="fa-solid fa-user"></i> Assigned: <?= htmlspecialchars($s['current_teacher_first'].' '.$s['current_teacher_last']) ?>
            </div>
          <?php endif; ?>
          <button class="btn btn-primary btn-sm" style="width:100%;justify-content:center"
            onclick="openReqModal(<?= $s['id'] ?>, '<?= htmlspecialchars(addslashes($s['code'].' — '.$s['name'])) ?>')">
            <i class="fa-solid fa-hand-pointer"></i> Request This Subject
          </button>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<!-- My Requests tab -->
<div id="tab-requests" style="display:<?= $activeTab==='requests'?'block':'none' ?>">
  <?php if (empty($myRequests)): ?>
    <div class="card card-dark"><div class="empty-state"><div class="empty-icon">📋</div>
      <p style="color:var(--ad-muted)">No requests submitted yet.</p>
    </div></div>
  <?php else: ?>
    <div class="card card-dark"><div class="card-body" style="padding:0">
      <div class="table-wrapper">
        <table class="table table-dark">
          <thead><tr><th>Subject</th><th>Schedule</th><th>Status</th><th>Note</th><th>Submitted</th></tr></thead>
          <tbody>
            <?php foreach ($myRequests as $req): ?>
            <tr>
              <td><strong><?= htmlspecialchars($req['code']) ?></strong><div style="font-size:.78rem;color:var(--ad-muted)"><?= htmlspecialchars($req['name']) ?></div></td>
              <td style="font-size:.82rem"><?= $req['day_of_week'] ?><br><span style="color:var(--ad-muted)"><?= date('h:i A',strtotime($req['time_start'])) ?>–<?= date('h:i A',strtotime($req['time_end'])) ?></span></td>
              <td>
                <?php if ($req['status']==='pending'):   ?><span class="badge badge-warning">Pending</span>
                <?php elseif ($req['status']==='approved'): ?><span class="badge badge-success">Approved</span>
                <?php else: ?><span class="badge badge-danger">Rejected</span>
                <?php endif; ?>
              </td>
              <td style="font-size:.8rem;color:var(--ad-muted)"><?= htmlspecialchars($req['admin_note'] ?? '—') ?></td>
              <td style="font-size:.8rem;color:var(--ad-muted)"><?= date('M j',strtotime($req['created_at'])) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div></div>
  <?php endif; ?>
</div>
<?php endif; ?>

<!-- Request Modal -->
<div id="reqModal" style="display:none;position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.5);backdrop-filter:blur(4px);align-items:center;justify-content:center">
  <div style="background:var(--ad-surface);border-radius:20px;padding:2rem;max-width:400px;width:90%;box-shadow:0 20px 60px rgba(0,0,0,.4)">
    <h3 style="color:var(--ad-text);margin-bottom:.3rem"><i class="fa-solid fa-hand-pointer" style="color:var(--primary)"></i>&nbsp; Request Subject</h3>
    <p id="reqSubjectName" style="color:var(--ad-muted);font-size:.85rem;margin-bottom:1rem"></p>
    <form method="POST" class="dark-form">
      <input type="hidden" name="post_action" value="request_subject">
      <input type="hidden" name="subject_id"  id="reqSubjectId">
      <div class="form-group">
        <label class="form-label">Message to Admin <span style="color:var(--ad-muted)">(optional)</span></label>
        <textarea name="message" class="form-control" rows="3" placeholder="Why you'd like to teach this subject…" style="resize:none"></textarea>
      </div>
      <div style="display:flex;gap:.7rem;margin-top:.5rem">
        <button type="button" class="btn btn-secondary" style="flex:1;justify-content:center" onclick="closeReqModal()">Cancel</button>
        <button type="submit" class="btn btn-primary" style="flex:1;justify-content:center"><i class="fa-solid fa-paper-plane"></i> Submit</button>
      </div>
    </form>
  </div>
</div>

<script>
function switchSubjectTab(tab) {
  ['my','request','requests'].forEach(t => {
    document.getElementById('tab-'+t).style.display = t===tab?'block':'none';
  });
}
const reqModal = document.getElementById('reqModal');
function openReqModal(id, name) {
  document.getElementById('reqSubjectId').value = id;
  document.getElementById('reqSubjectName').textContent = name;
  reqModal.style.display = 'flex';
}
function closeReqModal() { reqModal.style.display = 'none'; }
reqModal.addEventListener('click', e => { if (e.target===reqModal) closeReqModal(); });
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
