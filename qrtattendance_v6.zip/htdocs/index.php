<?php
require_once __DIR__ . '/includes/auth.php';
if (!empty($_SESSION['logged_in'])) {
    if ($_SESSION['role'] === 'admin')        redirect('admin/dashboard.php');
    elseif ($_SESSION['role'] === 'teacher')  redirect('teacher/dashboard.php');
    else                                       redirect('student/dashboard.php');
}
redirect('login.php');
