<?php
// ============================================================
//  api/attendance_status.php
//  Polled by student/qrcode.php every 2 seconds.
//
//  Returns the student's current attendance record for today.
//  The CLIENT (localStorage) decides whether to show the overlay.
//  No session-based delivery tracking — avoids InfinityFree
//  session/cookie issues with AJAX requests entirely.
// ============================================================
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('X-Content-Type-Options: nosniff');

if (empty($_SESSION['logged_in']) || $_SESSION['role'] !== 'student') {
    http_response_code(403);
    echo json_encode(['success' => false]);
    exit;
}

try {
    $student = (new Student())->findByUserId((int)$_SESSION['user_id']);

    if (!$student) {
        echo json_encode(['success' => false]);
        exit;
    }

    $record = Database::getInstance()->query(
        "SELECT id, time_in, time_out, status
         FROM attendance
         WHERE student_id = ? AND date = CURDATE()
         ORDER BY id DESC
         LIMIT 1",
        [$student['id']]
    )->fetch();

    if (!$record) {
        echo json_encode([
            'success'  => true,
            'recorded' => false,
            'state'    => 'none',   // nothing recorded yet
        ]);
        exit;
    }

    $hasOut = !empty($record['time_out']);
    $hasIn  = !empty($record['time_in']);

    echo json_encode([
        'success'    => true,
        'recorded'   => true,
        // 'state' is what the client uses to detect changes
        // 'in'  = time_in recorded, no time_out yet
        // 'out' = both recorded
        'state'      => $hasOut ? 'out' : 'in',
        'record_id'  => (int)$record['id'],
        'status'     => $record['status'],
        'time_in'    => $hasIn  ? date('h:i A', strtotime($record['time_in']))  : null,
        'time_out'   => $hasOut ? date('h:i A', strtotime($record['time_out'])) : null,
    ]);

} catch (Throwable $e) {
    echo json_encode(['success' => false, 'recorded' => false, 'state' => 'none']);
}
exit;