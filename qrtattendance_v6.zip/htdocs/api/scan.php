<?php
// ============================================================
//  api/scan.php — QR Scan & Stats API Endpoint
//  Called by JavaScript fetch() from admin/scan.php
// ============================================================
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

// Must be logged in as admin OR teacher
if (session_status() === PHP_SESSION_NONE) session_start();
$_role = $_SESSION['role'] ?? '';
if (empty($_SESSION['logged_in']) || !in_array($_role, ['admin','teacher'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized.']);
    exit;
}

// If teacher: restrict to their own subjects only
$_isTeacher     = ($_role === 'teacher');
$_teacherUserId = (int)$_SESSION['user_id'];

$attendanceClass = new Attendance();
$subjectClass    = new Subject();
$studentClass    = new Student();

// ── GET: Today's stats ────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['stats'])) {
    $counts = $attendanceClass->countToday();
    echo json_encode([
        'success' => true,
        'present' => $counts['present'],
        'late'    => $counts['late'],
        'absent'  => $counts['absent'],
        'total'   => $counts['total'],
    ]);
    exit;
}

// ── POST: Process scan ────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $body  = json_decode(file_get_contents('php://input'), true);
    $token = trim($body['token'] ?? '');

    if ($token === '') {
        echo json_encode(['success' => false, 'message' => 'Empty QR token.']);
        exit;
    }

    // Resolve student from token first so we can check their enrolled subjects
    $student = $studentClass->findByQrToken($token);
    if (!$student) {
        echo json_encode(['success' => false, 'message' => 'Unknown QR code — student not found.']);
        exit;
    }

    // Find the subject that is currently active for this student
    // (today's day, current time within time_start..time_end, enrolled, active)
    $subject = $subjectClass->getActiveSubjectForStudent((int)$student['id']);

    // If teacher: verify the active subject is one of their assigned subjects
    if ($_isTeacher && $subject) {
        if ((int)($subject['teacher_user_id'] ?? 0) !== $_teacherUserId) {
            echo json_encode([
                'success' => false,
                'message' => 'This subject is not assigned to you. Only the assigned teacher can scan for it.',
                'student' => $student,
            ]);
            exit;
        }
    }

    if (!$subject) {
        // No active subject found — check if there are any subjects today for context
        $todaySubjects = $subjectClass->getTodaysSubjects();
        if (empty($todaySubjects)) {
            $msg = 'No classes are scheduled for today (' . date('l') . ').';
        } else {
            $msg = 'No active class right now for ' . $student['first_name'] . ' ' . $student['last_name'] . '. '
                 . 'Classes are outside their scheduled window or the student is not enrolled.';
        }
        echo json_encode(['success' => false, 'message' => $msg, 'student' => $student]);
        exit;
    }

    // Process the scan with subject context (thresholds applied inside processScan)
    $result = $attendanceClass->processScan($token, (int)$_SESSION['user_id'], $subject);
    echo json_encode($result);
    exit;
}

http_response_code(405);
echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
