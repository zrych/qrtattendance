<?php
require_once __DIR__ . '/../includes/auth.php';
User::requireLogin('student');

$studentClass = new Student();
$student      = $studentClass->findByUserId((int)$_SESSION['user_id']);
if (!$student) { User::logout(); }

$pageTitle = 'My QR Code';
$activeNav = 'qrcode';
require_once __DIR__ . '/../includes/header_student.php';
?>

<!-- ═══════════════════════════════════════════════════════════
     ATTENDANCE CONFIRMATION OVERLAY
     Hidden by default. Shown only when the server reports
     a new_scan that hasn't been delivered yet.
════════════════════════════════════════════════════════════ -->
<div id="attendanceOverlay" style="
  display:none;
  position:fixed;inset:0;z-index:9999;
  background:rgba(0,0,0,.55);
  backdrop-filter:blur(6px);
  -webkit-backdrop-filter:blur(6px);
  align-items:center;justify-content:center">
  <div id="overlayCard" style="
    background:var(--st-surface);
    border-radius:24px;
    padding:2.5rem 2rem;
    max-width:340px;width:90%;
    text-align:center;
    box-shadow:0 24px 60px rgba(0,0,0,.35)">

    <div id="overlayIcon" style="
      width:72px;height:72px;border-radius:50%;
      display:flex;align-items:center;justify-content:center;
      margin:0 auto 1.2rem;font-size:2rem"></div>

    <h2 id="overlayTitle" style="
      font-size:1.35rem;font-weight:800;
      color:var(--st-text);margin:0 0 .4rem"></h2>

    <div id="overlayBadge" style="
      display:inline-block;padding:.3rem .9rem;
      border-radius:999px;font-size:.8rem;font-weight:700;
      letter-spacing:.5px;text-transform:uppercase;
      margin-bottom:1rem"></div>

    <p id="overlayTime" style="
      font-size:2rem;font-weight:800;
      font-variant-numeric:tabular-nums;
      color:var(--st-text);margin:0 0 .3rem;
      letter-spacing:1px"></p>
    <p id="overlayLabel" style="
      font-size:.82rem;color:var(--st-muted);margin:0 0 1.4rem"></p>

    <p style="font-size:.9rem;color:var(--st-text);font-weight:600;margin:0 0 1.4rem">
      <?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?>
      &nbsp;·&nbsp;
      <span style="color:var(--st-muted);font-weight:400">
        <?= htmlspecialchars($student['student_number']) ?>
      </span>
    </p>

    <!-- Progress bar countdown to auto-dismiss -->
    <div style="height:4px;background:var(--st-border);border-radius:2px;overflow:hidden">
      <div id="overlayProgress" style="
        height:100%;border-radius:2px;
        width:100%"></div>
    </div>
    <p style="font-size:.73rem;color:var(--st-muted);margin:.5rem 0 0">
      Tap anywhere to dismiss
    </p>
  </div>
</div>

<!-- ════════════════════════════════════════════════════════ -->

<div style="max-width:600px;margin:0 auto">

  <div style="text-align:center;margin-bottom:1.5rem">
    <h1 style="font-size:1.6rem;font-weight:800;color:var(--st-text)">My QR Code</h1>
    <p style="color:var(--st-muted)">Show this code to the scanner to mark your attendance.</p>
  </div>

  <!-- QR Card -->
  <div class="qr-display-card">
    <div style="display:inline-flex;align-items:center;justify-content:center;
                width:48px;height:48px;background:rgba(99,102,241,.1);
                border-radius:14px;margin:0 auto 1rem">
      <i class="fa-solid fa-qrcode" style="font-size:1.4rem;color:var(--primary)"></i>
    </div>
    <h2><?= htmlspecialchars($student['last_name'] . ', ' . $student['first_name']) ?></h2>
    <p><?= htmlspecialchars($student['student_number']) ?> &nbsp;·&nbsp;
       <?= htmlspecialchars($student['course'] . ' Yr' . $student['year_level']) ?></p>

    <div id="qrcode" style="margin:0 auto;display:inline-block"></div>

    <!-- Status badge shown after attendance is recorded -->
    <div id="scannedBadge" style="display:none;margin-top:.8rem">
      <span id="scannedBadgeText" style="
        background:rgba(16,185,129,.1);color:#15803d;
        padding:.35rem .9rem;border-radius:999px;
        font-size:.8rem;font-weight:700">
        <i class="fa-solid fa-circle-check"></i> Attendance Recorded
      </span>
    </div>

    <div class="qr-student-info" style="margin-top:1rem">
      <i class="fa-solid fa-circle-info"></i>
      Token: <strong><?= htmlspecialchars(substr($student['qr_token'], 0, 8)) ?>…</strong>
    </div>

    <div style="display:flex;gap:.7rem;justify-content:center;margin-top:1.4rem;flex-wrap:wrap">
      <button class="btn btn-primary" onclick="downloadQR()">
        <i class="fa-solid fa-download"></i> Download QR
      </button>
      <button class="btn btn-outline" onclick="printQR()">
        <i class="fa-solid fa-print"></i> Print
      </button>
    </div>
  </div>

  <!-- Info cards -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-top:1.2rem">
    <div class="card card-light" style="padding:1.2rem">
      <div style="display:flex;align-items:center;gap:.7rem;margin-bottom:.6rem">
        <div style="width:36px;height:36px;background:rgba(16,185,129,.1);border-radius:10px;
                    display:flex;align-items:center;justify-content:center">
          <i class="fa-solid fa-check" style="color:#10b981"></i>
        </div>
        <strong style="color:var(--st-text)">How to use</strong>
      </div>
      <ol style="color:var(--st-muted);font-size:.85rem;padding-left:1.1rem;line-height:1.9">
        <li>Open this page on your phone</li>
        <li>Present your QR code to the scanner</li>
        <li>First scan = Time In</li>
        <li>Second scan = Time Out</li>
      </ol>
    </div>
    <div class="card card-light" style="padding:1.2rem">
      <div style="display:flex;align-items:center;gap:.7rem;margin-bottom:.6rem">
        <div style="width:36px;height:36px;background:rgba(245,158,11,.1);border-radius:10px;
                    display:flex;align-items:center;justify-content:center">
          <i class="fa-solid fa-shield" style="color:#f59e0b"></i>
        </div>
        <strong style="color:var(--st-text)">Security tips</strong>
      </div>
      <ul style="color:var(--st-muted);font-size:.85rem;padding-left:1.1rem;line-height:1.9">
        <li>Never share your QR code</li>
        <li>Each QR is unique to you</li>
        <li>Report loss to admin</li>
        <li>Keep screen brightness up</li>
      </ul>
    </div>
  </div>

</div>

<!-- QR Code library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>
// ── QR Generation ─────────────────────────────────────────────
const QR_TOKEN   = <?= json_encode($student['qr_token']) ?>;
const FULL_NAME  = <?= json_encode($student['first_name'] . ' ' . $student['last_name']) ?>;
const STU_NUMBER = <?= json_encode($student['student_number']) ?>;
const STU_COURSE = <?= json_encode($student['course'] . ' – Year ' . $student['year_level'] . ($student['section'] ? ' Sec. ' . $student['section'] : '')) ?>;

new QRCode(document.getElementById('qrcode'), {
    text: QR_TOKEN, width: 260, height: 260,
    colorDark: '#1e293b', colorLight: '#ffffff',
    correctLevel: QRCode.CorrectLevel.H
});

function downloadQR() {
    const canvas = document.querySelector('#qrcode canvas');
    if (!canvas) { alert('QR not ready yet.'); return; }
    const out = document.createElement('canvas');
    out.width = 360; out.height = 420;
    const ctx = out.getContext('2d');
    ctx.fillStyle = '#ffffff'; ctx.roundRect(0,0,360,420,18); ctx.fill();
    ctx.strokeStyle = '#6366f1'; ctx.lineWidth = 3;
    ctx.roundRect(4,4,352,412,16); ctx.stroke();
    ctx.fillStyle = '#6366f1'; ctx.fillRect(4,4,352,60);
    ctx.fillStyle = '#ffffff'; ctx.font = 'bold 16px Inter,sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('QR ATTENDANCE', 180, 28);
    ctx.font = '13px Inter,sans-serif'; ctx.fillText(STU_NUMBER, 180, 52);
    ctx.drawImage(canvas, 50, 80, 260, 260);
    ctx.fillStyle = '#1e293b'; ctx.font = 'bold 15px Inter,sans-serif';
    ctx.fillText(FULL_NAME, 180, 368);
    ctx.fillStyle = '#64748b'; ctx.font = '12px Inter,sans-serif';
    ctx.fillText(STU_COURSE, 180, 388);
    ctx.fillText('Generated: ' + new Date().toLocaleDateString(), 180, 406);
    const a = document.createElement('a');
    a.download = 'QR_' + STU_NUMBER + '.png';
    a.href = out.toDataURL('image/png'); a.click();
}

function printQR() {
    const canvas = document.querySelector('#qrcode canvas');
    if (!canvas) { alert('QR not ready yet.'); return; }
    const win = window.open('', '_blank');
    win.document.write(`<html><head><title>QR – ${FULL_NAME}</title>
    <style>body{font-family:Inter,sans-serif;text-align:center;padding:40px}
    h2{margin:0;font-size:20px}p{color:#64748b;margin:4px 0}
    .box{border:2px solid #6366f1;border-radius:16px;padding:24px;display:inline-block}</style>
    </head><body><div class="box">
    <p style="color:#6366f1;font-weight:700;letter-spacing:1px;font-size:12px">QR ATTENDANCE SYSTEM</p>
    <h2>${FULL_NAME}</h2><p>${STU_NUMBER}</p><p>${STU_COURSE}</p>
    <img src="${canvas.toDataURL()}" style="width:220px;margin:12px auto;display:block">
    </div><script>window.onload=()=>window.print()<\/script></body></html>`);
    win.document.close();
}

// ── Attendance Overlay ────────────────────────────────────────

const overlay      = document.getElementById('attendanceOverlay');
const overlayCard  = document.getElementById('overlayCard');
const overlayIcon  = document.getElementById('overlayIcon');
const overlayTitle = document.getElementById('overlayTitle');
const overlayBadge = document.getElementById('overlayBadge');
const overlayTime  = document.getElementById('overlayTime');
const overlayLabel = document.getElementById('overlayLabel');
const overlayProg  = document.getElementById('overlayProgress');
const scannedBadge = document.getElementById('scannedBadge');
const scannedText  = document.getElementById('scannedBadgeText');
const qrWrap       = document.getElementById('qrcode');

const OVERLAY_MS = 8000;
const POLL_MS    = 2000;

let dismissTimer = null;

const STATUS = {
    present: { icon:'✅', bg:'rgba(16,185,129,.15)', bar:'#10b981', label:'Present', badgeBg:'rgba(16,185,129,.2)', badgeColor:'#10b981' },
    late:    { icon:'🕐', bg:'rgba(245,158,11,.15)', bar:'#f59e0b', label:'Late',    badgeBg:'rgba(245,158,11,.2)', badgeColor:'#f59e0b' },
    absent:  { icon:'⚠️', bg:'rgba(239,68,68,.15)',  bar:'#ef4444', label:'Absent',  badgeBg:'rgba(239,68,68,.2)',  badgeColor:'#ef4444' },
};

function showOverlay(data) {
    const isOut = (data.state === 'out');
    const cfg   = STATUS[data.status] || STATUS.present;

    overlayIcon.textContent       = isOut ? '👋' : cfg.icon;
    overlayIcon.style.background  = isOut ? 'rgba(99,102,241,.15)' : cfg.bg;
    overlayTitle.textContent      = isOut ? 'Time Out Recorded' : 'Attendance Recorded!';
    overlayBadge.textContent      = isOut ? 'Time Out' : cfg.label;
    overlayBadge.style.background = isOut ? 'rgba(99,102,241,.2)' : cfg.badgeBg;
    overlayBadge.style.color      = isOut ? '#6366f1' : cfg.badgeColor;
    overlayTime.textContent       = isOut ? data.time_out : data.time_in;
    overlayLabel.textContent      = isOut ? 'Time Out' : 'Time In';

    // Blur QR so it can't be immediately re-scanned
    qrWrap.style.transition = 'opacity .3s, filter .3s';
    qrWrap.style.opacity    = '0.15';
    qrWrap.style.filter     = 'blur(4px)';

    // Show persistent badge beneath QR
    scannedBadge.style.display = 'block';
    if (isOut) {
        scannedText.style.background = 'rgba(99,102,241,.1)';
        scannedText.style.color      = '#6366f1';
        scannedText.innerHTML        = '<i class="fa-solid fa-circle-check"></i> Fully Recorded';
    } else {
        scannedText.style.background = 'rgba(16,185,129,.1)';
        scannedText.style.color      = '#15803d';
        scannedText.innerHTML        = '<i class="fa-solid fa-circle-check"></i> Attendance Recorded';
    }

    // Animate overlay in
    overlay.style.display  = 'flex';
    overlayCard.style.animation = 'slideUpOverlay .35s cubic-bezier(.34,1.56,.64,1) both';

    // Progress bar countdown
    const barColor = isOut ? '#6366f1' : cfg.bar;
    overlayProg.style.transition = 'none';
    overlayProg.style.background = barColor;
    overlayProg.style.width      = '100%';
    overlayProg.getBoundingClientRect(); // force reflow
    overlayProg.style.transition = `width ${OVERLAY_MS}ms linear`;
    overlayProg.style.width      = '0%';

    clearTimeout(dismissTimer);
    dismissTimer = setTimeout(hideOverlay, OVERLAY_MS);
}

function hideOverlay() {
    clearTimeout(dismissTimer);
    overlay.style.display = 'none';
    // Restore QR
    qrWrap.style.opacity = '1';
    qrWrap.style.filter  = 'none';
    // Reset progress bar silently
    overlayProg.style.transition = 'none';
    overlayProg.style.width      = '100%';
}

overlay.addEventListener('click', hideOverlay);

// ── Polling ───────────────────────────────────────────────────
//
// State tracking uses localStorage — survives page refreshes and
// is independent of server sessions or InfinityFree's proxy layer.
//
// localStorage key: 'att_state_<studentId>'
// Stored value: JSON { date, state, record_id }
//   date      = 'YYYY-MM-DD' (today's date)
//   state     = 'none' | 'in' | 'out'
//   record_id = int (attendance row ID)
//
// On each poll, compare the server's current state against what
// localStorage remembers. If state changed → new scan → show overlay.
// localStorage is updated AFTER showing the overlay so it only fires once.

const STUDENT_KEY = 'att_state_' + <?= json_encode((string)$student['id']) ?>;
const TODAY       = <?= json_encode(date('Y-m-d')) ?>;

function loadLocalState() {
    try {
        const raw = localStorage.getItem(STUDENT_KEY);
        if (!raw) return null;
        const obj = JSON.parse(raw);
        // Discard if it's from a previous day
        if (obj.date !== TODAY) {
            localStorage.removeItem(STUDENT_KEY);
            return null;
        }
        return obj;
    } catch (e) {
        return null;
    }
}

function saveLocalState(state, recordId) {
    try {
        localStorage.setItem(STUDENT_KEY, JSON.stringify({
            date:      TODAY,
            state:     state,
            record_id: recordId,
        }));
    } catch (e) { /* localStorage unavailable — fail silently */ }
}

async function pollStatus() {
    try {
        const r = await fetch('/api/attendance_status.php', {
            credentials: 'same-origin',
            cache:       'no-store'
        });

        if (!r.ok) return;

        const ct = r.headers.get('Content-Type') || '';
        if (!ct.includes('application/json')) {
            // InfinityFree security challenge returned HTML — reload for fresh cookie
            location.reload();
            return;
        }

        const data = await r.json();
        if (!data.success) return;

        // ── No record today ────────────────────────────────────
        if (!data.recorded || data.state === 'none') {
            scannedBadge.style.display = 'none';
            qrWrap.style.opacity       = '1';
            qrWrap.style.filter        = 'none';
            return;
        }

        // ── A record exists ────────────────────────────────────
        // Always keep the "Attendance Recorded" badge visible
        scannedBadge.style.display = 'block';

        const local     = loadLocalState();
        const prevState = local ? local.state : 'none';

        // Has the state changed since we last showed an overlay?
        const stateChanged = (data.state !== prevState);

        if (stateChanged) {
            // Save FIRST so rapid polls don't double-trigger
            saveLocalState(data.state, data.record_id);
            // Then show the overlay
            showOverlay(data);
        }

    } catch (e) {
        // Silently ignore network errors
    }
}

pollStatus();
setInterval(pollStatus, POLL_MS);
</script>

<style>
@keyframes slideUpOverlay {
    from { transform: translateY(40px) scale(.95); opacity: 0 }
    to   { transform: translateY(0)    scale(1);   opacity: 1 }
}
</style>

</main>
<script>
document.querySelectorAll('.alert').forEach(a => {
    setTimeout(() => {
        a.style.opacity = '0';
        a.style.transition = 'opacity .5s';
        setTimeout(() => a.remove(), 500);
    }, 4000);
});
</script>
</body>
</html>